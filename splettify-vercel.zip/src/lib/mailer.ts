/**
 * Pengirim email kode (reset kata sandi & verifikasi pendaftaran).
 *
 * - Jika RESEND_API_KEY tersedia di environment → email dikirim sungguhan
 *   melalui API Resend (https://resend.com).
 * - Jika tidak (mis. lingkungan pengembangan/sandbox tanpa SMTP) → kode
 *   dikembalikan sebagai `previewCode` agar alur tetap bisa diuji, dan
 *   UI menampilkannya sebagai "kotak masuk simulasi".
 */

export type MailKind = 'reset' | 'verify';

export type MailResult = {
  /** true jika email benar-benar terkirim ke provider email */
  delivered: boolean;
  /** hanya terisi pada mode simulasi (tanpa provider email) */
  previewCode: string | null;
  /** penyebab gagal kirim (untuk log server) */
  error?: string;
};

function codeDigitsHtml(code: string): string {
  return code
    .split('')
    .map(
      (d) =>
        `<td style="padding:0 6px;"><div style="width:52px;height:64px;line-height:64px;text-align:center;font-size:30px;font-weight:700;color:#1f1235;background:#f3effc;border:1px solid #ddd0f5;border-radius:12px;font-family:Arial,Helvetica,sans-serif;">${d}</div></td>`
    )
    .join('');
}

function codeEmailHtml(opts: { name: string; code: string; kind: MailKind }): string {
  const { name, code, kind } = opts;
  const heading =
    kind === 'reset'
      ? `Hai ${name}, ini kode reset kata sandimu`
      : `Hai ${name}, verifikasi emailmu`;
  const intro =
    kind === 'reset'
      ? `Gunakan kode di bawah ini untuk mengatur kata sandi baru. Kode berlaku selama <b>10 menit</b> dan hanya bisa dipakai sekali.`
      : `Selamat datang di Yanzea! Masukkan kode di bawah ini untuk memverifikasi emailmu. Kode berlaku selama <b>10 menit</b> dan hanya bisa dipakai sekali.`;
  const notYou =
    kind === 'reset'
      ? `<b>Tidak meminta kode ini?</b> Abaikan saja email ini — kata sandimu tidak akan berubah.`
      : `<b>Tidak mendaftar di Yanzea?</b> Abaikan saja email ini — akun tidak akan aktif tanpa verifikasi.`;
  const subjectTag = kind === 'reset' ? 'Kode reset kata sandi' : 'Kode verifikasi akun';

  return `<!doctype html>
<html><body style="margin:0;padding:32px 12px;background:#f6f4fb;font-family:Arial,Helvetica,sans-serif;">
  <div style="max-width:520px;margin:0 auto;background:#ffffff;border-radius:20px;overflow:hidden;border:1px solid #e8e2f5;">
    <div style="background:linear-gradient(135deg,#2a1458,#6d28d9);padding:28px 32px;">
      <p style="margin:0;font-size:20px;font-weight:700;color:#ffffff;letter-spacing:.5px;">Yanzea</p>
      <p style="margin:4px 0 0;font-size:12px;color:rgba(255,255,255,.75);">AI Agent Otomasi, IIoT &amp; IoT</p>
    </div>
    <div style="padding:32px;">
      <p style="margin:0 0 8px;font-size:18px;font-weight:700;color:#1f1235;">${heading}</p>
      <p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:#5c5470;">${intro}</p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 20px;"><tr>${codeDigitsHtml(code)}</tr></table>
      <p style="margin:0 0 4px;font-size:14px;line-height:1.6;color:#5c5470;">${notYou}</p>
      <hr style="border:none;border-top:1px solid #eee7fa;margin:24px 0;" />
      <p style="margin:0;font-size:11px;line-height:1.6;color:#9a92ac;">
        Email otomatis dari Yanzea · Jangan bagikan kode ini kepada siapa pun, termasuk pihak yang mengaku sebagai tim Yanzea.
      </p>
    </div>
  </div>
</body></html>`;
}

export async function sendCodeEmail(
  to: string,
  name: string,
  code: string,
  kind: MailKind
): Promise<MailResult> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.MAIL_FROM || 'Yanzea <onboarding@resend.dev>';
  const subject =
    kind === 'reset' ? `Kode reset kata sandi Yanzea: ${code}` : `Kode verifikasi akun Yanzea: ${code}`;

  if (!apiKey) {
    // Mode simulasi: tampilkan kode di server log + serahkan ke UI untuk pratinjau.
    console.log(`[mailer:simulasi] Kode ${kind} untuk ${to}: ${code} (berlaku 10 menit)`);
    return { delivered: false, previewCode: code };
  }

  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject,
        html: codeEmailHtml({ name, code, kind }),
      }),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => '');
      console.error('[mailer:resend] Gagal mengirim email:', res.status, detail);
      return { delivered: false, previewCode: null, error: `HTTP ${res.status}` };
    }
    return { delivered: true, previewCode: null };
  } catch (err) {
    console.error('[mailer:resend] Error jaringan:', err);
    return { delivered: false, previewCode: null, error: 'network' };
  }
}
