import { PrismaClient } from '@prisma/client'
import { createClient } from '@libsql/client'
import { PrismaLibSQL } from '@prisma/adapter-libsql'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/**
 * Database dual-mode:
 *
 * 1. PRODUKSI (Vercel/Turso) — set environment:
 *      TURSO_DATABASE_URL=libsql://splettify-<user>.turso.io
 *      TURSO_AUTH_TOKEN=eyJ...
 *    → Prisma memakai driver adapter libSQL menuju Turso (SQLite di cloud,
 *      gratis, cocok untuk serverless).
 *
 * 2. LOKAL/SANDBOX — tanpa env Turso → SQLite file biasa lewat DATABASE_URL
 *      (db/custom.db), perilaku lama tidak berubah.
 */
function instantiateDb(): PrismaClient {
  const tursoUrl = process.env.TURSO_DATABASE_URL

  if (tursoUrl && tursoUrl.startsWith('libsql://')) {
    const libsql = createClient({
      url: tursoUrl,
      authToken: process.env.TURSO_AUTH_TOKEN,
    })
    return new PrismaClient({
      adapter: new PrismaLibSQL(libsql),
    })
  }

  return new PrismaClient({
    log: ['query'],
  })
}

export const db = globalForPrisma.prisma ?? instantiateDb()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
