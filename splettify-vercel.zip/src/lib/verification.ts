import { createHash, randomInt, timingSafeEqual } from 'crypto';

/** Masa berlaku kode verifikasi/reset (10 menit). */
export const CODE_TTL_MS = 10 * 60 * 1000;

/** Batas percobaan memasukkan kode sebelum kode dikunci. */
export const MAX_CODE_ATTEMPTS = 5;

/** Batas jumlah kode yang dikirim per email dalam 10 menit (anti spam). */
export const MAX_CODES_PER_WINDOW = 5;

export const SEND_WINDOW_MS = 10 * 60 * 1000;

/** Kode acak 6 digit yang aman secara kriptografis, mis. "042913". */
export function generateCode(): string {
  return String(randomInt(0, 1_000_000)).padStart(6, '0');
}

/** Hash SHA-256 dari kode 6 digit. */
export function hashCode(code: string): string {
  return createHash('sha256').update(code, 'utf8').digest('hex');
}

/** Perbandingan konstan-waktu untuk hash kode. */
export function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  return bufA.length === bufB.length && timingSafeEqual(bufA, bufB);
}
