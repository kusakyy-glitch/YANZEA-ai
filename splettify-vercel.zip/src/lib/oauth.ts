import { db } from '@/lib/db';

/** Ambil nama tampilan yang rapi dari bagian lokal email, mis. "budi.santoso" → "Budi Santoso". */
export function prettyNameFromEmail(email: string): string {
  const local = email.split('@')[0] || 'Pengguna Splettify';
  return local
    .split(/[._\-+]+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

/**
 * Cari pengguna berdasarkan email; jika belum ada, daftarkan akun baru
 * via Google (tanpa kata sandi). Jika akun email sudah ada, tautkan
 * googleId-nya sehingga masuk lewat Google otomatis tersambung.
 */
export async function findOrCreateGoogleUser(opts: {
  email: string;
  name: string;
  googleId: string;
}) {
  const email = opts.email.trim().toLowerCase();

  let user = await db.user.findUnique({ where: { email } });
  if (!user) {
    user = await db.user.create({
      data: {
        email,
        name: opts.name || prettyNameFromEmail(email),
        googleId: opts.googleId,
        passwordHash: null,
        emailVerified: true, // email Google sudah terverifikasi oleh Google
      },
    });
  } else if (!user.googleId || !user.emailVerified) {
    user = await db.user.update({
      where: { id: user.id },
      data: { googleId: opts.googleId, emailVerified: true },
    });
  }
  return user;
}
