import type { Metadata } from "next";
import { Outfit, Instrument_Serif } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const outfit = Outfit({
  variable: "--font-outfit",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
});

const instrumentSerif = Instrument_Serif({
  variable: "--font-instrument",
  subsets: ["latin"],
  weight: "400",
  style: ["normal", "italic"],
});

// Domain produksi: www.splettify.co.id (bisa dioverride lewat NEXT_PUBLIC_SITE_URL saat deploy)
export const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") || "https://www.splettify.co.id";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: "Yanzea — AI Agent Otomasi, IIoT & IoT",
  description:
    "Yanzea, AI agent pintar untuk sistem otomasi, IIoT, dan IoT: konsultasi PLC & SCADA, desain proyek IoT, hingga dashboard pemantauan perangkat real-time — cepat dan dalam Bahasa Indonesia.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${outfit.variable} ${instrumentSerif.variable} font-[family-name:var(--font-outfit)] antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
