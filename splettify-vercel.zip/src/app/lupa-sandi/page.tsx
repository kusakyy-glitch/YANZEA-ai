'use client';

import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, Eye, EyeOff, KeyRound, Loader2, Lock, Mail, RefreshCw, ShieldCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FlowerOfLife } from '@/components/sacred-geometry';

type Step = 'email' | 'verify' | 'done';

const STEP_LABELS = [
  { id: 'email' as const, label: 'Email' },
  { id: 'verify' as const, label: 'Verifikasi' },
  { id: 'done' as const, label: 'Selesai' },
];

export default function LupaSandiPage() {
  const { toast } = useToast();

  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [maskedEmail, setMaskedEmail] = useState('');

  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [previewCode, setPreviewCode] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resendIn, setResendIn] = useState(0);

  /* hitung mundur kirim ulang kode */
  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  /* setelah sukses, otomatis diarahkan ke aplikasi (sesi sudah aktif) */
  useEffect(() => {
    if (step !== 'done') return;
    const t = setTimeout(() => {
      window.location.href = '/';
    }, 2600);
    return () => clearTimeout(t);
  }, [step]);

  function maskEmail(e: string): string {
    return e.replace(/^(.).+(@.*)$/, '$1•••$2');
  }

  async function requestCode(target?: string) {
    const mail = (target ?? email).trim();
    setError(null);
    if (!/^\S+@\S+\.\S+$/.test(mail)) {
      setError('Masukkan alamat email yang valid.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: mail }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.message || 'Gagal mengirim kode. Silakan coba lagi.');
        return;
      }
      setPreviewCode(data.previewCode ?? null);
      setMaskedEmail(maskEmail(mail));
      setCode('');
      setPassword('');
      setConfirm('');
      setResendIn(60);
      setStep('verify');
      toast({
        title: data.delivered ? 'Kode verifikasi terkirim' : 'Kode verifikasi siap',
        description: data.message,
        className: 'border-violet-300/25 bg-[#170f24] text-white shadow-[0_18px_50px_-12px_rgba(76,29,149,0.8)]',
      });
    } catch {
      setError('Koneksi bermasalah. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  async function submitReset(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);

    if (code.replace(/\D/g, '').length !== 6) {
      setError('Kode verifikasi harus 6 digit angka.');
      return;
    }
    if (password.length < 6) {
      setError('Kata sandi baru minimal 6 karakter.');
      return;
    }
    if (password !== confirm) {
      setError('Kata sandi tidak cocok.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), code: code.replace(/\D/g, ''), password }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.message || 'Gagal memperbarui kata sandi.');
        return;
      }
      toast({
        title: 'Kata sandi berhasil diperbarui',
        description: `Selamat datang kembali${data.user?.name ? `, ${data.user.name.split(' ')[0]}` : ''}!`,
        className: 'border-violet-300/25 bg-[#170f24] text-white shadow-[0_18px_50px_-12px_rgba(76,29,149,0.8)]',
      });
      setStep('done');
    } catch {
      setError('Koneksi bermasalah. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  const stepIndex = step === 'email' ? 0 : step === 'verify' ? 1 : 2;

  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden bg-[#120b1e]">
      {/* backdrop ungu, konsisten dengan halaman masuk */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(120% 90% at 85% 0%, rgba(124,58,237,0.75) 0%, rgba(124,58,237,0) 55%),' +
            'radial-gradient(120% 100% at 15% 100%, rgba(91,33,182,0.85) 0%, rgba(67,56,202,0.4) 45%, rgba(18,11,30,0) 75%),' +
            'radial-gradient(90% 70% at 50% 50%, rgba(109,40,217,0.35) 0%, rgba(18,11,30,0) 70%),' +
            'linear-gradient(160deg, #150d20 0%, #2a1458 45%, #4c1d95 100%)',
        }}
      />
      <div aria-hidden="true" className="absolute -right-40 -top-64 h-[820px] w-[820px] rounded-full border border-white/10" />
      <div aria-hidden="true" className="absolute -bottom-80 -left-52 h-[900px] w-[900px] rounded-full border border-white/[0.08]" />

      <main className="relative z-10 flex flex-1 items-center justify-center p-4 py-10 sm:p-8">
        <div className="w-full max-w-md overflow-hidden rounded-[28px] border border-violet-300/20 bg-[#0a0710]/90 shadow-[0_50px_140px_-30px_rgba(76,29,149,0.9),0_0_0_1px_rgba(167,139,250,0.08)] backdrop-blur-xl">
          <div className="relative bg-[#0d0a13] px-6 py-9 sm:px-9">
            <div className="pointer-events-none absolute right-[-30%] top-[-30%] h-64 w-64 rounded-full bg-violet-700/25 blur-[90px]" />
            <FlowerOfLife className="pointer-events-none absolute -bottom-14 -right-14 h-48 w-48 text-violet-500/[0.07]" />

            <div className="relative">
              {/* brand */}
              <a href="/" className="inline-flex items-center gap-2.5">
                <FlowerOfLife className="h-8 w-8 text-violet-300" />
                <span className="text-lg font-semibold tracking-tight text-white">yanzea</span>
              </a>

              {/* stepper */}
              <div className="mt-7 flex items-center gap-2" aria-hidden="true">
                {STEP_LABELS.map((s, i) => (
                  <div key={s.id} className="flex flex-1 items-center gap-2">
                    <div
                      className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[10.5px] font-semibold transition-colors ${
                        i < stepIndex
                          ? 'border-violet-400/60 bg-violet-500 text-white'
                          : i === stepIndex
                            ? 'border-violet-300 bg-violet-500/20 text-violet-100 shadow-[0_0_14px_rgba(139,92,246,0.5)]'
                            : 'border-white/15 bg-white/[0.04] text-white/35'
                      }`}
                    >
                      {i < stepIndex ? '✓' : i + 1}
                    </div>
                    {i < STEP_LABELS.length - 1 ? (
                      <div className={`h-px flex-1 ${i < stepIndex ? 'bg-violet-400/50' : 'bg-white/10'}`} />
                    ) : null}
                  </div>
                ))}
              </div>

              {step === 'email' ? (
                <>
                  <p className="mt-6 text-[11px] font-medium uppercase tracking-[0.28em] text-violet-300/80">
                    Reset Akses
                  </p>
                  <h1 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
                    Lupa kata sandi?
                  </h1>
                  <p className="mt-2 text-sm leading-relaxed text-white/55">
                    Masukkan email yang terdaftar — kami kirimkan kode verifikasi 6 digit secara otomatis.
                  </p>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      requestCode();
                    }}
                    noValidate
                    className="mt-7"
                  >
                    <label htmlFor="fp-email" className="text-xs font-medium text-white/70">
                      Alamat email
                    </label>
                    <div className="relative mt-1.5">
                      <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                      <Input
                        id="fp-email"
                        type="email"
                        autoComplete="email"
                        placeholder="you@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
                      />
                    </div>

                    {error ? (
                      <p role="alert" className="mt-4 rounded-lg border border-rose-400/20 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
                        {error}
                      </p>
                    ) : null}

                    <Button
                      type="submit"
                      disabled={loading}
                      className="mt-6 h-12 w-full rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-purple-500 text-sm font-semibold text-white shadow-[0_10px_40px_-8px_rgba(139,92,246,0.65)] transition-all hover:brightness-110 disabled:opacity-60"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" /> Mengirim kode…
                        </>
                      ) : (
                        <>
                          Kirim Kode Verifikasi <ArrowRight className="h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </form>
                </>
              ) : null}

              {step === 'verify' ? (
                <>
                  <p className="mt-6 text-[11px] font-medium uppercase tracking-[0.28em] text-violet-300/80">
                    Verifikasi
                  </p>
                  <h1 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
                    Cek emailmu
                  </h1>
                  <p className="mt-2 text-sm leading-relaxed text-white/55">
                    Kami mengirim kode verifikasi ke <span className="text-violet-200">{maskedEmail}</span>.
                    Kode berlaku 10 menit.
                  </p>

                  {/* kotak masuk simulasi — hanya muncul tanpa penyedia email */}
                  {previewCode ? (
                    <div className="mt-5 overflow-hidden rounded-2xl border border-emerald-300/25 bg-emerald-500/[0.07]">
                      <div className="flex items-center justify-between border-b border-emerald-300/15 px-4 py-2">
                        <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-200/90">
                          Kotak Masuk — Simulasi
                        </span>
                        <span className="rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-200">
                          mode pengembangan
                        </span>
                      </div>
                      <div className="px-4 py-3">
                        <p className="text-[11px] text-white/45">
                          Dari: <span className="text-white/70">Yanzea &lt;noreply@splettify.co.id&gt;</span>
                        </p>
                        <p className="text-[12px] font-medium text-white/85">
                          Kode reset kata sandi Yanzea
                        </p>
                        <div className="mt-2.5 flex items-center gap-2">
                          <span className="rounded-lg border border-emerald-300/30 bg-black/30 px-3 py-1.5 font-mono text-lg tracking-[0.35em] text-emerald-200">
                            {previewCode}
                          </span>
                          <button
                            type="button"
                            onClick={() => setCode(previewCode)}
                            className="rounded-lg border border-emerald-300/25 bg-emerald-500/10 px-2.5 py-1.5 text-[11px] font-medium text-emerald-200 transition-colors hover:bg-emerald-500/20"
                          >
                            Isi kode otomatis
                          </button>
                        </div>
                        <p className="mt-2.5 text-[10.5px] leading-relaxed text-white/35">
                          Dengan environment <span className="font-mono">RESEND_API_KEY</span> aktif, kode dikirim
                          ke email sungguhan dan kotak simulasi ini tidak muncul.
                        </p>
                      </div>
                    </div>
                  ) : null}

                  <form onSubmit={submitReset} noValidate className="mt-6">
                    <label htmlFor="fp-code" className="text-xs font-medium text-white/70">
                      Kode verifikasi
                    </label>
                    <div className="relative mt-1.5">
                      <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                      <Input
                        id="fp-code"
                        inputMode="numeric"
                        autoComplete="one-time-code"
                        maxLength={6}
                        placeholder="••••••"
                        value={code}
                        onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 font-mono text-lg tracking-[0.3em] text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
                      />
                    </div>

                    <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div>
                        <label htmlFor="fp-password" className="block text-xs font-medium text-white/70">
                          Kata sandi baru
                        </label>
                        <div className="relative mt-1.5">
                          <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                          <Input
                            id="fp-password"
                            type={showPassword ? 'text' : 'password'}
                            autoComplete="new-password"
                            placeholder="Min. 6 karakter"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 pr-11 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword((v) => !v)}
                            aria-label={showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
                            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-white/40 transition-colors hover:text-white/80"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>
                      <div>
                        <label htmlFor="fp-confirm" className="block text-xs font-medium text-white/70">
                          Konfirmasi sandi
                        </label>
                        <div className="relative mt-1.5">
                          <ShieldCheck className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                          <Input
                            id="fp-confirm"
                            type={showPassword ? 'text' : 'password'}
                            autoComplete="new-password"
                            placeholder="Ulangi kata sandi"
                            value={confirm}
                            onChange={(e) => setConfirm(e.target.value)}
                            className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
                          />
                        </div>
                      </div>
                    </div>

                    {error ? (
                      <p role="alert" className="mt-4 rounded-lg border border-rose-400/20 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
                        {error}
                      </p>
                    ) : null}

                    <Button
                      type="submit"
                      disabled={loading}
                      className="mt-6 h-12 w-full rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-purple-500 text-sm font-semibold text-white shadow-[0_10px_40px_-8px_rgba(139,92,246,0.65)] transition-all hover:brightness-110 disabled:opacity-60"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" /> Menyimpan…
                        </>
                      ) : (
                        <>
                          Ubah Kata Sandi &amp; Masuk <ArrowRight className="h-4 w-4" />
                        </>
                      )}
                    </Button>

                    <div className="mt-4 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setStep('email')}
                        className="inline-flex items-center gap-1.5 text-xs text-white/50 transition-colors hover:text-white/80"
                      >
                        <ArrowLeft className="h-3.5 w-3.5" /> Ganti email
                      </button>
                      <button
                        type="button"
                        disabled={resendIn > 0 || loading}
                        onClick={() => requestCode()}
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-violet-300 transition-colors hover:text-violet-200 disabled:cursor-not-allowed disabled:text-white/30"
                      >
                        <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
                        {resendIn > 0 ? `Kirim ulang kode (${resendIn}s)` : 'Kirim ulang kode'}
                      </button>
                    </div>
                  </form>
                </>
              ) : null}

              {step === 'done' ? (
                <div className="mt-8 flex flex-col items-center pb-2 text-center">
                  <div className="animate-floaty relative">
                    <div className="absolute inset-0 -z-10 rounded-full bg-emerald-500/25 blur-[50px]" />
                    <div className="flex h-16 w-16 items-center justify-center rounded-full border border-emerald-300/40 bg-emerald-500/15">
                      <ShieldCheck className="h-8 w-8 text-emerald-300" />
                    </div>
                  </div>
                  <h1 className="mt-5 text-2xl font-semibold tracking-tight text-white">
                    Kata sandi diperbarui
                  </h1>
                  <p className="mt-2 max-w-xs text-sm leading-relaxed text-white/55">
                    Kamu sudah otomatis masuk. Mengalihkan ke obrolan…
                  </p>
                  <Button
                    onClick={() => {
                      window.location.href = '/';
                    }}
                    className="mt-6 h-11 rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-purple-500 px-6 text-sm font-semibold text-white shadow-[0_10px_40px_-8px_rgba(139,92,246,0.65)] hover:brightness-110"
                  >
                    Masuk sekarang <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              ) : null}

              <p className="mt-7 text-center text-sm text-white/50">
                Sudah ingat kata sandimu?{' '}
                <a href="/" className="font-medium text-violet-300 transition-colors hover:text-violet-200">
                  Kembali masuk
                </a>
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="relative z-10 mt-auto pb-6 text-center">
        <p className="text-xs tracking-wide text-white/45">
          © 2026 Yanzea · splettify.co.id — AI Agent Otomasi, IIoT &amp; IoT
        </p>
      </footer>
    </div>
  );
}
