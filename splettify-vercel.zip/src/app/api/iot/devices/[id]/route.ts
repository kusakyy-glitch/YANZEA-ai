import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

/** PATCH /api/iot/devices/[id] — ubah status aktuator (nyala/mati). Khusus admin. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }
  if (user.role !== 'ADMIN') {
    return NextResponse.json(
      { ok: false, message: 'Dashboard IoT hanya dapat diakses oleh admin.' },
      { status: 403 }
    );
  }
  const { id } = await params;

  let body: { isOn?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Format permintaan tidak valid.' }, { status: 400 });
  }

  if (typeof body.isOn !== 'boolean') {
    return NextResponse.json({ ok: false, message: 'Status isOn wajib boolean.' }, { status: 400 });
  }

  const device = await db.device.findFirst({ where: { id, userId: user.id, kind: 'actuator' } });
  if (!device) {
    return NextResponse.json({ ok: false, message: 'Aktuator tidak ditemukan.' }, { status: 404 });
  }

  const updated = await db.device.update({ where: { id: device.id }, data: { isOn: body.isOn } });
  return NextResponse.json({ ok: true, device: updated });
}
