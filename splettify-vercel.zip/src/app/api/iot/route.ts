import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

/* ------------------------------------------------------------------ */
/*  Fleet bawaan — perangkat disemai otomatis saat pertama kali        */
/* ------------------------------------------------------------------ */

const SENSOR_SEED = [
  { name: 'Suhu Lantai Produksi', metric: 'suhu', unit: '°C', zone: 'Lantai Produksi', baseValue: 27.5, amplitude: 3.5 },
  { name: 'Kelembapan Gudang', metric: 'kelembapan', unit: '%', zone: 'Gudang', baseValue: 62, amplitude: 8 },
  { name: 'Tekanan Hidrolik', metric: 'tekanan', unit: 'bar', zone: 'Lantai Produksi', baseValue: 5.2, amplitude: 1.2 },
  { name: 'Arus Motor Utama', metric: 'arus', unit: 'A', zone: 'Ruang Panel', baseValue: 12, amplitude: 2.5 },
  { name: 'Level Tangki Air', metric: 'level', unit: '%', zone: 'Utilitas', baseValue: 62, amplitude: 28 },
  { name: 'Intensitas Cahaya', metric: 'cahaya', unit: 'lux', zone: 'Gudang', baseValue: 350, amplitude: 250 },
];

const ACTUATOR_SEED = [
  { name: 'Kipas Pendingin', zone: 'Lantai Produksi' },
  { name: 'Pompa Air', zone: 'Utilitas' },
  { name: 'Conveyor Line A', zone: 'Lantai Produksi' },
  { name: 'Lampu Gudang', zone: 'Gudang' },
  { name: 'Alarm Industri', zone: 'Ruang Panel' },
];

/** [nama, indeksSensor, operator, threshold, indeksAktuator, action] */
const RULE_SEED: [string, number, string, number, number, boolean][] = [
  ['Pendingin Otomatis', 0, '>', 28, 0, true], // Suhu > 28 °C  → Kipas Nyala
  ['Pendingin Otomatis', 0, '<', 26, 0, false], // Suhu < 26 °C  → Kipas Mati
  ['Isi Tangki Otomatis', 4, '<', 40, 1, true], // Level < 40 %  → Pompa Nyala
  ['Isi Tangki Otomatis', 4, '>', 85, 1, false], // Level > 85 % → Pompa Mati
  ['Lampu Otomatis', 5, '<', 200, 3, true], // Cahaya < 200 lux  → Lampu Nyala
  ['Lampu Otomatis', 5, '>', 450, 3, false], // Cahaya > 450 lux → Lampu Mati
  ['Alarm Beban Berlebih', 3, '>', 14, 4, true], // Arus > 14 A  → Alarm Nyala
  ['Alarm Beban Berlebih', 3, '<', 12, 4, false], // Arus < 12 A → Alarm Mati
];

async function seedFleet(userId: string) {
  const sensors = [];
  for (const s of SENSOR_SEED) {
    sensors.push(
      await db.device.create({
        data: { userId, name: s.name, kind: 'sensor', metric: s.metric, unit: s.unit, zone: s.zone, baseValue: s.baseValue, amplitude: s.amplitude },
      })
    );
  }
  const actuators = [];
  for (const a of ACTUATOR_SEED) {
    actuators.push(
      await db.device.create({
        data: { userId, name: a.name, kind: 'actuator', zone: a.zone },
      })
    );
  }
  for (const [name, si, operator, threshold, ai, action] of RULE_SEED) {
    await db.automationRule.create({
      data: { userId, name, sensorId: sensors[si].id, operator, threshold, actuatorId: actuators[ai].id, action },
    });
  }
}

const ruleInclude = {
  sensor: { select: { id: true, name: true, unit: true, metric: true } },
  actuator: { select: { id: true, name: true } },
};

/** GET /api/iot — daftar perangkat + aturan otomasi milik user (seed saat kosong). Khusus admin. */
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }
  if (user.role !== 'ADMIN') {
    return NextResponse.json(
      { ok: false, message: 'Dashboard IoT hanya dapat diakses oleh admin.' },
      { status: 403 }
    );
  }

  const count = await db.device.count({ where: { userId: user.id } });
  if (count === 0) {
    await seedFleet(user.id);
  }

  const [devices, rules] = await Promise.all([
    db.device.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'asc' } }),
    db.automationRule.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'asc' },
      include: ruleInclude,
    }),
  ]);

  return NextResponse.json({ ok: true, devices, rules });
}

/** POST /api/iot — buat aturan otomasi baru. Khusus admin. */
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }
  if (user.role !== 'ADMIN') {
    return NextResponse.json(
      { ok: false, message: 'Dashboard IoT hanya dapat diakses oleh admin.' },
      { status: 403 }
    );
  }

  let body: { sensorId?: string; operator?: string; threshold?: number; actuatorId?: string; action?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Format permintaan tidak valid.' }, { status: 400 });
  }

  const { sensorId, operator, actuatorId } = body;
  const threshold = Number(body.threshold);
  const action = body.action !== false;

  if (!sensorId || !actuatorId) {
    return NextResponse.json({ ok: false, message: 'Sensor dan aktuator wajib dipilih.' }, { status: 400 });
  }
  if (operator !== '>' && operator !== '<') {
    return NextResponse.json({ ok: false, message: 'Operator harus lebih dari (>) atau kurang dari (<).' }, { status: 400 });
  }
  if (!Number.isFinite(threshold)) {
    return NextResponse.json({ ok: false, message: 'Nilai ambang batas harus berupa angka.' }, { status: 400 });
  }

  const [sensor, actuator] = await Promise.all([
    db.device.findFirst({ where: { id: sensorId, userId: user.id, kind: 'sensor' } }),
    db.device.findFirst({ where: { id: actuatorId, userId: user.id, kind: 'actuator' } }),
  ]);
  if (!sensor || !actuator) {
    return NextResponse.json({ ok: false, message: 'Sensor atau aktuator tidak ditemukan.' }, { status: 404 });
  }

  const ruleCount = await db.automationRule.count({ where: { userId: user.id } });
  if (ruleCount >= 20) {
    return NextResponse.json({ ok: false, message: 'Maksimal 20 aturan otomasi. Hapus yang tidak terpakai dulu.' }, { status: 400 });
  }

  const rule = await db.automationRule.create({
    data: {
      userId: user.id,
      name: `Otomasi ${actuator.name}`,
      sensorId: sensor.id,
      operator,
      threshold,
      actuatorId: actuator.id,
      action,
    },
    include: ruleInclude,
  });

  return NextResponse.json({ ok: true, rule });
}
