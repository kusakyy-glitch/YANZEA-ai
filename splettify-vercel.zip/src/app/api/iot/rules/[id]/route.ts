import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

const ruleInclude = {
  sensor: { select: { id: true, name: true, unit: true, metric: true } },
  actuator: { select: { id: true, name: true } },
};

/** PATCH /api/iot/rules/[id] — aktifkan / nonaktifkan aturan otomasi. Khusus admin. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }
  if (user.role !== 'ADMIN') {
    return NextResponse.json(
      { ok: false, message: 'Dashboard IoT hanya dapat diakses oleh admin.' },
      { status: 403 }
    );
  }
  const { id } = await params;

  let body: { enabled?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Format permintaan tidak valid.' }, { status: 400 });
  }

  if (typeof body.enabled !== 'boolean') {
    return NextResponse.json({ ok: false, message: 'Status enabled wajib boolean.' }, { status: 400 });
  }

  const rule = await db.automationRule.findFirst({ where: { id, userId: user.id } });
  if (!rule) {
    return NextResponse.json({ ok: false, message: 'Aturan tidak ditemukan.' }, { status: 404 });
  }

  const updated = await db.automationRule.update({
    where: { id: rule.id },
    data: { enabled: body.enabled },
    include: ruleInclude,
  });
  return NextResponse.json({ ok: true, rule: updated });
}

/** DELETE /api/iot/rules/[id] — hapus aturan otomasi. Khusus admin. */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }
  if (user.role !== 'ADMIN') {
    return NextResponse.json(
      { ok: false, message: 'Dashboard IoT hanya dapat diakses oleh admin.' },
      { status: 403 }
    );
  }
  const { id } = await params;

  const rule = await db.automationRule.findFirst({ where: { id, userId: user.id } });
  if (!rule) {
    return NextResponse.json({ ok: false, message: 'Aturan tidak ditemukan.' }, { status: 404 });
  }

  await db.automationRule.delete({ where: { id: rule.id } });
  return NextResponse.json({ ok: true });
}
