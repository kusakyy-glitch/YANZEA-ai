import { NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

const SYSTEM_PROMPT = `You are Splettify — a smart, warm, and efficient AI agent inside the Splettify web app. You are a specialist in automation systems (sistem otomasi), IIoT (Industrial Internet of Things), and IoT (Internet of Things).

Your expertise:
- Industrial automation: PLC (Siemens, Allen-Bradley, Omron, Mitsubishi), SCADA, HMI, DCS, ladder logic and function blocks, control loops, relays, contactors, VFD/inverter.
- IIoT: industrial sensors and telemetry, predictive maintenance, OEE, edge devices and gateways, protocols (MQTT, Modbus RTU/TCP, OPC UA, Profinet, LoRaWAN), monitoring dashboards.
- IoT: ESP32/ESP8266, Arduino, Raspberry Pi, smart home and smart building, common sensors (temperature, humidity, pressure, level, flow, motion, light), actuators (relay, motor, solenoid, valve), firmware basics (Arduino C++, MicroPython), cloud dashboards.
- You also handle ANY general request (writing, ideas, planning, summarizing, everyday advice) like a capable personal assistant.

Your personality: friendly, upbeat, and genuinely helpful. Be concrete and actionable: give real steps, component and wiring suggestions, and short code snippets (Arduino C++, Python, or ladder pseudo-code) when relevant. If a request is ambiguous, make a reasonable assumption, state it briefly, and deliver.

Formatting: use Markdown when it helps (short paragraphs, bold key ideas, lists, code blocks). Keep responses concise by default (under ~250 words) unless the user asks for depth.

IMPORTANT: Always respond in the same language the user writes in (e.g., Indonesian if they write Indonesian, English if they write English). If the language is ambiguous, default to Indonesian (Bahasa Indonesia).`;

const HISTORY_LIMIT = 20;

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }

  let body: { conversationId?: string; message?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Format permintaan tidak valid.' }, { status: 400 });
  }

  const content = (body.message ?? '').trim();
  if (!content) {
    return NextResponse.json({ ok: false, message: 'Pesan tidak boleh kosong.' }, { status: 400 });
  }
  if (content.length > 4000) {
    return NextResponse.json({ ok: false, message: 'Pesan terlalu panjang (maksimal 4000 karakter).' }, { status: 400 });
  }

  // Find or create the conversation (owned by the user)
  let conversation = body.conversationId
    ? await db.conversation.findFirst({ where: { id: body.conversationId, userId: user.id } })
    : null;

  if (!conversation) {
    const title = content.length > 48 ? `${content.slice(0, 48).trimEnd()}…` : content;
    conversation = await db.conversation.create({
      data: { userId: user.id, title },
    });
  }

  // Persist the user's message
  const userMessage = await db.message.create({
    data: { role: 'user', content, conversationId: conversation.id },
  });

  // Build history for the model (most recent messages, in order)
  const history = await db.message.findMany({
    where: { conversationId: conversation.id },
    orderBy: { createdAt: 'desc' },
    take: HISTORY_LIMIT,
    select: { role: true, content: true },
  });
  history.reverse();

  // Ask the model
  let replyText: string;
  try {
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: SYSTEM_PROMPT },
        ...history.map((m) => ({
          role: m.role === 'assistant' ? ('assistant' as const) : ('user' as const),
          content: m.content,
        })),
      ],
      thinking: { type: 'disabled' },
    });
    replyText = completion.choices[0]?.message?.content?.trim() || '';
  } catch (err) {
    console.error('LLM error:', err);
    replyText = '';
  }

  if (!replyText) {
    replyText =
      'Maaf, aku sedang tidak bisa menjangkau sistemku saat ini. Coba kirim pesan itu lagi sebentar lagi. ✨';
  }

  const assistantMessage = await db.message.create({
    data: { role: 'assistant', content: replyText, conversationId: conversation.id },
  });

  // Touch conversation so it sorts to the top
  await db.conversation.update({ where: { id: conversation.id }, data: { updatedAt: new Date() } });

  return NextResponse.json({
    ok: true,
    conversationId: conversation.id,
    conversationTitle: conversation.title,
    userMessage: { id: userMessage.id, role: 'user', content: userMessage.content, createdAt: userMessage.createdAt },
    assistantMessage: {
      id: assistantMessage.id,
      role: 'assistant',
      content: assistantMessage.content,
      createdAt: assistantMessage.createdAt,
    },
  });
}
