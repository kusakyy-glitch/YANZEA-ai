import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/admin/overview
 * Data lengkap IIoT / Otomasi / IoT + pengguna. Hanya untuk role ADMIN.
 */
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Silakan masuk terlebih dahulu.' }, { status: 401 });
  }
  if (user.role !== 'ADMIN') {
    return NextResponse.json(
      { ok: false, message: 'Akses ditolak. Halaman ini khusus admin.' },
      { status: 403 }
    );
  }

  const [users, devices, rules, totalConversations, totalMessages] = await Promise.all([
    db.user.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        emailVerified: true,
        googleId: true,
        createdAt: true,
        _count: { select: { conversations: true, devices: true } },
      },
    }),
    db.device.findMany({
      orderBy: { createdAt: 'asc' },
      include: { user: { select: { name: true, email: true } } },
    }),
    db.automationRule.findMany({
      orderBy: { createdAt: 'asc' },
      include: {
        sensor: { select: { id: true, name: true, unit: true } },
        actuator: { select: { id: true, name: true } },
        user: { select: { name: true, email: true } },
      },
    }),
    db.conversation.count(),
    db.message.count(),
  ]);

  const stats = {
    totalUsers: users.length,
    verifiedUsers: users.filter((u) => u.emailVerified).length,
    googleUsers: users.filter((u) => !!u.googleId).length,
    totalDevices: devices.length,
    sensors: devices.filter((d) => d.kind === 'sensor').length,
    actuators: devices.filter((d) => d.kind === 'actuator').length,
    actuatorsOn: devices.filter((d) => d.kind === 'actuator' && d.isOn).length,
    totalRules: rules.length,
    activeRules: rules.filter((r) => r.enabled).length,
    totalConversations,
    totalMessages,
    googleOAuthConfigured: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
    mailProviderConfigured: Boolean(process.env.RESEND_API_KEY),
  };

  return NextResponse.json({ ok: true, stats, users, devices, rules });
}
