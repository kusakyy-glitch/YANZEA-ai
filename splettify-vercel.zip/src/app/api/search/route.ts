import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

const HISTORY_LIMIT = 10;
const RESULT_LIMIT = 20;

/** Riwayat terbaru tanpa duplikat kata kunci (yang paling baru menang). */
async function recentHistory(userId: string) {
  const rows = await db.searchHistory.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    take: 60,
  });
  const seen = new Set<string>();
  const unique: typeof rows = [];
  for (const row of rows) {
    const key = row.query.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(row);
    if (unique.length >= HISTORY_LIMIT) break;
  }
  return unique;
}

/** GET /api/search — riwayat pencarian milik user yang sedang masuk. */
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Silakan masuk terlebih dahulu.' }, { status: 401 });
  }
  const history = await recentHistory(user.id);
  return NextResponse.json({ ok: true, history });
}

/**
 * POST /api/search — simpan kata kunci ke riwayat (otomatis, per user)
 * lalu cari di judul percakapan & isi pesan milik user tersebut.
 */
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Silakan masuk terlebih dahulu.' }, { status: 401 });
  }

  let body: { query?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Format permintaan tidak valid.' }, { status: 400 });
  }

  const query = (body.query ?? '').trim().slice(0, 120);
  if (!query) {
    return NextResponse.json({ ok: false, message: 'Kata kunci pencarian tidak boleh kosong.' }, { status: 400 });
  }

  /* auto simpan ke database — setiap user punya riwayatnya sendiri */
  await db.searchHistory.create({ data: { userId: user.id, query } });

  const [conversations, messages, history] = await Promise.all([
    db.conversation.findMany({
      where: { userId: user.id, title: { contains: query } },
      orderBy: { updatedAt: 'desc' },
      take: 10,
      select: { id: true, title: true, updatedAt: true },
    }),
    db.message.findMany({
      where: {
        content: { contains: query },
        conversation: { userId: user.id },
      },
      orderBy: { createdAt: 'desc' },
      take: RESULT_LIMIT,
      select: {
        id: true,
        role: true,
        content: true,
        createdAt: true,
        conversation: { select: { id: true, title: true } },
      },
    }),
    recentHistory(user.id),
  ]);

  return NextResponse.json({ ok: true, query, conversations, messages, history });
}

/** DELETE /api/search?id=… — hapus satu entri, tanpa ?id= → hapus seluruh riwayat user. */
export async function DELETE(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Silakan masuk terlebih dahulu.' }, { status: 401 });
  }

  const id = new URL(req.url).searchParams.get('id');
  if (id) {
    const row = await db.searchHistory.findFirst({ where: { id, userId: user.id } });
    if (!row) {
      return NextResponse.json({ ok: false, message: 'Entri riwayat tidak ditemukan.' }, { status: 404 });
    }
    await db.searchHistory.delete({ where: { id: row.id } });
  } else {
    await db.searchHistory.deleteMany({ where: { userId: user.id } });
  }

  const history = await recentHistory(user.id);
  return NextResponse.json({ ok: true, history });
}
