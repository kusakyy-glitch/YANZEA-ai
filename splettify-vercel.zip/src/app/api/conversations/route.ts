import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

/** List the signed-in user's conversations (newest first). */
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }

  const conversations = await db.conversation.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: 'desc' },
    select: { id: true, title: true, createdAt: true, updatedAt: true },
  });
  return NextResponse.json({ ok: true, conversations });
}

/** Create a new empty conversation. */
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }

  let body: { title?: string } = {};
  try {
    body = await req.json();
  } catch {
    /* body optional */
  }

  const conversation = await db.conversation.create({
    data: {
      userId: user.id,
      title: (body.title ?? '').trim() || 'New conversation',
    },
  });
  return NextResponse.json({ ok: true, conversation });
}
