import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

/** Load one conversation with its messages (ownership enforced). */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }
  const { id } = await params;

  const conversation = await db.conversation.findFirst({
    where: { id, userId: user.id },
    include: {
      messages: { orderBy: { createdAt: 'asc' }, select: { id: true, role: true, content: true, createdAt: true } },
    },
  });
  if (!conversation) {
    return NextResponse.json({ ok: false, message: 'Percakapan tidak ditemukan.' }, { status: 404 });
  }
  return NextResponse.json({ ok: true, conversation });
}

/** Delete a conversation (messages cascade). */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Kamu belum masuk.' }, { status: 401 });
  }
  const { id } = await params;

  const conversation = await db.conversation.findFirst({ where: { id, userId: user.id } });
  if (!conversation) {
    return NextResponse.json({ ok: false, message: 'Percakapan tidak ditemukan.' }, { status: 404 });
  }
  await db.conversation.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
