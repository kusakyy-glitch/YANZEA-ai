import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { sendCodeEmail } from '@/lib/mailer';
import { CODE_TTL_MS, MAX_CODES_PER_WINDOW, SEND_WINDOW_MS, generateCode, hashCode } from '@/lib/verification';

export async function POST(req: Request) {
  let body: { email?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Invalid request body.' }, { status: 400 });
  }

  const email = (body.email ?? '').trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.json({ ok: false, message: 'Masukkan alamat email yang valid.' }, { status: 400 });
  }

  const user = await db.user.findUnique({ where: { email } });

  if (!user) {
    // Pada mode simulasi (tanpa provider email) kita beri tahu secara eksplisit
    // agar alur mudah diuji. Dengan provider aktif, respons selalu generik
    // (anti-enumerasi) persis seperti sukses.
    const usingProvider = Boolean(process.env.RESEND_API_KEY);
    if (usingProvider) {
      return NextResponse.json({
        ok: true,
        message: 'Jika email terdaftar, kode reset telah dikirim. Periksa kotak masukmu.',
      });
    }
    return NextResponse.json(
      { ok: false, exists: false, message: 'Email tidak terdaftar. Coba email lain atau buat akun baru.' },
      { status: 404 }
    );
  }

  // Anti-spam: maksimal N kode per email dalam jendela waktu 10 menit.
  const recentCount = await db.passwordResetCode.count({
    where: { userId: user.id, createdAt: { gt: new Date(Date.now() - SEND_WINDOW_MS) } },
  });
  if (recentCount >= MAX_CODES_PER_WINDOW) {
    return NextResponse.json(
      { ok: false, message: 'Terlalu banyak permintaan kode. Coba lagi dalam beberapa menit.' },
      { status: 429 }
    );
  }

  // Kode acak 6 digit yang aman secara kriptografis.
  const code = generateCode();

  // Batalkan kode lama yang masih aktif.
  await db.passwordResetCode.updateMany({
    where: { userId: user.id, usedAt: null },
    data: { usedAt: new Date() },
  });

  await db.passwordResetCode.create({
    data: {
      userId: user.id,
      codeHash: hashCode(code),
      expiresAt: new Date(Date.now() + CODE_TTL_MS),
    },
  });

  const mail = await sendCodeEmail(user.email, user.name, code, 'reset');

  return NextResponse.json({
    ok: true,
    message: `Kode reset dikirim ke ${user.email.replace(/^(.).+(@.*)$/, '$1•••$2')}. Berlaku 10 menit.`,
    delivered: mail.delivered,
    // Hanya terisi pada mode simulasi tanpa provider email.
    previewCode: mail.previewCode,
  });
}
