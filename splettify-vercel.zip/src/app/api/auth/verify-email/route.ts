import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createSession, publicUser } from '@/lib/auth';
import { sendCodeEmail } from '@/lib/mailer';
import {
  CODE_TTL_MS,
  MAX_CODE_ATTEMPTS,
  MAX_CODES_PER_WINDOW,
  SEND_WINDOW_MS,
  generateCode,
  hashCode,
  safeEqual,
} from '@/lib/verification';

/**
 * POST /api/auth/verify-email
 *
 * - { email, code }                → verifikasi kode (menandai emailVerified, membuat sesi)
 * - { email, resend: true }        → kirim kode baru
 */
export async function POST(req: Request) {
  let body: { email?: string; code?: string; resend?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Invalid request body.' }, { status: 400 });
  }

  const email = (body.email ?? '').trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.json({ ok: false, message: 'Masukkan alamat email yang valid.' }, { status: 400 });
  }

  const user = await db.user.findUnique({ where: { email } });
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Email tidak terdaftar.' }, { status: 404 });
  }
  if (user.emailVerified) {
    return NextResponse.json({ ok: false, message: 'Email ini sudah terverifikasi. Silakan masuk.' }, { status: 400 });
  }

  /* ---------- kirim ulang kode ---------- */
  if (body.resend) {
    const recentCount = await db.emailVerificationCode.count({
      where: { userId: user.id, createdAt: { gt: new Date(Date.now() - SEND_WINDOW_MS) } },
    });
    if (recentCount >= MAX_CODES_PER_WINDOW) {
      return NextResponse.json(
        { ok: false, message: 'Terlalu banyak permintaan kode. Coba lagi dalam beberapa menit.' },
        { status: 429 }
      );
    }

    const code = generateCode();
    await db.emailVerificationCode.updateMany({
      where: { userId: user.id, usedAt: null },
      data: { usedAt: new Date() },
    });
    await db.emailVerificationCode.create({
      data: {
        userId: user.id,
        codeHash: hashCode(code),
        expiresAt: new Date(Date.now() + CODE_TTL_MS),
      },
    });
    const mail = await sendCodeEmail(user.email, user.name, code, 'verify');

    return NextResponse.json({
      ok: true,
      message: `Kode verifikasi baru dikirim ke ${user.email.replace(/^(.).+(@.*)$/, '$1•••$2')}.`,
      delivered: mail.delivered,
      previewCode: mail.previewCode,
    });
  }

  /* ---------- verifikasi kode ---------- */
  const code = (body.code ?? '').replace(/\D/g, '');
  if (code.length !== 6) {
    return NextResponse.json({ ok: false, message: 'Kode harus 6 digit angka.' }, { status: 400 });
  }

  const record = await db.emailVerificationCode.findFirst({
    where: { userId: user.id, usedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  });

  if (!record) {
    return NextResponse.json(
      { ok: false, message: 'Kode salah atau sudah kedaluwarsa. Minta kode baru.' },
      { status: 400 }
    );
  }

  if (record.attempts >= MAX_CODE_ATTEMPTS) {
    await db.emailVerificationCode.update({ where: { id: record.id }, data: { usedAt: new Date() } });
    return NextResponse.json(
      { ok: false, locked: true, message: 'Terlalu banyak percobaan. Minta kode baru ya.' },
      { status: 429 }
    );
  }

  if (!safeEqual(hashCode(code), record.codeHash)) {
    const attempts = record.attempts + 1;
    const locked = attempts >= MAX_CODE_ATTEMPTS;
    await db.emailVerificationCode.update({
      where: { id: record.id },
      data: { attempts, usedAt: locked ? new Date() : undefined },
    });
    return NextResponse.json(
      {
        ok: false,
        locked,
        message: locked
          ? 'Terlalu banyak percobaan. Minta kode baru ya.'
          : `Kode salah. Sisa percobaan: ${MAX_CODE_ATTEMPTS - attempts}.`,
      },
      { status: locked ? 429 : 400 }
    );
  }

  // Kode benar → verifikasi email, pakai kode, nonaktifkan sisa kode.
  await db.emailVerificationCode.update({ where: { id: record.id }, data: { usedAt: new Date() } });
  await db.emailVerificationCode.updateMany({
    where: { userId: user.id, id: { not: record.id }, usedAt: null },
    data: { usedAt: new Date() },
  });

  const verified = await db.user.update({
    where: { id: user.id },
    data: { emailVerified: true },
  });

  // Verifikasi sukses = langsung masuk ke aplikasi.
  await createSession(user.id);

  return NextResponse.json({
    ok: true,
    user: publicUser(verified),
    message: 'Email berhasil diverifikasi. Selamat datang di Yanzea!',
  });
}
