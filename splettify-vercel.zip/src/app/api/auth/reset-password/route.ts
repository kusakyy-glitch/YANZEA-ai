import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createSession, hashPassword, publicUser } from '@/lib/auth';
import { MAX_CODE_ATTEMPTS, hashCode, safeEqual } from '@/lib/verification';

export async function POST(req: Request) {
  let body: { email?: string; code?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Invalid request body.' }, { status: 400 });
  }

  const email = (body.email ?? '').trim().toLowerCase();
  const code = (body.code ?? '').replace(/\D/g, '');
  const password = body.password ?? '';

  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.json({ ok: false, message: 'Masukkan alamat email yang valid.' }, { status: 400 });
  }
  if (code.length !== 6) {
    return NextResponse.json({ ok: false, message: 'Kode harus 6 digit angka.' }, { status: 400 });
  }
  if (password.length < 6) {
    return NextResponse.json(
      { ok: false, message: 'Kata sandi baru minimal 6 karakter.' },
      { status: 400 }
    );
  }

  const user = await db.user.findUnique({ where: { email } });
  if (!user) {
    return NextResponse.json({ ok: false, message: 'Email tidak terdaftar.' }, { status: 404 });
  }

  const record = await db.passwordResetCode.findFirst({
    where: { userId: user.id, usedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  });

  if (!record) {
    return NextResponse.json(
      { ok: false, message: 'Kode salah atau sudah kedaluwarsa. Minta kode baru.' },
      { status: 400 }
    );
  }

  if (record.attempts >= MAX_CODE_ATTEMPTS) {
    await db.passwordResetCode.update({ where: { id: record.id }, data: { usedAt: new Date() } });
    return NextResponse.json(
      { ok: false, locked: true, message: 'Terlalu banyak percobaan. Minta kode baru ya.' },
      { status: 429 }
    );
  }

  if (!safeEqual(hashCode(code), record.codeHash)) {
    const attempts = record.attempts + 1;
    const locked = attempts >= MAX_CODE_ATTEMPTS;
    await db.passwordResetCode.update({
      where: { id: record.id },
      data: { attempts, usedAt: locked ? new Date() : undefined },
    });
    return NextResponse.json(
      {
        ok: false,
        locked,
        message: locked
          ? 'Terlalu banyak percobaan. Minta kode baru ya.'
          : `Kode salah. Sisa percobaan: ${MAX_CODE_ATTEMPTS - attempts}.`,
      },
      { status: locked ? 429 : 400 }
    );
  }

  // Kode benar: tandai terpakai (satu kali pakai) dan nonaktifkan sisa kode lain.
  await db.passwordResetCode.update({ where: { id: record.id }, data: { usedAt: new Date() } });
  await db.passwordResetCode.updateMany({
    where: { userId: user.id, id: { not: record.id }, usedAt: null },
    data: { usedAt: new Date() },
  });

  const updated = await db.user.update({
    where: { id: user.id },
    data: { passwordHash: hashPassword(password) },
  });

  // Langsung masukkan pengguna ke dalam sesi (auto-login setelah reset).
  await createSession(user.id);

  return NextResponse.json({
    ok: true,
    user: publicUser(updated),
    message: 'Kata sandi berhasil diperbarui.',
  });
}
