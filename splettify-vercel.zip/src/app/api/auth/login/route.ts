import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createSession, publicUser, verifyPassword } from '@/lib/auth';

export async function POST(req: Request) {
  let body: { email?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Invalid request body.' }, { status: 400 });
  }

  const email = (body.email ?? '').trim().toLowerCase();
  const password = body.password ?? '';

  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.json({ ok: false, message: 'Masukkan alamat email yang valid.' }, { status: 400 });
  }
  if (!password) {
    return NextResponse.json({ ok: false, message: 'Mohon masukkan kata sandimu.' }, { status: 400 });
  }

  const user = await db.user.findUnique({ where: { email } });
  // passwordHash null = akun yang dibuat lewat Google (tanpa kata sandi).
  if (!user || !user.passwordHash || !verifyPassword(password, user.passwordHash)) {
    return NextResponse.json(
      { ok: false, message: 'Email atau kata sandi salah.' },
      { status: 401 }
    );
  }

  // Akun email harus diverifikasi dulu sebelum bisa masuk.
  if (!user.emailVerified) {
    return NextResponse.json(
      {
        ok: false,
        needsVerification: true,
        message: 'Email belum diverifikasi. Masukkan kode verifikasi yang kami kirim ke emailmu.',
      },
      { status: 403 }
    );
  }

  await createSession(user.id);
  return NextResponse.json({ ok: true, user: publicUser(user) });
}
