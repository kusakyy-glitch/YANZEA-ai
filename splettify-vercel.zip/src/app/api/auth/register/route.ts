import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, publicUser } from '@/lib/auth';
import { sendCodeEmail } from '@/lib/mailer';
import { CODE_TTL_MS, generateCode, hashCode } from '@/lib/verification';

export async function POST(req: Request) {
  let body: { name?: string; email?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, message: 'Invalid request body.' }, { status: 400 });
  }

  const name = (body.name ?? '').trim();
  const email = (body.email ?? '').trim().toLowerCase();
  const password = body.password ?? '';

  if (name.length < 2) {
    return NextResponse.json({ ok: false, message: 'Mohon masukkan namamu.' }, { status: 400 });
  }
  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.json({ ok: false, message: 'Masukkan alamat email yang valid.' }, { status: 400 });
  }
  if (password.length < 6) {
    return NextResponse.json(
      { ok: false, message: 'Kata sandi minimal 6 karakter.' },
      { status: 400 }
    );
  }

  const existing = await db.user.findUnique({ where: { email } });
  if (existing) {
    return NextResponse.json(
      { ok: false, message: 'Akun dengan email ini sudah terdaftar. Coba masuk.' },
      { status: 409 }
    );
  }

  const user = await db.user.create({
    data: { name, email, passwordHash: hashPassword(password), emailVerified: false },
  });

  // Kirim kode verifikasi 6 digit ke email pendaftar.
  const code = generateCode();
  await db.emailVerificationCode.create({
    data: {
      userId: user.id,
      codeHash: hashCode(code),
      expiresAt: new Date(Date.now() + CODE_TTL_MS),
    },
  });
  const mail = await sendCodeEmail(user.email, user.name, code, 'verify');

  // Sesi belum dibuat — pengguna harus memasukkan kode verifikasi dulu.
  return NextResponse.json({
    ok: true,
    user: publicUser(user),
    message: 'Akun dibuat. Kami mengirim kode verifikasi ke emailmu.',
    verification: {
      delivered: mail.delivered,
      // Hanya terisi pada mode simulasi tanpa provider email.
      previewCode: mail.previewCode,
    },
  });
}
