import { NextResponse } from 'next/server';
import { randomBytes } from 'crypto';
import { cookies } from 'next/headers';

/**
 * GET /api/auth/google
 *
 * - Dengan GOOGLE_CLIENT_ID & GOOGLE_CLIENT_SECRET → mulai OAuth Google asli.
 * - Tanpa kredensial (mis. lingkungan pengembangan) → mode simulasi:
 *   pengunjung diarahkan ke halaman pemilih akun Google tiruan.
 */
export async function GET(req: Request) {
  const origin = new URL(req.url).origin;
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;

  if (clientId && clientSecret) {
    const state = randomBytes(16).toString('hex');
    const store = await cookies();
    store.set('g_state', state, {
      httpOnly: true,
      sameSite: 'lax',
      secure: false,
      path: '/',
      maxAge: 600,
    });

    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    authUrl.searchParams.set('client_id', clientId);
    authUrl.searchParams.set('redirect_uri', `${origin}/api/auth/google/callback`);
    authUrl.searchParams.set('response_type', 'code');
    authUrl.searchParams.set('scope', 'openid email profile');
    authUrl.searchParams.set('state', state);
    authUrl.searchParams.set('prompt', 'select_account');
    return NextResponse.redirect(authUrl.toString());
  }

  return NextResponse.redirect(`${origin}/api/auth/google/demo`);
}
