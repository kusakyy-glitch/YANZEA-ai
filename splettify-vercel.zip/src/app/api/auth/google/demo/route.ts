/**
 * GET /api/auth/google/demo
 *
 * Halaman simulasi pemilih akun Google — dipakai ketika kredensial OAuth
 * (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET) belum diatur. Meniru alur
 * accounts.google.com: pilih akun → otomatis daftar/masuk → kembali ke aplikasi.
 */
export async function GET(req: Request) {
  const origin = new URL(req.url).origin;

  const html = `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Pilih akun — Google</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: Roboto, Arial, "Helvetica Neue", sans-serif;
    background: #fff; color: #202124; min-height: 100vh;
    display: flex; align-items: center; justify-content: center; padding: 24px;
  }
  .card { width: 100%; max-width: 448px; border: 1px solid #dadce0; border-radius: 28px; padding: 44px 40px 36px; }
  .logo { display: flex; align-items: center; gap: 10px; margin-bottom: 18px; }
  .g-text { font-size: 21px; font-weight: 500; letter-spacing: -0.5px; }
  .g-blue { color: #4285f4; } .g-red { color: #ea4335; } .g-yellow { color: #fbbc05; } .g-green { color: #34a853; }
  h1 { font-size: 24px; font-weight: 400; margin-bottom: 8px; }
  .sub { font-size: 14px; color: #5f6368; margin-bottom: 26px; }
  .sub b { color: #202124; font-weight: 500; }
  .account {
    display: flex; align-items: center; gap: 14px; width: 100%;
    padding: 11px 12px; border: none; background: transparent; border-radius: 999px;
    cursor: pointer; text-align: left; font: inherit; text-decoration: none; color: inherit;
  }
  .account:hover { background: #f8f9fa; }
  .avatar {
    width: 34px; height: 34px; border-radius: 50%; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; font-weight: 500; color: #fff;
  }
  .meta { min-width: 0; }
  .name { font-size: 14px; color: #202124; }
  .email { font-size: 12.5px; color: #5f6368; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .divider { border-top: 1px solid #e8eaed; margin: 16px 0; }
  .other { font-size: 14px; color: #5f6368; margin-bottom: 12px; }
  .field { margin-bottom: 14px; }
  .field label { display: block; font-size: 12px; color: #5f6368; margin-bottom: 4px; }
  .field input {
    width: 100%; height: 42px; border: 1px solid #dadce0; border-radius: 8px;
    padding: 0 12px; font-size: 14px; font-family: inherit; color: #202124; outline: none;
  }
  .field input:focus { border-color: #1a73e8; box-shadow: 0 0 0 1px #1a73e8; }
  .actions { display: flex; justify-content: space-between; align-items: center; margin-top: 22px; }
  .back { font-size: 13.5px; font-weight: 500; color: #1a73e8; text-decoration: none; padding: 8px 4px; }
  .next {
    height: 38px; padding: 0 26px; border: none; border-radius: 999px; cursor: pointer;
    background: #1a73e8; color: #fff; font-size: 14px; font-weight: 500; font-family: inherit;
  }
  .next:hover { background: #1765cc; box-shadow: 0 1px 3px rgba(26,115,232,.4); }
  .badge {
    display: inline-block; margin-bottom: 20px; padding: 5px 12px; border-radius: 999px;
    background: #fef7e0; color: #b06000; font-size: 11.5px; font-weight: 500;
  }
  .hint { margin-top: 18px; font-size: 11.5px; line-height: 1.55; color: #80868b; }
  code { background: #f1f3f4; border-radius: 4px; padding: 1px 5px; font-size: 11px; }
</style>
</head>
<body>
  <main class="card">
    <span class="badge">Simulasi — mode pengembangan</span>
    <div class="logo">
      <svg width="26" height="26" viewBox="0 0 48 48" aria-hidden="true">
        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
      </svg>
      <span class="g-text"><span class="g-blue">G</span><span class="g-red">o</span><span class="g-yellow">o</span><span class="g-blue">g</span><span class="g-green">l</span><span class="g-red">e</span></span>
    </div>
    <h1>Pilih akun</h1>
    <p class="sub">untuk melanjutkan ke <b>Yanzea — AI Agent Otomasi, IIoT &amp; IoT</b></p>

    <a class="account" href="${origin}/api/auth/google/demo/complete?email=budi.santoso%40gmail.com&amp;name=Budi%20Santoso">
      <span class="avatar" style="background:#1a73e8;">B</span>
      <span class="meta"><span class="name">Budi Santoso</span><br/><span class="email">budi.santoso@gmail.com</span></span>
    </a>
    <a class="account" href="${origin}/api/auth/google/demo/complete?email=sari.dewi%40gmail.com&amp;name=Sari%20Dewi">
      <span class="avatar" style="background:#d93025;">S</span>
      <span class="meta"><span class="name">Sari Dewi</span><br/><span class="email">sari.dewi@gmail.com</span></span>
    </a>

    <div class="divider"></div>
    <p class="other">Gunakan akun lain</p>
    <form method="GET" action="${origin}/api/auth/google/demo/complete">
      <div class="field">
        <label for="email">Alamat email</label>
        <input id="email" name="email" type="email" required placeholder="nama@gmail.com" />
      </div>
      <div class="field">
        <label for="name">Nama (opsional)</label>
        <input id="name" name="name" type="text" placeholder="Nama lengkap" />
      </div>
      <div class="actions">
        <a class="back" href="/">Batal</a>
        <button class="next" type="submit">Lanjutkan</button>
      </div>
    </form>
    <p class="hint">
      Ini halaman simulasi agar alur &ldquo;Daftar dengan Google&rdquo; bisa dicoba tanpa kredensial OAuth.
      Untuk Google asli, atur environment <code>GOOGLE_CLIENT_ID</code> dan <code>GOOGLE_CLIENT_SECRET</code>,
      maka tombol Google akan otomatis memakai accounts.google.com sungguhan.
    </p>
  </main>
</body>
</html>`;

  return new Response(html, {
    headers: { 'Content-Type': 'text/html; charset=utf-8' },
  });
}
