import { NextResponse } from 'next/server';
import { createSession } from '@/lib/auth';
import { findOrCreateGoogleUser, prettyNameFromEmail } from '@/lib/oauth';

/**
 * GET /api/auth/google/demo/complete?email=...&name=...
 * Menyelesaikan alur Google simulasi: daftarkan (atau masukkan) akun,
 * buat sesi, lalu kembalikan ke aplikasi.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const email = (url.searchParams.get('email') ?? '').trim().toLowerCase();
  const rawName = (url.searchParams.get('name') ?? '').trim().slice(0, 60);

  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.redirect(`${url.origin}/api/auth/google/demo`);
  }

  const user = await findOrCreateGoogleUser({
    email,
    name: rawName || prettyNameFromEmail(email),
    googleId: `google:${email}`,
  });

  await createSession(user.id);
  return NextResponse.redirect(url.origin + '/');
}
