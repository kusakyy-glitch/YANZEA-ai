import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createSession } from '@/lib/auth';
import { findOrCreateGoogleUser, prettyNameFromEmail } from '@/lib/oauth';

/**
 * GET /api/auth/google/callback
 * Callback OAuth Google asli — aktif ketika GOOGLE_CLIENT_ID &
 * GOOGLE_CLIENT_SECRET tersedia (lihat /api/auth/google).
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const origin = url.origin;
  const fail = (reason: string) => {
    console.error('[google:callback]', reason);
    return NextResponse.redirect(`${origin}/api/auth/google/demo`);
  };

  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const store = await cookies();
  const savedState = store.get('g_state')?.value;

  if (!code || !state || !savedState || state !== savedState) {
    return fail('State OAuth tidak cocok atau kode hilang.');
  }
  store.delete('g_state');

  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID!,
        client_secret: process.env.GOOGLE_CLIENT_SECRET!,
        redirect_uri: `${origin}/api/auth/google/callback`,
        grant_type: 'authorization_code',
      }),
    });
    const tokens = (await tokenRes.json()) as { access_token?: string };
    if (!tokenRes.ok || !tokens.access_token) return fail('Penukaran token Google gagal.');

    const infoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    const info = (await infoRes.json()) as { sub?: string; email?: string; name?: string };
    if (!infoRes.ok || !info.email || !info.sub) return fail('Profil Google tidak dapat dibaca.');

    const user = await findOrCreateGoogleUser({
      email: info.email,
      name: info.name || prettyNameFromEmail(info.email),
      googleId: info.sub,
    });

    await createSession(user.id);
    return NextResponse.redirect(origin + '/');
  } catch (err) {
    return fail(`Kesalahan OAuth: ${err instanceof Error ? err.message : 'tidak diketahui'}`);
  }
}
