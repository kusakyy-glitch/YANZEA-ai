'use client';

import { useEffect, useState } from 'react';
import { Eye, EyeOff, KeyRound, Loader2, Lock, Mail, ArrowRight, RefreshCw, User, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import {
  FlowerOfLife,
  SparkBurst,
  HexStar,
  LotusRing,
  Triquetra,
  IconBadge,
} from '@/components/sacred-geometry';
import { WaveMoire } from '@/components/wave-moire';
import { ChatApp, type AppUser } from '@/components/chat-app';
import { IotDashboard } from '@/components/iot-dashboard';
import { AdminDashboard } from '@/components/admin-dashboard';

type AuthMode = 'login' | 'register';

/* ------------------------------------------------------------------ */
/*  Small building blocks                                              */
/* ------------------------------------------------------------------ */

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
      <path
        fill="#EA4335"
        d="M12 5.04c1.62 0 3.06.56 4.2 1.64l3.12-3.12C17.46 1.8 14.96.75 12 .75 7.62.75 3.84 3.27 2.04 6.86l3.66 2.84C6.55 7.02 9.03 5.04 12 5.04z"
      />
      <path
        fill="#4285F4"
        d="M23.25 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.32-5.17 3.32-8.82z"
      />
      <path
        fill="#FBBC05"
        d="M5.7 14.3c-.23-.69-.36-1.42-.36-2.18s.13-1.49.36-2.18L2.04 6.86C1.28 8.42.85 10.16.85 12s.43 3.58 1.19 5.14l3.66-2.84z"
      />
      <path
        fill="#34A853"
        d="M12 23.25c3.04 0 5.6-1 7.46-2.72l-3.86-3c-1.07.72-2.44 1.15-3.6 1.15-2.97 0-5.45-1.98-6.3-4.66l-3.66 2.84c1.8 3.59 5.58 6.39 9.96 6.39z"
      />
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden="true">
      <path d="M17.05 12.54c-.03-2.89 2.36-4.27 2.47-4.34-1.35-1.97-3.44-2.24-4.18-2.27-1.77-.18-3.47 1.05-4.37 1.05-.91 0-2.29-1.03-3.77-1-1.93.03-3.72 1.13-4.71 2.86-2.01 3.49-.51 8.66 1.45 11.49.96 1.39 2.1 2.95 3.6 2.89 1.45-.06 2-.94 3.75-.94s2.24.94 3.77.91c1.56-.03 2.55-1.42 3.5-2.81 1.1-1.61 1.55-3.17 1.58-3.25-.04-.02-3.03-1.16-3.09-4.59zM14.14 4.06c.8-.97 1.34-2.33 1.19-3.68-1.15.05-2.55.77-3.38 1.74-.74.85-1.4 2.23-1.22 3.55 1.29.1 2.6-.65 3.41-1.61z" />
    </svg>
  );
}

function ResultsRing() {
  const R = 26;
  const C = 2 * Math.PI * R;
  return (
    <div className="relative h-16 w-16">
      <svg viewBox="0 0 64 64" className="h-16 w-16 -rotate-90">
        <circle cx="32" cy="32" r={R} stroke="rgba(255,255,255,0.14)" strokeWidth="3" fill="none" />
        <circle
          cx="32"
          cy="32"
          r={R}
          stroke="#a78bfa"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${0.94 * C} ${C}`}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-sm font-semibold leading-none text-white">+99%</span>
        <span className="mt-0.5 text-[9px] leading-none text-white/50">Uptime</span>
      </div>
    </div>
  );
}

/** Floating glass feature card, as seen across the video */
function FloatCard({
  icon,
  title,
  sub,
  className = '',
  animClass = 'animate-floaty',
  animDelay = '0s',
}: {
  icon: React.ReactNode;
  title: string;
  sub?: string;
  className?: string;
  animClass?: string;
  animDelay?: string;
}) {
  return (
    <div
      className={`${animClass} absolute z-10 w-56 rounded-2xl border border-white/10 bg-white/[0.06] p-4 shadow-[0_18px_50px_-12px_rgba(0,0,0,0.65)] backdrop-blur-md ${className}`}
      style={{ animationDelay: animDelay }}
    >
      <IconBadge>{icon}</IconBadge>
      <p className="mt-3 text-[13px] font-medium leading-snug text-white/95">{title}</p>
      {sub ? <p className="mt-1.5 text-[11px] leading-relaxed text-white/50">{sub}</p> : null}
    </div>
  );
}

function PhotoCard({
  src,
  alt,
  badge,
  className = '',
  animClass = 'animate-floaty',
  animDelay = '0s',
}: {
  src: string;
  alt: string;
  badge: React.ReactNode;
  className?: string;
  animClass?: string;
  animDelay?: string;
}) {
  return (
    <div
      className={`${animClass} z-10 absolute ${className}`}
      style={{ animationDelay: animDelay }}
    >
      <div className="overflow-hidden rounded-2xl border border-white/15 shadow-[0_18px_50px_-12px_rgba(0,0,0,0.7)]">
        <img src={src} alt={alt} className="h-full w-full object-cover" />
      </div>
      <div className="absolute -left-2 -top-2 flex h-8 w-8 items-center justify-center rounded-full border border-white/20 bg-[#141018] text-violet-200 shadow-lg">
        {badge}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Email verification (setelah daftar / login akun belum verifikasi)  */
/* ------------------------------------------------------------------ */

function SimulatedInbox({ code, onUse }: { code: string; onUse?: (code: string) => void }) {
  return (
    <div className="mt-5 overflow-hidden rounded-2xl border border-emerald-300/25 bg-emerald-500/[0.07]">
      <div className="flex items-center justify-between border-b border-emerald-300/15 px-4 py-2">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-200/90">
          Kotak Masuk — Simulasi
        </span>
        <span className="rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-200">
          mode pengembangan
        </span>
      </div>
      <div className="px-4 py-3">
        <p className="text-[11px] text-white/45">
          Dari: <span className="text-white/70">Yanzea &lt;noreply@splettify.co.id&gt;</span>
        </p>
        <p className="text-[12px] font-medium text-white/85">Kode verifikasi akun Yanzea</p>
        <div className="mt-2.5 flex items-center gap-2">
          <span className="rounded-lg border border-emerald-300/30 bg-black/30 px-3 py-1.5 font-mono text-lg tracking-[0.35em] text-emerald-200">
            {code}
          </span>
          {onUse ? (
            <button
              type="button"
              onClick={() => onUse(code)}
              className="rounded-lg border border-emerald-300/25 bg-emerald-500/10 px-2.5 py-1.5 text-[11px] font-medium text-emerald-200 transition-colors hover:bg-emerald-500/20"
            >
              Isi kode otomatis
            </button>
          ) : null}
        </div>
        <p className="mt-2.5 text-[10.5px] leading-relaxed text-white/35">
          Dengan environment <span className="font-mono">RESEND_API_KEY</span> aktif, kode dikirim ke email
          sungguhan dan kotak simulasi ini tidak muncul.
        </p>
      </div>
    </div>
  );
}

function EmailVerifyPanel({
  email,
  initialPreviewCode,
  onVerified,
}: {
  email: string;
  initialPreviewCode: string | null;
  onVerified: (user: AppUser) => void;
}) {
  const { toast } = useToast();
  const [code, setCode] = useState('');
  const [preview, setPreview] = useState<string | null>(initialPreviewCode);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resendIn, setResendIn] = useState(60);

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  const masked = email.replace(/^(.).+(@.*)$/, '$1•••$2');

  async function resend() {
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, resend: true }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.message || 'Gagal mengirim ulang kode.');
        return;
      }
      setPreview(data.previewCode ?? null);
      setCode('');
      setResendIn(60);
      toast({
        title: data.delivered ? 'Kode verifikasi terkirim' : 'Kode verifikasi baru siap',
        description: data.message,
        className:
          'border-violet-300/25 bg-[#170f24] text-white shadow-[0_18px_50px_-12px_rgba(76,29,149,0.8)]',
      });
    } catch {
      setError('Koneksi bermasalah. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    if (code.length !== 6) {
      setError('Kode verifikasi harus 6 digit angka.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.message || 'Verifikasi gagal. Silakan coba lagi.');
        return;
      }
      onVerified(data.user);
    } catch {
      setError('Koneksi bermasalah. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <p className="mt-6 text-[11px] font-medium uppercase tracking-[0.28em] text-violet-300/80">
        Verifikasi
      </p>
      <h1 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
        Verifikasi emailmu
      </h1>
      <p className="mt-2 text-sm leading-relaxed text-white/55">
        Masukkan kode verifikasi yang dikirim ke{' '}
        <span className="text-violet-200">{masked}</span>. Kode berlaku 10 menit.
      </p>

      {preview ? <SimulatedInbox code={preview} onUse={(c) => setCode(c)} /> : null}

      <form onSubmit={submit} noValidate className="mt-6">
        <label htmlFor="vf-code" className="text-xs font-medium text-white/70">
          Kode verifikasi
        </label>
        <div className="relative mt-1.5">
          <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
          <Input
            id="vf-code"
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={6}
            placeholder="••••••"
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
            className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 font-mono text-lg tracking-[0.3em] text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
          />
        </div>

        {error ? (
          <p role="alert" className="mt-4 rounded-lg border border-rose-400/20 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
            {error}
          </p>
        ) : null}

        <Button
          type="submit"
          disabled={loading}
          className="mt-6 h-12 w-full rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-purple-500 text-sm font-semibold text-white shadow-[0_10px_40px_-8px_rgba(139,92,246,0.65)] transition-all hover:brightness-110 disabled:opacity-60"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Memeriksa…
            </>
          ) : (
            <>
              Verifikasi &amp; Masuk <ArrowRight className="h-4 w-4" />
            </>
          )}
        </Button>

        <button
          type="button"
          disabled={resendIn > 0 || loading}
          onClick={resend}
          className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-violet-300 transition-colors hover:text-violet-200 disabled:cursor-not-allowed disabled:text-white/30"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          {resendIn > 0 ? `Kirim ulang kode (${resendIn}s)` : 'Kirim ulang kode'}
        </button>
      </form>
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Illustration panel — recreates the video artwork                   */
/* ------------------------------------------------------------------ */

function IllustrationPanel() {
  return (
    <div
      aria-hidden="true"
      className="relative hidden min-h-[660px] flex-1 overflow-hidden border-r border-white/[0.07] bg-[#0a0710] lg:block"
    >
      {/* ambient glows */}
      <div className="absolute -left-24 bottom-[-15%] h-[420px] w-[420px] rounded-full bg-violet-700/35 blur-[120px]" />
      <div className="absolute right-[-12%] top-[-10%] h-[380px] w-[380px] rounded-full bg-purple-600/25 blur-[120px]" />
      <div className="absolute left-[30%] top-[35%] h-[300px] w-[300px] rounded-full bg-fuchsia-700/15 blur-[110px]" />

      {/* faint orbital rings, like the video backdrop */}
      <div className="absolute -left-40 top-1/2 h-[560px] w-[560px] -translate-y-1/2 rounded-full border border-white/[0.06]" />
      <div className="absolute -left-24 top-1/2 h-[380px] w-[380px] -translate-y-1/2 rounded-full border border-white/[0.05]" />
      <div className="absolute -right-32 -top-24 h-[360px] w-[360px] rounded-full border border-white/[0.06]" />

      {/* thin constellation lines */}
      <svg className="absolute inset-0 h-full w-full opacity-[0.16]" viewBox="0 0 560 660" preserveAspectRatio="none">
        <path d="M60 120 C 180 200, 340 150, 470 260" stroke="#a78bfa" strokeWidth="0.8" fill="none" />
        <path d="M40 520 C 160 430, 300 520, 520 400" stroke="#c4b5fd" strokeWidth="0.8" fill="none" />
        <path d="M120 640 C 240 560, 420 620, 540 540" stroke="#8b5cf6" strokeWidth="0.8" fill="none" />
      </svg>

      {/* headline behind the cards, as in the video */}
      <div className="absolute left-1/2 top-[44%] z-0 w-full -translate-x-1/2 -translate-y-1/2 text-center">
        <p className="text-[44px] font-semibold leading-[1.04] tracking-tight text-white">
          Automate
        </p>
        <p className="font-serif text-[52px] italic leading-[1.04] tracking-tight text-white/20">
          Everything
        </p>
      </div>

      {/* flowing wave lines, bottom area */}
      <WaveMoire className="absolute -right-8 bottom-[-4%] h-[46%] w-[88%]" opacity={0.5} />

      {/* floating results ring, cut into the corner like the video */}
      <div className="animate-floaty absolute -top-3 left-4 z-30 rounded-2xl border border-white/10 bg-white/[0.05] p-3 backdrop-blur-md" style={{ animationDelay: '1.2s' }}>
        <ResultsRing />
      </div>

      {/* floating feature cards */}
      <FloatCard
        icon={<SparkBurst className="h-5 w-5" />}
        title="Sistem Otomasi Cerdas"
        sub="Rancang logika kontrol PLC, SCADA, dan HMI bersama AI."
        className="left-[16%] top-[10%]"
        animDelay="0s"
      />
      <FloatCard
        icon={<HexStar className="h-5 w-5" />}
        title="IIoT Industri Real-Time"
        sub="Pantau mesin, sensor, dan lini produksi tanpa jeda."
        className="right-[2%] top-[20%]"
        animClass="animate-floaty2"
        animDelay="0.6s"
      />
      <FloatCard
        icon={<LotusRing className="h-5 w-5" />}
        title="IoT Terhubung Satu Dashboard"
        sub="Sensor, aktuator, dan data dalam satu layar."
        className="left-[6%] top-[46%]"
        animDelay="1s"
      />
      <FloatCard
        icon={<Triquetra className="h-5 w-5" />}
        title="Aturan Otomatis 24/7"
        sub="Sensor memicu aktuator — tanpa sentuhan tangan."
        className="bottom-[6%] right-[19%]"
        animClass="animate-floaty2"
        animDelay="1.5s"
      />

      {/* AI Assist pill */}
      <div className="animate-floaty absolute left-[44%] top-[52%] z-20 flex flex-col items-center gap-1.5 rounded-2xl bg-violet-500 px-4 py-3 shadow-[0_0_40px_rgba(139,92,246,0.55)]" style={{ animationDelay: '0.3s' }}>
        <IconBadge className="h-9 w-9 border-white/30 bg-white/10 text-white">
          <SparkBurst className="h-4 w-4" />
        </IconBadge>
        <span className="text-[10px] font-semibold tracking-wide text-white">AI Agent</span>
      </div>

      {/* people photo cards */}
      <PhotoCard
        src="/user-woman.png"
        alt="Anggota perempuan tertawa riang"
        badge={<SparkBurst className="h-4 w-4" />}
        className="bottom-[2%] left-[3%] h-44 w-40"
        animDelay="0.9s"
      />
      <PhotoCard
        src="/user-man.png"
        alt="Anggota pria tersenyum berkacamata"
        badge={<HexStar className="h-4 w-4" />}
        className="bottom-[24%] right-[2%] h-40 w-36"
        animClass="animate-floaty2"
        animDelay="0.2s"
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Login form panel                                                   */
/* ------------------------------------------------------------------ */

function LoginForm({
  onSwitch,
  onAuthed,
}: {
  onSwitch: () => void;
  onAuthed: (user: AppUser) => void;
}) {
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [verifyEmail, setVerifyEmail] = useState<string | null>(null);

  function goGoogle() {
    window.location.href = '/api/auth/google';
  }

  function appleComingSoon() {
    toast({
      title: 'Masuk dengan Apple segera hadir',
      description: 'Sementara gunakan Google atau email untuk masuk.',
    });
  }

  if (verifyEmail) {
    return (
      <div className="relative flex flex-1 flex-col justify-center bg-[#0d0a13] px-6 py-10 sm:px-10 lg:px-12">
        <div className="pointer-events-none absolute right-[-20%] top-[-20%] h-72 w-72 rounded-full bg-violet-700/25 blur-[100px]" />
        <FlowerOfLife className="pointer-events-none absolute -bottom-16 -right-16 h-64 w-64 text-violet-500/[0.07]" />
        <div className="relative">
          <div className="flex items-center gap-2.5">
            <FlowerOfLife className="h-8 w-8 text-violet-300" />
            <span className="text-lg font-semibold tracking-tight text-white">yanzea</span>
          </div>
          <EmailVerifyPanel
            email={verifyEmail}
            initialPreviewCode={null}
            onVerified={(user) => {
              setVerifyEmail(null);
              toast({
                title: `Selamat datang kembali, ${user.name.split(' ')[0]}!`,
                description: 'Email terverifikasi.',
                className:
                  'border-violet-300/25 bg-[#170f24] text-white shadow-[0_18px_50px_-12px_rgba(76,29,149,0.8)]',
              });
              onAuthed(user);
            }}
          />
        </div>
      </div>
    );
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);

    if (!/^\S+@\S+\.\S+$/.test(email.trim())) {
      setError('Masukkan alamat email yang valid.');
      return;
    }
    if (password.length < 6) {
      setError('Kata sandi minimal 6 karakter.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password, remember }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        // Akun email belum diverifikasi → tampilkan panel verifikasi.
        if (res.status === 403 && data.needsVerification) {
          setVerifyEmail(email.trim());
          setError(null);
          return;
        }
        setError(data.message || 'Terjadi kesalahan. Silakan coba lagi.');
      } else {
        toast({
          title: `Selamat datang kembali, ${data.user.name.split(' ')[0]}!`,
          description: data.user.role === 'ADMIN' ? 'Mengalihkan ke Panel Admin…' : 'Mengalihkan ke obrolanmu…',
          className:
            'border-violet-300/25 bg-[#170f24] text-white shadow-[0_18px_50px_-12px_rgba(76,29,149,0.8)]',
        });
        onAuthed(data.user);
      }
    } catch {
      setError('Koneksi bermasalah. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex flex-1 flex-col justify-center bg-[#0d0a13] px-6 py-10 sm:px-10 lg:px-12">
      {/* soft corner glow + watermark, keeps mobile from feeling empty */}
      <div className="pointer-events-none absolute right-[-20%] top-[-20%] h-72 w-72 rounded-full bg-violet-700/25 blur-[100px]" />
      <FlowerOfLife className="pointer-events-none absolute -bottom-16 -right-16 h-64 w-64 text-violet-500/[0.07]" />

      <div className="relative">
        {/* brand */}
        <div className="flex items-center gap-2.5">
          <FlowerOfLife className="h-8 w-8 text-violet-300" />
          <span className="text-lg font-semibold tracking-tight text-white">yanzea</span>
        </div>

        <p className="mt-8 text-[11px] font-medium uppercase tracking-[0.28em] text-violet-300/80">
          AI Agent Pintarmu
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          Selamat datang kembali
        </h1>
        <p className="mt-2 text-sm text-white/55">
          Masuk untuk melanjutkan percakapanmu dengan Yanzea.
        </p>

        {/* social sign-in */}
        <div className="mt-7 grid grid-cols-2 gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={goGoogle}
            className="h-11 rounded-xl border-white/10 bg-white/[0.05] text-sm text-white/90 hover:bg-white/[0.1] hover:text-white"
          >
            <GoogleIcon /> Google
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={appleComingSoon}
            className="h-11 rounded-xl border-white/10 bg-white/[0.05] text-sm text-white/90 hover:bg-white/[0.1] hover:text-white"
          >
            <AppleIcon /> Apple
          </Button>
        </div>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/15 to-white/10" />
          <span className="text-[11px] uppercase tracking-wider text-white/35">atau dengan email</span>
          <div className="h-px flex-1 bg-gradient-to-l from-transparent via-white/15 to-white/10" />
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <label htmlFor="email" className="text-xs font-medium text-white/70">
            Alamat email
          </label>
          <div className="relative mt-1.5">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
            />
          </div>

          <label htmlFor="password" className="mt-4 block text-xs font-medium text-white/70">
            Kata sandi
          </label>
          <div className="relative mt-1.5">
            <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
            <Input
              id="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 pr-11 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-white/40 transition-colors hover:text-white/80"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <label className="flex cursor-pointer items-center gap-2 text-xs text-white/60">
              <Checkbox
                checked={remember}
                onCheckedChange={(v) => setRemember(v === true)}
                className="border-white/20 bg-white/[0.05] data-[state=checked]:border-violet-500 data-[state=checked]:bg-violet-600 data-[state=checked]:text-white"
              />
              Ingat saya
            </label>
            <a href="/lupa-sandi" className="text-xs font-medium text-violet-300 transition-colors hover:text-violet-200">
              Lupa kata sandi?
            </a>
          </div>

          {error ? (
            <p role="alert" className="mt-4 rounded-lg border border-rose-400/20 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
              {error}
            </p>
          ) : null}

          <Button
            type="submit"
            disabled={loading}
            className="mt-6 h-12 w-full rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-purple-500 text-sm font-semibold text-white shadow-[0_10px_40px_-8px_rgba(139,92,246,0.65)] transition-all hover:shadow-[0_14px_50px_-6px_rgba(139,92,246,0.85)] hover:brightness-110 disabled:opacity-60"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Sedang masuk…
              </>
            ) : (
              <>
                Masuk <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-white/50">
          Baru di Yanzea?{' '}
          <button
            type="button"
            onClick={onSwitch}
            className="font-medium text-violet-300 transition-colors hover:text-violet-200"
          >
            Buat akun
          </button>
        </p>

        <p className="mt-6 text-center text-[11px] leading-relaxed text-white/30">
          Dengan masuk, kamu menyetujui{' '}
          <a href="#" className="underline underline-offset-2 hover:text-white/50">Syarat &amp; Ketentuan</a> dan{' '}
          <a href="#" className="underline underline-offset-2 hover:text-white/50">Kebijakan Privasi</a> kami.
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Register form panel                                                */
/* ------------------------------------------------------------------ */

function RegisterForm({
  onSwitch,
  onAuthed,
}: {
  onSwitch: () => void;
  onAuthed: (user: AppUser) => void;
}) {
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agree, setAgree] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingVerify, setPendingVerify] = useState<{ email: string; previewCode: string | null } | null>(null);

  function goGoogle() {
    window.location.href = '/api/auth/google';
  }

  function appleComingSoon() {
    toast({
      title: 'Daftar dengan Apple segera hadir',
      description: 'Sementara gunakan Google atau email untuk mendaftar.',
    });
  }

  function passwordStrength(pw: string): { label: string; width: string; color: string } {
    let score = 0;
    if (pw.length >= 6) score++;
    if (pw.length >= 10) score++;
    if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
    if (/\d/.test(pw) || /[^\w\s]/.test(pw)) score++;
    if (score <= 1) return { label: 'Lemah', width: '25%', color: 'bg-rose-400' };
    if (score === 2) return { label: 'Cukup', width: '50%', color: 'bg-amber-400' };
    if (score === 3) return { label: 'Baik', width: '75%', color: 'bg-violet-400' };
    return { label: 'Kuat', width: '100%', color: 'bg-emerald-400' };
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);

    if (name.trim().length < 2) {
      setError('Mohon masukkan namamu.');
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) {
      setError('Masukkan alamat email yang valid.');
      return;
    }
    if (password.length < 6) {
      setError('Kata sandi minimal 6 karakter.');
      return;
    }
    if (password !== confirm) {
      setError('Kata sandi tidak cocok.');
      return;
    }
    if (!agree) {
      setError('Mohon setujui Syarat & Ketentuan serta Kebijakan Privasi.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), email: email.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.message || 'Terjadi kesalahan. Silakan coba lagi.');
      } else {
        toast({
          title: `Akun dibuat, ${data.user.name.split(' ')[0]}!`,
          description: 'Kami mengirim kode verifikasi ke emailmu.',
          className:
            'border-violet-300/25 bg-[#170f24] text-white shadow-[0_18px_50px_-12px_rgba(76,29,149,0.8)]',
        });
        setPendingVerify({
          email: email.trim(),
          previewCode: data.verification?.previewCode ?? null,
        });
      }
    } catch {
      setError('Koneksi bermasalah. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  const strength = password ? passwordStrength(password) : null;

  if (pendingVerify) {
    return (
      <div className="relative flex flex-1 flex-col justify-center bg-[#0d0a13] px-6 py-10 sm:px-10 lg:px-12">
        <div className="pointer-events-none absolute right-[-20%] top-[-20%] h-72 w-72 rounded-full bg-violet-700/25 blur-[100px]" />
        <FlowerOfLife className="pointer-events-none absolute -bottom-16 -right-16 h-64 w-64 text-violet-500/[0.07]" />
        <div className="relative">
          <div className="flex items-center gap-2.5">
            <FlowerOfLife className="h-8 w-8 text-violet-300" />
            <span className="text-lg font-semibold tracking-tight text-white">yanzea</span>
          </div>
          <EmailVerifyPanel
            email={pendingVerify.email}
            initialPreviewCode={pendingVerify.previewCode}
            onVerified={(user) => {
              setPendingVerify(null);
              toast({
                title: `Selamat datang di Yanzea, ${user.name.split(' ')[0]}!`,
                description: 'Email terverifikasi — akunmu aktif.',
                className:
                  'border-violet-300/25 bg-[#170f24] text-white shadow-[0_18px_50px_-12px_rgba(76,29,149,0.8)]',
              });
              onAuthed(user);
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex flex-1 flex-col justify-center bg-[#0d0a13] px-6 py-10 sm:px-10 lg:px-12">
      <div className="pointer-events-none absolute right-[-20%] top-[-20%] h-72 w-72 rounded-full bg-violet-700/25 blur-[100px]" />
      <FlowerOfLife className="pointer-events-none absolute -bottom-16 -right-16 h-64 w-64 text-violet-500/[0.07]" />

      <div className="relative">
        <div className="flex items-center gap-2.5">
          <FlowerOfLife className="h-8 w-8 text-violet-300" />
          <span className="text-lg font-semibold tracking-tight text-white">yanzea</span>
        </div>

        <p className="mt-8 text-[11px] font-medium uppercase tracking-[0.28em] text-violet-300/80">
          AI Agent Pintarmu
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          Buat akunmu
        </h1>
        <p className="mt-2 text-sm text-white/55">
          Mulai sekarang — Yanzea siap membantu apa pun kebutuhanmu.
        </p>

        {/* social sign-up */}
        <div className="mt-7 grid grid-cols-2 gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={goGoogle}
            className="h-11 rounded-xl border-white/10 bg-white/[0.05] text-sm text-white/90 hover:bg-white/[0.1] hover:text-white"
          >
            <GoogleIcon /> Google
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={appleComingSoon}
            className="h-11 rounded-xl border-white/10 bg-white/[0.05] text-sm text-white/90 hover:bg-white/[0.1] hover:text-white"
          >
            <AppleIcon /> Apple
          </Button>
        </div>

        <div className="my-5 flex items-center gap-3">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/15 to-white/10" />
          <span className="text-[11px] uppercase tracking-wider text-white/35">atau dengan email</span>
          <div className="h-px flex-1 bg-gradient-to-l from-transparent via-white/15 to-white/10" />
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <label htmlFor="reg-name" className="text-xs font-medium text-white/70">
            Nama lengkap
          </label>
          <div className="relative mt-1.5">
            <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
            <Input
              id="reg-name"
              type="text"
              autoComplete="name"
              placeholder="Namamu"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
            />
          </div>

          <label htmlFor="reg-email" className="mt-4 block text-xs font-medium text-white/70">
            Alamat email
          </label>
          <div className="relative mt-1.5">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
            <Input
              id="reg-email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
            />
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="reg-password" className="block text-xs font-medium text-white/70">
                Kata sandi
              </label>
              <div className="relative mt-1.5">
                <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                <Input
                  id="reg-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="Min. 6 karakter"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 pr-11 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-white/40 transition-colors hover:text-white/80"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <div>
              <label htmlFor="reg-confirm" className="block text-xs font-medium text-white/70">
                Konfirmasi kata sandi
              </label>
              <div className="relative mt-1.5">
                <Sparkles className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                <Input
                  id="reg-confirm"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="Ulangi kata sandi"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  className="h-11 rounded-xl border-white/10 bg-white/[0.05] pl-10 text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
                />
              </div>
            </div>
          </div>

          {strength ? (
            <div className="mt-3 flex items-center gap-3">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${strength.color}`}
                  style={{ width: strength.width }}
                />
              </div>
              <span className="w-14 text-right text-[11px] text-white/50">{strength.label}</span>
            </div>
          ) : null}

          <label className="mt-4 flex cursor-pointer items-start gap-2.5 text-xs leading-relaxed text-white/60">
            <Checkbox
              checked={agree}
              onCheckedChange={(v) => setAgree(v === true)}
              className="mt-0.5 border-white/20 bg-white/[0.05] data-[state=checked]:border-violet-500 data-[state=checked]:bg-violet-600 data-[state=checked]:text-white"
            />
            <span>
              Saya menyetujui{' '}
            <a href="#" className="text-violet-300 hover:text-violet-200">Syarat &amp; Ketentuan</a> dan{' '}
            <a href="#" className="text-violet-300 hover:text-violet-200">Kebijakan Privasi</a>.
            </span>
          </label>

          {error ? (
            <p role="alert" className="mt-4 rounded-lg border border-rose-400/20 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
              {error}
            </p>
          ) : null}

          <Button
            type="submit"
            disabled={loading}
            className="mt-6 h-12 w-full rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-purple-500 text-sm font-semibold text-white shadow-[0_10px_40px_-8px_rgba(139,92,246,0.65)] transition-all hover:shadow-[0_14px_50px_-6px_rgba(139,92,246,0.85)] hover:brightness-110 disabled:opacity-60"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Membuat akun…
              </>
            ) : (
              <>
                Buat Akun <Sparkles className="h-4 w-4" />
              </>
            )}
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-white/50">
          Sudah punya akun?{' '}
          <button
            type="button"
            onClick={onSwitch}
            className="font-medium text-violet-300 transition-colors hover:text-violet-200"
          >
            Masuk
          </button>
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Auth screen (backdrop + illustration + form)                       */
/* ------------------------------------------------------------------ */

function AuthScreen({
  mode,
  onAuthed,
}: {
  mode: AuthMode;
  onAuthed: (user: AppUser) => void;
}) {
  const [view, setView] = useState<AuthMode>(mode);
  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden bg-[#120b1e]">
      {/* vibrant purple backdrop, like the video frame around the screen */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(120% 90% at 85% 0%, rgba(124,58,237,0.75) 0%, rgba(124,58,237,0) 55%),' +
            'radial-gradient(120% 100% at 15% 100%, rgba(91,33,182,0.85) 0%, rgba(67,56,202,0.4) 45%, rgba(18,11,30,0) 75%),' +
            'radial-gradient(90% 70% at 50% 50%, rgba(109,40,217,0.35) 0%, rgba(18,11,30,0) 70%),' +
            'linear-gradient(160deg, #150d20 0%, #2a1458 45%, #4c1d95 100%)',
        }}
      />
      {/* huge thin orbital rings on the backdrop */}
      <div aria-hidden="true" className="absolute -right-40 -top-64 h-[820px] w-[820px] rounded-full border border-white/10" />
      <div aria-hidden="true" className="absolute -bottom-80 -left-52 h-[900px] w-[900px] rounded-full border border-white/[0.08]" />
      <div aria-hidden="true" className="absolute -bottom-64 left-1/4 h-[520px] w-[520px] rounded-full border border-white/[0.06]" />

      <main className="relative z-10 flex flex-1 items-center justify-center p-4 py-10 sm:p-8">
        <div className="grid w-full max-w-6xl overflow-hidden rounded-[28px] border border-violet-300/20 bg-[#0a0710]/90 shadow-[0_50px_140px_-30px_rgba(76,29,149,0.9),0_0_0_1px_rgba(167,139,250,0.08)] backdrop-blur-xl lg:grid-cols-[1.08fr_1fr]">
          <IllustrationPanel />
          {view === 'login' ? (
            <LoginForm onSwitch={() => setView('register')} onAuthed={onAuthed} />
          ) : (
            <RegisterForm onSwitch={() => setView('login')} onAuthed={onAuthed} />
          )}
        </div>
      </main>

      <footer className="relative z-10 mt-auto pb-6 text-center">
        <p className="text-xs tracking-wide text-white/45">
          © 2026 Yanzea · splettify.co.id — AI Agent Otomasi, IIoT &amp; IoT
        </p>
      </footer>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Page — session bootstrap                                           */
/* ------------------------------------------------------------------ */

export default function Home() {
  const [booted, setBooted] = useState(false);
  const [user, setUser] = useState<AppUser | null>(null);
  const [view, setView] = useState<'chat' | 'iot' | 'admin'>('chat');

  useEffect(() => {
    fetch('/api/auth/me')
      .then(async (res) => {
        if (res.ok) {
          const data = await res.json();
          if (data.ok && data.user) setUser(data.user);
        }
      })
      .catch(() => {})
      .finally(() => setBooted(true));
  }, []);

  if (!booted) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-[#120b1e]">
        <div className="animate-floaty relative">
          <div className="absolute inset-0 -z-10 rounded-full bg-violet-600/30 blur-[60px]" />
          <FlowerOfLife className="h-16 w-16 text-violet-300" />
        </div>
      </div>
    );
  }

  // Setelah login/daftar, admin diarahkan ke Panel Admin; pengguna biasa ke chat.
  const handleAuthed = (u: AppUser) => {
    setUser(u);
    setView(u.role === 'ADMIN' ? 'admin' : 'chat');
  };

  if (user) {
    const handleLogout = () => {
      setUser(null);
      setView('chat');
    };
    if (view === 'admin') {
      return (
        <AdminDashboard
          user={user}
          onBack={() => setView('chat')}
          onOpenIot={() => setView('iot')}
          onLogout={handleLogout}
        />
      );
    }
    // Dashboard IoT khusus admin — pengguna biasa selalu kembali ke chat.
    if (view === 'iot' && user.role === 'ADMIN') {
      return <IotDashboard user={user} onBack={() => setView('chat')} onLogout={handleLogout} />;
    }
    return (
      <ChatApp
        user={user}
        onLogout={handleLogout}
        onOpenDashboard={user.role === 'ADMIN' ? () => setView('iot') : undefined}
        onOpenAdmin={user.role === 'ADMIN' ? () => setView('admin') : undefined}
      />
    );
  }

  return <AuthScreen mode="login" onAuthed={handleAuthed} />;
}
