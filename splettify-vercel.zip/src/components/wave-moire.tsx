/**
 * Wavy moiré line art — recreates the flowing purple line waves shown behind
 * the "superconscious" wordmark in the reference video.
 * Paths are generated deterministically so server and client markup match.
 */

type WaveMoireProps = {
  className?: string;
  lines?: number;
  opacity?: number;
};

export function WaveMoire({ className, lines = 24, opacity = 0.7 }: WaveMoireProps) {
  const W = 600;
  const H = 300;
  const paths = Array.from({ length: lines }, (_, i) => {
    const t = i / (lines - 1);
    const y0 = 26 + i * ((H - 52) / (lines - 1));
    const pts: string[] = [];
    for (let x = 0; x <= W; x += 12) {
      const p = x / W;
      const envelope = Math.sin(Math.PI * p);
      const wave =
        Math.sin(p * Math.PI * 1.7 + t * 2.6 + 0.5) * 52 * envelope +
        Math.sin(p * Math.PI * 3.1 - t * 1.4) * 14 * envelope;
      pts.push(`${x},${(y0 + wave).toFixed(1)}`);
    }
    return `M${pts.join(' L')}`;
  });

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none"
      className={className}
      style={{ opacity }}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="waveGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#7c3aed" stopOpacity="0.05" />
          <stop offset="35%" stopColor="#a78bfa" stopOpacity="0.9" />
          <stop offset="70%" stopColor="#8b5cf6" stopOpacity="0.75" />
          <stop offset="100%" stopColor="#6d28d9" stopOpacity="0.05" />
        </linearGradient>
      </defs>
      {paths.map((d, i) => (
        <path
          key={i}
          d={d}
          fill="none"
          stroke="url(#waveGrad)"
          strokeWidth="1.05"
        />
      ))}
    </svg>
  );
}
