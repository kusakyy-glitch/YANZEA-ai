'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Activity,
  ArrowLeft,
  Cpu,
  Droplets,
  Fan,
  Gauge,
  Lightbulb,
  Loader2,
  LogOut,
  MoveHorizontal,
  Plus,
  Siren,
  Sun,
  Thermometer,
  Trash2,
  Waves,
  Zap,
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { FlowerOfLife } from '@/components/sacred-geometry';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type DashboardUser = { id: string; name: string; email: string };

export type IotDevice = {
  id: string;
  name: string;
  kind: string; // "sensor" | "actuator"
  metric: string | null;
  unit: string | null;
  zone: string;
  baseValue: number;
  amplitude: number;
  isOn: boolean;
};

export type IotRule = {
  id: string;
  name: string;
  sensorId: string;
  operator: string; // ">" | "<"
  threshold: number;
  actuatorId: string;
  action: boolean; // true = nyalakan
  enabled: boolean;
  sensor: { id: string; name: string; unit: string | null };
  actuator: { id: string; name: string };
};

type Reading = { value: number; history: number[] };
type LogEntry = { id: number; time: string; text: string; kind: 'auto' | 'manual' | 'info' };

const HISTORY_LEN = 40;
const TICK_MS = 2000;

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

const fmt = (n: number) => n.toLocaleString('id-ID', { maximumFractionDigits: 1 });

function SensorGlyph({ metric, className }: { metric: string | null; className?: string }) {
  switch (metric) {
    case 'suhu':
      return <Thermometer className={className} />;
    case 'kelembapan':
      return <Droplets className={className} />;
    case 'tekanan':
      return <Gauge className={className} />;
    case 'arus':
      return <Zap className={className} />;
    case 'level':
      return <Waves className={className} />;
    case 'cahaya':
      return <Sun className={className} />;
    default:
      return <Activity className={className} />;
  }
}

function ActuatorGlyph({ name, className }: { name: string; className?: string }) {
  const n = name.toLowerCase();
  if (n.includes('kipas') || n.includes('pendingin')) return <Fan className={className} />;
  if (n.includes('pompa')) return <Droplets className={className} />;
  if (n.includes('conveyor')) return <MoveHorizontal className={className} />;
  if (n.includes('lampu')) return <Lightbulb className={className} />;
  if (n.includes('alarm')) return <Siren className={className} />;
  return <Cpu className={className} />;
}

/** Simulasi telemetri: gelombang lambat + goyangan halus + derau acak. */
function simValue(device: IotDevice, tSec: number, index: number): number {
  const period = 90 + index * 22; // detik per siklus
  const phase = index * 1.7;
  const slow = Math.sin((tSec / period) * Math.PI * 2 + phase);
  const wobble = Math.sin(tSec / 7 + index) * 0.06;
  const noise = (Math.random() - 0.5) * 0.05;
  return Math.max(0, device.baseValue + device.amplitude * (slow + wobble + noise));
}

function nowTime(): string {
  return new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}

function Sparkline({ data }: { data: number[] }) {
  if (data.length < 2) return <div className="mt-3 h-8" />;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const pts = data
    .map((v, i) => `${((i / (data.length - 1)) * 100).toFixed(2)},${(26 - ((v - min) / span) * 22).toFixed(2)}`)
    .join(' ');
  return (
    <svg viewBox="0 0 100 28" preserveAspectRatio="none" className="mt-3 h-8 w-full" aria-hidden="true">
      <polyline
        points={pts}
        fill="none"
        stroke="rgba(167,139,250,0.85)"
        strokeWidth="1.6"
        strokeLinejoin="round"
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  Sub-components                                                     */
/* ------------------------------------------------------------------ */

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
      <div className="flex items-center gap-2 text-white/50">
        <span className="text-violet-300">{icon}</span>
        <p className="text-[10.5px] font-medium uppercase tracking-wider">{label}</p>
      </div>
      <p className="mt-2 text-2xl font-semibold tracking-tight text-white">{value}</p>
      <p className="mt-0.5 text-[10.5px] text-white/35">{sub}</p>
    </div>
  );
}

function SensorCard({ device, reading }: { device: IotDevice; reading?: Reading }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 transition-colors hover:border-violet-300/25">
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-violet-300/20 bg-violet-500/10 text-violet-200">
            <SensorGlyph metric={device.metric} className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium text-white">{device.name}</p>
            <p className="text-[10.5px] text-white/40">{device.zone}</p>
          </div>
        </div>
        <span className="flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/20 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-200">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" />
          Online
        </span>
      </div>
      <p className="mt-3 text-[28px] font-semibold leading-none tracking-tight text-white">
        {reading ? fmt(reading.value) : '—'}
        <span className="ml-1 text-sm font-normal text-white/40">{device.unit}</span>
      </p>
      {reading ? <Sparkline data={reading.history} /> : <div className="mt-3 h-8 animate-pulse rounded bg-white/5" />}
    </div>
  );
}

function ActuatorCard({ device, onToggle }: { device: IotDevice; onToggle: () => void }) {
  return (
    <div
      className={`rounded-2xl border p-4 transition-all ${
        device.isOn
          ? 'border-violet-400/40 bg-violet-500/[0.12] shadow-[0_0_30px_-10px_rgba(139,92,246,0.5)]'
          : 'border-white/10 bg-white/[0.04]'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2.5">
          <span
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border ${
              device.isOn ? 'border-violet-300/40 bg-violet-500/20 text-violet-100' : 'border-white/10 bg-white/[0.05] text-white/40'
            }`}
          >
            <ActuatorGlyph name={device.name} className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium text-white">{device.name}</p>
            <p className="text-[10.5px] text-white/40">{device.zone}</p>
          </div>
        </div>
        <Switch
          checked={device.isOn}
          onCheckedChange={onToggle}
          aria-label={`${device.isOn ? 'Matikan' : 'Nyalakan'} ${device.name}`}
          className="data-[state=checked]:bg-violet-600 data-[state=unchecked]:bg-white/10"
        />
      </div>
      <p className={`mt-3 text-[22px] font-semibold leading-none tracking-tight ${device.isOn ? 'text-violet-200' : 'text-white/30'}`}>
        {device.isOn ? 'MENYALA' : 'MATI'}
      </p>
      <div className="mt-3 flex items-center gap-1.5 text-[10.5px] text-white/40">
        <Zap className={`h-3 w-3 ${device.isOn ? 'text-violet-300' : 'text-white/25'}`} />
        {device.isOn ? 'Aktif — dikendalikan sistem otomasi' : 'Siaga'}
      </div>
    </div>
  );
}

function RuleItem({
  rule,
  onToggle,
  onDelete,
}: {
  rule: IotRule;
  onToggle: (v: boolean) => void;
  onDelete: () => void;
}) {
  return (
    <div className={`rounded-xl border p-3 ${rule.enabled ? 'border-white/10 bg-white/[0.03]' : 'border-white/[0.06] bg-transparent opacity-55'}`}>
      <div className="flex items-center justify-between gap-2">
        <p className="truncate text-[12px] font-medium text-white/90">{rule.name}</p>
        <div className="flex shrink-0 items-center gap-1.5">
          <Switch
            checked={rule.enabled}
            onCheckedChange={onToggle}
            aria-label={`${rule.enabled ? 'Nonaktifkan' : 'Aktifkan'} aturan ${rule.name}`}
            className="scale-90 data-[state=checked]:bg-violet-600 data-[state=unchecked]:bg-white/10"
          />
          <button
            onClick={onDelete}
            aria-label={`Hapus aturan ${rule.name}`}
            className="rounded-md p-1 text-white/25 transition-colors hover:bg-white/10 hover:text-rose-300"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
      <p className="mt-1 text-[10.5px] leading-relaxed text-white/45">
        JIKA <span className="text-white/70">{rule.sensor.name}</span> {rule.operator === '>' ? '>' : '<'}{' '}
        <span className="text-white/70">
          {fmt(rule.threshold)} {rule.sensor.unit}
        </span>{' '}
        → MAKA <span className="text-violet-200/90">{rule.actuator.name}</span> {rule.action ? 'Nyala' : 'Mati'}
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main dashboard                                                     */
/* ------------------------------------------------------------------ */

export function IotDashboard({
  user,
  onBack,
  onLogout,
}: {
  user: DashboardUser;
  onBack: () => void;
  onLogout: () => void;
}) {
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [devices, setDevices] = useState<IotDevice[]>([]);
  const [rules, setRules] = useState<IotRule[]>([]);
  const [readings, setReadings] = useState<Record<string, Reading>>({});
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [clock, setClock] = useState('');

  const [fSensor, setFSensor] = useState('');
  const [fOp, setFOp] = useState('>');
  const [fThr, setFThr] = useState('');
  const [fAct, setFAct] = useState('');
  const [fAction, setFAction] = useState('true');
  const [savingRule, setSavingRule] = useState(false);

  const devicesRef = useRef<IotDevice[]>([]);
  const rulesRef = useRef<IotRule[]>([]);
  const readingsRef = useRef<Record<string, Reading>>({});
  const logIdRef = useRef(0);

  const firstName = user.name.split(' ')[0];

  const addLog = useCallback((kind: LogEntry['kind'], text: string) => {
    logIdRef.current += 1;
    const entry: LogEntry = { id: logIdRef.current, time: nowTime(), text, kind };
    setLogs((prev) => [entry, ...prev].slice(0, 14));
  }, []);

  /* ---------------- data awal ---------------- */

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await fetch('/api/iot');
        if (res.status === 401) return onLogout();
        const data = await res.json();
        if (!alive || !data.ok) return;

        const list: IotDevice[] = data.devices;
        setDevices(list);
        setRules(data.rules);
        devicesRef.current = list;
        rulesRef.current = data.rules;

        const now = Date.now();
        const init: Record<string, Reading> = {};
        list.forEach((d, idx) => {
          if (d.kind !== 'sensor') return;
          const history: number[] = [];
          for (let i = HISTORY_LEN - 1; i >= 0; i--) {
            history.push(simValue(d, (now - i * TICK_MS) / 1000, idx));
          }
          init[d.id] = { value: history[history.length - 1], history };
        });
        readingsRef.current = init;
        setReadings(init);

        const firstSensor = list.find((d) => d.kind === 'sensor');
        const firstActuator = list.find((d) => d.kind === 'actuator');
        setFSensor(firstSensor?.id ?? '');
        setFAct(firstActuator?.id ?? '');

        addLog('info', `Terhubung ke gateway — ${list.length} perangkat online`);
      } catch {
        if (alive) toast({ title: 'Tidak dapat memuat perangkat IoT.', variant: 'destructive' });
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  /* ---------------- jam live ---------------- */

  useEffect(() => {
    setClock(nowTime());
    const t = setInterval(() => setClock(nowTime()), 1000);
    return () => clearInterval(t);
  }, []);

  /* ---------------- mesin otomasi (tick) ---------------- */

  useEffect(() => {
    const timer = setInterval(() => {
      const list = devicesRef.current;
      if (!list.length) return;
      const t = Date.now() / 1000;

      // 1) telemetri sensor baru
      const nextReadings = { ...readingsRef.current };
      list.forEach((d, idx) => {
        if (d.kind !== 'sensor') return;
        const value = simValue(d, t, idx);
        const history = [...(nextReadings[d.id]?.history ?? []), value].slice(-HISTORY_LEN);
        nextReadings[d.id] = { value, history };
      });
      readingsRef.current = nextReadings;
      setReadings(nextReadings);

      // 2) evaluasi aturan otomasi
      const activeRules = rulesRef.current.filter((r) => r.enabled);
      const nextOn = new Map<string, boolean>();
      for (const d of list) if (d.kind === 'actuator') nextOn.set(d.id, d.isOn);
      for (const r of activeRules) {
        const reading = nextReadings[r.sensorId];
        if (!reading) continue;
        const cond = r.operator === '>' ? reading.value > r.threshold : reading.value < r.threshold;
        if (cond) nextOn.set(r.actuatorId, r.action);
      }

      // 3) terapkan perubahan + catat aktivitas
      const changed = new Map<string, boolean>();
      for (const d of list) {
        if (d.kind !== 'actuator') continue;
        const target = nextOn.get(d.id) ?? d.isOn;
        if (target === d.isOn) continue;
        changed.set(d.id, target);

        const rule = activeRules.find((r) => r.actuatorId === d.id);
        const reading = rule ? nextReadings[rule.sensorId] : undefined;
        if (rule && reading) {
          addLog(
            'auto',
            `Otomasi: ${d.name} ${target ? 'MENYALA' : 'MATI'} — ${rule.sensor.name} ${fmt(reading.value)} ${rule.sensor.unit ?? ''} ${
              rule.operator === '>' ? '>' : '<'
            } ${fmt(rule.threshold)} ${rule.sensor.unit ?? ''}`
          );
        }
        fetch(`/api/iot/devices/${d.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ isOn: target }),
        }).catch(() => {});
      }

      if (changed.size) {
        const next = devicesRef.current.map((d) => (changed.has(d.id) ? { ...d, isOn: changed.get(d.id)! } : d));
        devicesRef.current = next;
        setDevices(next);
      }
    }, TICK_MS);
    return () => clearInterval(timer);
  }, [addLog]);

  /* ---------------- aksi ---------------- */

  async function toggleDevice(d: IotDevice) {
    const next = !d.isOn;
    const list = devicesRef.current.map((x) => (x.id === d.id ? { ...x, isOn: next } : x));
    devicesRef.current = list;
    setDevices(list);
    addLog('manual', `${d.name} ${next ? 'menyala' : 'mati'} — dikendalikan manual`);
    try {
      const res = await fetch(`/api/iot/devices/${d.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isOn: next }),
      });
      if (res.status === 401) return onLogout();
    } catch {
      /* offline — status lokal sudah dioptimalkan */
    }
  }

  async function toggleRule(r: IotRule, enabled: boolean) {
    const next = rulesRef.current.map((x) => (x.id === r.id ? { ...x, enabled } : x));
    rulesRef.current = next;
    setRules(next);
    addLog('info', `Aturan "${r.name}" ${enabled ? 'diaktifkan' : 'dinonaktifkan'}`);
    try {
      const res = await fetch(`/api/iot/rules/${r.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled }),
      });
      if (res.status === 401) return onLogout();
    } catch {
      /* offline */
    }
  }

  async function deleteRule(r: IotRule) {
    const next = rulesRef.current.filter((x) => x.id !== r.id);
    rulesRef.current = next;
    setRules(next);
    addLog('info', `Aturan "${r.name}" dihapus`);
    try {
      const res = await fetch(`/api/iot/rules/${r.id}`, { method: 'DELETE' });
      if (res.status === 401) return onLogout();
      toast({ title: 'Aturan dihapus', description: r.name });
    } catch {
      toast({ title: 'Tidak dapat menghapus aturan.', variant: 'destructive' });
    }
  }

  async function createRule(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!fSensor || !fAct) {
      toast({ title: 'Lengkapi dulu', description: 'Pilih sensor dan aktuator untuk aturan otomasi.', variant: 'destructive' });
      return;
    }
    const threshold = Number(fThr.replace(',', '.'));
    if (!Number.isFinite(threshold)) {
      toast({ title: 'Ambang batas belum benar', description: 'Isi nilai ambang batas berupa angka, mis. 28.', variant: 'destructive' });
      return;
    }

    setSavingRule(true);
    try {
      const res = await fetch('/api/iot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sensorId: fSensor, operator: fOp, threshold, actuatorId: fAct, action: fAction === 'true' }),
      });
      if (res.status === 401) return onLogout();
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.message || 'Gagal membuat aturan.');

      const next = [...rulesRef.current, data.rule as IotRule];
      rulesRef.current = next;
      setRules(next);
      addLog(
        'info',
        `Aturan baru: ${data.rule.sensor.name} ${data.rule.operator === '>' ? '>' : '<'} ${fmt(data.rule.threshold)} ${data.rule.sensor.unit ?? ''} → ${data.rule.actuator.name} ${data.rule.action ? 'Nyala' : 'Mati'}`
      );
      toast({ title: 'Aturan otomasi dibuat', description: data.rule.name, className: 'border-violet-300/25 bg-[#170f24] text-white' });
      setFThr('');
    } catch (err) {
      toast({
        title: 'Gagal membuat aturan',
        description: err instanceof Error ? err.message : 'Silakan coba lagi.',
        variant: 'destructive',
      });
    } finally {
      setSavingRule(false);
    }
  }

  /* ---------------- turunan ---------------- */

  const sensors = devices.filter((d) => d.kind === 'sensor');
  const actuators = devices.filter((d) => d.kind === 'actuator');
  const activeCount = actuators.filter((d) => d.isOn).length;
  const enabledRules = rules.filter((r) => r.enabled).length;

  const avgOf = (metric: string): number | null => {
    const list = sensors
      .filter((d) => d.metric === metric)
      .map((d) => readings[d.id]?.value)
      .filter((v): v is number => typeof v === 'number');
    if (!list.length) return null;
    return list.reduce((a, b) => a + b, 0) / list.length;
  };

  const avgTemp = avgOf('suhu');
  const avgHum = avgOf('kelembapan');

  /* ---------------- render ---------------- */

  return (
    <div className="relative h-dvh overflow-hidden">
      {/* ambience ungu */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(110% 80% at 85% 0%, rgba(124,58,237,0.5) 0%, rgba(124,58,237,0) 55%),' +
            'radial-gradient(100% 90% at 10% 100%, rgba(91,33,182,0.65) 0%, rgba(18,11,30,0) 70%),' +
            'linear-gradient(160deg, #150d20 0%, #2a1458 50%, #3b1a78 100%)',
        }}
      />
      <div aria-hidden="true" className="absolute -right-40 -top-64 h-[820px] w-[820px] rounded-full border border-white/10" />
      <div aria-hidden="true" className="absolute -bottom-80 -left-52 h-[900px] w-[900px] rounded-full border border-white/[0.08]" />

      <div className="relative z-10 flex h-full p-0 sm:p-4 lg:p-5">
        <div className="flex h-full w-full flex-col overflow-hidden rounded-none border-0 bg-[#0d0a13]/95 shadow-[0_50px_140px_-30px_rgba(76,29,149,0.9)] backdrop-blur-xl sm:rounded-[28px] sm:border sm:border-violet-300/20">
          {/* header */}
          <header className="flex items-center gap-3 border-b border-white/[0.07] px-4 py-3">
            <button
              onClick={onBack}
              aria-label="Kembali ke obrolan"
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[13px] text-white/60 transition-colors hover:bg-white/10 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">Obrolan</span>
            </button>
            <div className="flex min-w-0 items-center gap-2.5">
              <FlowerOfLife className="h-6 w-6 shrink-0 text-violet-300" />
              <div className="min-w-0 leading-tight">
                <p className="truncate text-[13px] font-semibold text-white">Dashboard IoT</p>
                <p className="text-[10px] text-white/40">Otomasi · IIoT · IoT</p>
              </div>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <span className="hidden items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-500/10 px-3 py-1 text-[11px] font-medium text-emerald-200 md:flex">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-300 opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-300" />
                </span>
                Live · <span className="tabular-nums">{clock}</span>
              </span>
              <button
                onClick={onLogout}
                aria-label="Keluar"
                title="Keluar"
                className="rounded-lg p-2 text-white/45 transition-colors hover:bg-white/10 hover:text-rose-300"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </header>

          {/* body */}
          <div className="min-h-0 flex-1 overflow-y-auto [scrollbar-width:thin]">
            <div className="mx-auto max-w-6xl space-y-5 px-4 py-5">
              {loading ? (
                <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                  {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
                    <div key={i} className="h-28 animate-pulse rounded-2xl bg-white/[0.05]" />
                  ))}
                </div>
              ) : (
                <>
                  {/* KPI */}
                  <section aria-label="Ringkasan sistem" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                    <StatCard
                      icon={<Thermometer className="h-3.5 w-3.5" />}
                      label="Suhu rata-rata"
                      value={avgTemp === null ? '—' : `${fmt(avgTemp)} °C`}
                      sub={`${sensors.filter((d) => d.metric === 'suhu').length} sensor suhu aktif`}
                    />
                    <StatCard
                      icon={<Droplets className="h-3.5 w-3.5" />}
                      label="Kelembapan"
                      value={avgHum === null ? '—' : `${fmt(avgHum)} %`}
                      sub={`${sensors.filter((d) => d.metric === 'kelembapan').length} sensor kelembapan`}
                    />
                    <StatCard
                      icon={<Zap className="h-3.5 w-3.5" />}
                      label="Aktuator aktif"
                      value={`${activeCount}/${actuators.length}`}
                      sub="perangkat output menyala"
                    />
                    <StatCard
                      icon={<Activity className="h-3.5 w-3.5" />}
                      label="Aturan aktif"
                      value={`${enabledRules}/${rules.length}`}
                      sub="mesin otomasi berjalan"
                    />
                  </section>

                  <div className="grid items-start gap-5 lg:grid-cols-[1fr_360px]">
                    {/* perangkat */}
                    <section aria-label="Perangkat terhubung">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="text-sm font-semibold text-white">Perangkat Terhubung</h2>
                        <span className="rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-200">
                          {devices.length} online
                        </span>
                      </div>
                      <p className="mt-1 text-[11px] leading-relaxed text-white/35">
                        Halo {firstName} — telemetri disimulasikan langsung di peramban dan status perangkat tersimpan di server,
                        siap dihubungkan ke perangkat fisik lewat API.
                      </p>

                      <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                        {sensors.map((d) => (
                          <SensorCard key={d.id} device={d} reading={readings[d.id]} />
                        ))}
                        {actuators.map((d) => (
                          <ActuatorCard key={d.id} device={d} onToggle={() => toggleDevice(d)} />
                        ))}
                      </div>
                    </section>

                    {/* aturan + aktivitas */}
                    <div className="space-y-5">
                      <section aria-label="Aturan otomasi" className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                        <div className="flex items-center justify-between gap-2">
                          <h2 className="text-sm font-semibold text-white">Aturan Otomasi</h2>
                          <span className="rounded-full border border-white/10 bg-white/[0.05] px-2 py-0.5 text-[10px] text-white/50">
                            {rules.length}/20
                          </span>
                        </div>
                        <p className="mt-0.5 text-[11px] leading-relaxed text-white/35">
                          JIKA kondisi sensor terpenuhi → aktuator bereaksi otomatis.
                        </p>

                        <div className="mt-3 max-h-64 space-y-2 overflow-y-auto pr-1 [scrollbar-width:thin]">
                          {rules.length === 0 ? (
                            <p className="rounded-xl border border-dashed border-white/10 px-3 py-6 text-center text-[11px] text-white/35">
                              Belum ada aturan. Buat aturan pertamamu di bawah.
                            </p>
                          ) : (
                            rules.map((r) => (
                              <RuleItem key={r.id} rule={r} onToggle={(v) => toggleRule(r, v)} onDelete={() => deleteRule(r)} />
                            ))
                          )}
                        </div>

                        <form onSubmit={createRule} className="mt-4 space-y-2.5 border-t border-white/10 pt-4">
                          <p className="text-[10.5px] font-semibold uppercase tracking-[0.18em] text-violet-300/80">Tambah aturan</p>
                          <Select value={fSensor} onValueChange={setFSensor}>
                            <SelectTrigger
                              aria-label="Pilih sensor"
                              className="h-9 rounded-xl border-white/10 bg-white/[0.05] text-xs text-white data-[placeholder]:text-white/35"
                            >
                              <SelectValue placeholder="Pilih sensor" />
                            </SelectTrigger>
                            <SelectContent className="border-white/10 bg-[#151020] text-white">
                              {sensors.map((s) => (
                                <SelectItem key={s.id} value={s.id} className="text-xs focus:bg-violet-500/25 focus:text-white">
                                  {s.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>

                          <div className="grid grid-cols-2 gap-2.5">
                            <Select value={fOp} onValueChange={setFOp}>
                              <SelectTrigger
                                aria-label="Operator perbandingan"
                                className="h-9 rounded-xl border-white/10 bg-white/[0.05] text-xs text-white data-[placeholder]:text-white/35"
                              >
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="border-white/10 bg-[#151020] text-white">
                                <SelectItem value=">" className="text-xs focus:bg-violet-500/25 focus:text-white">
                                  Lebih dari (&gt;)
                                </SelectItem>
                                <SelectItem value="<" className="text-xs focus:bg-violet-500/25 focus:text-white">
                                  Kurang dari (&lt;)
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              inputMode="decimal"
                              step="any"
                              placeholder="Ambang, mis. 28"
                              aria-label="Nilai ambang batas"
                              value={fThr}
                              onChange={(e) => setFThr(e.target.value)}
                              className="h-9 rounded-xl border-white/10 bg-white/[0.05] text-xs text-white placeholder:text-white/25 focus-visible:border-violet-400/60 focus-visible:ring-violet-500/25"
                            />
                          </div>

                          <Select value={fAct} onValueChange={setFAct}>
                            <SelectTrigger
                              aria-label="Pilih aktuator"
                              className="h-9 rounded-xl border-white/10 bg-white/[0.05] text-xs text-white data-[placeholder]:text-white/35"
                            >
                              <SelectValue placeholder="Pilih aktuator" />
                            </SelectTrigger>
                            <SelectContent className="border-white/10 bg-[#151020] text-white">
                              {actuators.map((a) => (
                                <SelectItem key={a.id} value={a.id} className="text-xs focus:bg-violet-500/25 focus:text-white">
                                  {a.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>

                          <Select value={fAction} onValueChange={setFAction}>
                            <SelectTrigger
                              aria-label="Aksi saat kondisi terpenuhi"
                              className="h-9 rounded-xl border-white/10 bg-white/[0.05] text-xs text-white data-[placeholder]:text-white/35"
                            >
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="border-white/10 bg-[#151020] text-white">
                              <SelectItem value="true" className="text-xs focus:bg-violet-500/25 focus:text-white">
                                Nyala saat terpenuhi
                              </SelectItem>
                              <SelectItem value="false" className="text-xs focus:bg-violet-500/25 focus:text-white">
                                Mati saat terpenuhi
                              </SelectItem>
                            </SelectContent>
                          </Select>

                          <Button
                            type="submit"
                            disabled={savingRule}
                            className="h-9 w-full rounded-xl bg-gradient-to-r from-violet-600 to-purple-500 text-xs font-semibold text-white shadow-[0_8px_30px_-8px_rgba(139,92,246,0.7)] hover:brightness-110 disabled:opacity-60"
                          >
                            {savingRule ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
                            Tambah Aturan
                          </Button>
                        </form>
                      </section>

                      <section aria-label="Aktivitas sistem" className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                        <h2 className="text-sm font-semibold text-white">Aktivitas Sistem</h2>
                        {logs.length === 0 ? (
                          <p className="mt-2 text-[11px] text-white/35">Belum ada aktivitas tercatat.</p>
                        ) : (
                          <ul className="mt-3 max-h-56 space-y-1.5 overflow-y-auto pr-1 [scrollbar-width:thin]">
                            {logs.map((l) => (
                              <li key={l.id} className="flex gap-2 text-[11px] leading-relaxed">
                                <span className="shrink-0 tabular-nums text-white/30">{l.time}</span>
                                <span
                                  className={
                                    l.kind === 'auto' ? 'text-violet-200/90' : l.kind === 'manual' ? 'text-emerald-200/90' : 'text-white/50'
                                  }
                                >
                                  {l.text}
                                </span>
                              </li>
                            ))}
                          </ul>
                        )}
                      </section>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
