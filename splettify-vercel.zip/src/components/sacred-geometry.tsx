/**
 * Sacred-geometry SVG icons recreated from the "Superconscious" design video:
 * thin-line mystical glyphs used as brand logo and feature-card icons.
 */

type IconProps = { className?: string };

/** Flower of Life — brand logo (7 overlapping circles + outer ring) */
export function FlowerOfLife({ className }: IconProps) {
  const cx = 20;
  const cy = 20;
  const r = 8.4;
  const petals = [0, 60, 120, 180, 240, 300].map((deg) => {
    const rad = (deg * Math.PI) / 180;
    return {
      x: +(cx + r * Math.cos(rad)).toFixed(2),
      y: +(cy + r * Math.sin(rad)).toFixed(2),
    };
  });
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.1"
      className={className}
      aria-hidden="true"
    >
      <circle cx={cx} cy={cy} r={r} />
      {petals.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={r} />
      ))}
      <circle cx={cx} cy={cy} r={17.6} strokeWidth="0.9" opacity="0.75" />
    </svg>
  );
}

/** Radiant spark burst — "Input Your Current Reality" icon */
export function SparkBurst({ className }: IconProps) {
  const rays = Array.from({ length: 12 }, (_, i) => {
    const a = (i * 30 * Math.PI) / 180;
    const inner = i % 2 === 0 ? 2.4 : 3.6;
    const outer = i % 2 === 0 ? 12.5 : 9.5;
    return {
      x1: +(16 + inner * Math.cos(a)).toFixed(2),
      y1: +(16 + inner * Math.sin(a)).toFixed(2),
      x2: +(16 + outer * Math.cos(a)).toFixed(2),
      y2: +(16 + outer * Math.sin(a)).toFixed(2),
    };
  });
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      className={className}
      aria-hidden="true"
    >
      {rays.map((l, i) => (
        <line key={i} x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2} />
      ))}
    </svg>
  );
}

/** Hexagon with inner hexagram — "AI Analyzes Subconscious Patterns" icon */
export function HexStar({ className }: IconProps) {
  const hex = Array.from({ length: 6 }, (_, i) => {
    const a = ((60 * i - 90) * Math.PI) / 180;
    return `${+(16 + 12 * Math.cos(a)).toFixed(2)},${+(16 + 12 * Math.sin(a)).toFixed(2)}`;
  }).join(' ');
  const tri1 = Array.from({ length: 3 }, (_, i) => {
    const a = ((120 * i - 90) * Math.PI) / 180;
    return `${+(16 + 6.4 * Math.cos(a)).toFixed(2)},${+(16 + 6.4 * Math.sin(a)).toFixed(2)}`;
  }).join(' ');
  const tri2 = Array.from({ length: 3 }, (_, i) => {
    const a = ((120 * i + 90) * Math.PI) / 180;
    return `${+(16 + 6.4 * Math.cos(a)).toFixed(2)},${+(16 + 6.4 * Math.sin(a)).toFixed(2)}`;
  }).join(' ');
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.1"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <polygon points={hex} />
      <polygon points={tri1} opacity="0.85" />
      <polygon points={tri2} opacity="0.85" />
    </svg>
  );
}

/** Lotus ring of circles — "AI Creates Your Journey" icon */
export function LotusRing({ className }: IconProps) {
  const nodes = Array.from({ length: 8 }, (_, i) => {
    const a = ((45 * i - 90) * Math.PI) / 180;
    return {
      x: +(16 + 6.2 * Math.cos(a)).toFixed(2),
      y: +(16 + 6.2 * Math.sin(a)).toFixed(2),
    };
  });
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.1"
      className={className}
      aria-hidden="true"
    >
      <circle cx="16" cy="16" r="2.1" />
      {nodes.map((n, i) => (
        <circle key={i} cx={n.x} cy={n.y} r="4.1" />
      ))}
    </svg>
  );
}

/** Trefoil knot (triquetra) — "Adapt and Grow" icon */
export function Triquetra({ className }: IconProps) {
  const nodes = [
    { x: 16, y: 11.2 },
    { x: 10.6, y: 20.8 },
    { x: 21.4, y: 20.8 },
  ];
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.1"
      className={className}
      aria-hidden="true"
    >
      {nodes.map((n, i) => (
        <circle key={i} cx={n.x} cy={n.y} r="7.4" />
      ))}
      <circle cx="16" cy="16" r="1.4" fill="currentColor" stroke="none" opacity="0.9" />
    </svg>
  );
}

/** Circular icon badge used on every floating card in the video */
export function IconBadge({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-violet-300/40 bg-violet-400/10 text-violet-200 shadow-[inset_0_0_12px_rgba(167,139,250,0.15)] ${className}`}
    >
      {children}
    </div>
  );
}
