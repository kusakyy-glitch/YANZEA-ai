'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import {
  Activity,
  ArrowLeft,
  ArrowUp,
  Clock3,
  Loader2,
  LogOut,
  Menu,
  MessageSquare,
  MessageSquarePlus,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { FlowerOfLife } from '@/components/sacred-geometry';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type AppUser = { id: string; name: string; email: string; role?: string };

type ConversationMeta = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
};

/* ---------------- riwayat pencarian (tersimpan di database) ---------------- */

type HistoryItem = { id: string; query: string; createdAt: string };
type SearchConvo = { id: string; title: string; updatedAt: string };
type SearchMsg = {
  id: string;
  role: string;
  content: string;
  createdAt: string;
  conversation: { id: string; title: string };
};
type SearchResults = { conversations: SearchConvo[]; messages: SearchMsg[] } | null;

function excerptAround(content: string, q: string) {
  const i = content.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return content.slice(0, 110);
  const start = Math.max(0, i - 32);
  const end = Math.min(content.length, i + q.length + 64);
  return `${start > 0 ? '…' : ''}${content.slice(start, end).replace(/\s+/g, ' ')}${end < content.length ? '…' : ''}`;
}

function histTime(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  return sameDay
    ? d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false })
    : d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
}

type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt?: string;
};

type StreamState = { text: string; shown: number } | null;

/* ------------------------------------------------------------------ */
/*  Markdown rendering                                                 */
/* ------------------------------------------------------------------ */

const mdComponents = {
  p: (p: React.HTMLAttributes<HTMLParagraphElement>) => (
    <p className="my-2 leading-relaxed first:mt-0 last:mb-0" {...p} />
  ),
  ul: (p: React.HTMLAttributes<HTMLUListElement>) => (
    <ul className="my-2 list-disc space-y-1 pl-5" {...p} />
  ),
  ol: (p: React.HTMLAttributes<HTMLOListElement>) => (
    <ol className="my-2 list-decimal space-y-1 pl-5" {...p} />
  ),
  li: (p: React.HTMLAttributes<HTMLLIElement>) => <li className="leading-relaxed" {...p} />,
  strong: (p: React.HTMLAttributes<HTMLElement>) => (
    <strong className="font-semibold text-white" {...p} />
  ),
  em: (p: React.HTMLAttributes<HTMLElement>) => <em className="italic" {...p} />,
  h1: (p: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h1 className="mt-4 mb-2 text-lg font-semibold text-white" {...p} />
  ),
  h2: (p: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h2 className="mt-4 mb-2 text-base font-semibold text-white" {...p} />
  ),
  h3: (p: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h3 className="mt-3 mb-1.5 text-sm font-semibold text-white" {...p} />
  ),
  a: (p: React.AnchorHTMLAttributes<HTMLAnchorElement>) => (
    <a className="text-violet-300 underline underline-offset-2" target="_blank" rel="noreferrer" {...p} />
  ),
  blockquote: (p: React.HTMLAttributes<HTMLQuoteElement>) => (
    <blockquote className="my-2 border-l-2 border-violet-400/50 pl-3 text-white/75 italic" {...p} />
  ),
  code: ({ className, children, ...rest }: React.HTMLAttributes<HTMLElement>) => {
    const isBlock = /language-/.test(className ?? '');
    if (isBlock) {
      return (
        <code className="block overflow-x-auto rounded-xl border border-white/10 bg-black/50 p-3 text-[12.5px] leading-relaxed text-violet-100" {...rest}>
          {children}
        </code>
      );
    }
    return (
      <code className="rounded-md border border-white/10 bg-black/40 px-1.5 py-0.5 text-[12.5px] text-violet-200" {...rest}>
        {children}
      </code>
    );
  },
  pre: (p: React.HTMLAttributes<HTMLPreElement>) => <pre className="my-2" {...p} />,
};

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function groupLabel(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const t = d.getTime();
  if (t >= startOfToday) return 'Hari Ini';
  if (t >= startOfToday - 86400000) return 'Kemarin';
  if (t >= startOfToday - 7 * 86400000) return '7 Hari Terakhir';
  return 'Lebih Lama';
}

const SUGGESTIONS = [
  {
    title: 'PLC, SCADA & HMI',
    prompt: 'Jelaskan perbedaan PLC, SCADA, dan HMI untuk pemula beserta contoh penggunaannya di pabrik.',
  },
  {
    title: 'Ide proyek IoT',
    prompt: 'Buatkan ide proyek IoT smart home sederhana berbasis ESP32 lengkap dengan daftar komponen dan langkahnya.',
  },
  {
    title: 'Protokol MQTT',
    prompt: 'Bagaimana cara kerja protokol MQTT pada sistem IIoT? Kapan sebaiknya dipakai dibanding Modbus?',
  },
  {
    title: 'Otomasi gudang',
    prompt: 'Rancang sistem otomasi sederhana untuk gudang pintar: sensor, aktuator, dan logika kontrolnya.',
  },
];

/* ------------------------------------------------------------------ */
/*  Main chat application                                              */
/* ------------------------------------------------------------------ */

export function ChatApp({
  user,
  onLogout,
  onOpenDashboard,
  onOpenAdmin,
}: {
  user: AppUser;
  onLogout: () => void;
  onOpenDashboard?: () => void;
  onOpenAdmin?: () => void;
}) {
  const { toast } = useToast();

  const [conversations, setConversations] = useState<ConversationMeta[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [activeId, setActiveId] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [stream, setStream] = useState<StreamState>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  /* pencarian + riwayat tersimpan di database */
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResults>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const skipLoadRef = useRef(false);
  const streamTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const firstName = user.name.split(' ')[0];

  /* ---------------- data loading ---------------- */

  const refreshConversations = useCallback(async () => {
    try {
      const res = await fetch('/api/conversations');
      if (res.status === 401) return onLogout();
      const data = await res.json();
      if (data.ok) setConversations(data.conversations);
    } catch {
      /* offline — biarkan daftar saat ini */
    } finally {
      setLoadingList(false);
    }
  }, [onLogout]);

  useEffect(() => {
    refreshConversations();
  }, [refreshConversations]);

  useEffect(() => {
    if (!activeId) {
      setMessages([]);
      return;
    }
    if (skipLoadRef.current) {
      skipLoadRef.current = false;
      return;
    }
    setLoadingMessages(true);
    fetch(`/api/conversations/${activeId}`)
      .then(async (res) => {
        if (res.status === 401) return onLogout();
        const data = await res.json();
        if (data.ok) setMessages(data.conversation.messages);
      })
      .catch(() => toast({ title: 'Tidak dapat memuat percakapan.', variant: 'destructive' }))
      .finally(() => setLoadingMessages(false));
  }, [activeId]);

  /* auto-scroll to the latest message */
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [messages, stream, loadingMessages, sending]);

  /* textarea auto-grow */
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }, [input]);

  useEffect(() => () => {
    if (streamTimer.current) clearInterval(streamTimer.current);
  }, []);

  /* ---------------- actions ---------------- */

  function startStream(text: string, done: () => void) {
    if (streamTimer.current) clearInterval(streamTimer.current);
    let shown = 0;
    setStream({ text, shown: 0 });
    streamTimer.current = setInterval(() => {
      shown += 4;
      if (shown >= text.length) {
        if (streamTimer.current) clearInterval(streamTimer.current);
        setStream(null);
        done();
      } else {
        setStream({ text, shown });
      }
    }, 14);
  }

  async function sendMessage(raw?: string) {
    const outgoing = (raw ?? input).trim();
    if (!outgoing || sending || stream) return;
    const wasNew = !activeId;
    const tempId = `temp-${Date.now()}`;

    setInput('');
    setSending(true);
    setMessages((m) => [...m, { id: tempId, role: 'user', content: outgoing }]);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversationId: activeId || undefined, message: outgoing }),
      });
      if (res.status === 401) return onLogout();
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.message || 'Gagal mengirim pesan.');

      setMessages((m) => [...m.filter((x) => x.id !== tempId), data.userMessage]);
      if (wasNew) {
        skipLoadRef.current = true;
        setActiveId(data.conversationId);
      }
      refreshConversations();
      setSending(false);
      startStream(data.assistantMessage.content, () => {
        setMessages((m) => [...m, data.assistantMessage]);
      });
    } catch (err) {
      setMessages((m) => m.filter((x) => x.id !== tempId));
      setInput(outgoing);
      setSending(false);
      toast({
        title: 'Pesan gagal terkirim',
        description: err instanceof Error ? err.message : 'Silakan coba lagi.',
        variant: 'destructive',
      });
    }
  }

  function newChat() {
    if (streamTimer.current) clearInterval(streamTimer.current);
    setStream(null);
    setSending(false);
    setActiveId('');
    setMessages([]);
    setSidebarOpen(false);
    textareaRef.current?.focus();
  }

  async function deleteConversation(id: string) {
    try {
      const res = await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
      if (res.status === 401) return onLogout();
      if (id === activeId) newChat();
      setConversations((c) => c.filter((x) => x.id !== id));
      toast({ title: 'Percakapan dihapus' });
    } catch {
      toast({ title: 'Tidak dapat menghapus percakapan.', variant: 'destructive' });
    }
  }

  async function logout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } finally {
      onLogout();
    }
  }

  /* ---------------- pencarian + riwayat ---------------- */

  function openSearchPanel() {
    setSearchOpen(true);
    setSearchResults(null);
    setSearchInput('');
    setHistoryLoading(true);
    fetch('/api/search')
      .then(async (res) => {
        if (res.status === 401) return onLogout();
        const d = await res.json();
        if (d.ok) setHistory(d.history);
      })
      .catch(() => {})
      .finally(() => setHistoryLoading(false));
  }

  function closeSearchPanel() {
    setSearchOpen(false);
    setSearchResults(null);
    setSearchInput('');
  }

  async function runSearch(raw?: string) {
    const q = (raw ?? searchInput).trim();
    if (!q || searching) return;
    setSearching(true);
    setSearchInput(q);
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q }),
      });
      if (res.status === 401) return onLogout();
      const d = await res.json();
      if (d.ok) {
        setSearchResults({ conversations: d.conversations, messages: d.messages });
        setHistory(d.history); // riwayat terbaru dari server (otomatis tersimpan)
      } else {
        toast({ title: d.message || 'Pencarian gagal.', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Koneksi bermasalah.', description: 'Silakan coba lagi.', variant: 'destructive' });
    } finally {
      setSearching(false);
    }
  }

  async function removeHistory(id: string) {
    try {
      const res = await fetch(`/api/search?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
      if (res.status === 401) return onLogout();
      const d = await res.json();
      if (d.ok) setHistory(d.history);
    } catch {
      /* diamkan — item tetap tampil sampai dimuat ulang */
    }
  }

  async function clearHistory() {
    try {
      const res = await fetch('/api/search', { method: 'DELETE' });
      if (res.status === 401) return onLogout();
      const d = await res.json();
      if (d.ok) {
        setHistory([]);
        toast({ title: 'Riwayat pencarian dihapus' });
      }
    } catch {
      toast({ title: 'Tidak dapat menghapus riwayat.', variant: 'destructive' });
    }
  }

  function openResult(conversationId: string) {
    closeSearchPanel();
    skipLoadRef.current = false;
    setActiveId(conversationId);
    setSidebarOpen(false);
  }

  /* ---------------- derived ---------------- */

  const activeTitle =
    conversations.find((c) => c.id === activeId)?.title ??
    (messages.length ? 'Percakapan baru' : 'Obrolan baru');

  const groups: { label: string; items: ConversationMeta[] }[] = [];
  for (const c of conversations) {
    const label = groupLabel(c.updatedAt);
    const last = groups[groups.length - 1];
    if (last && last.label === label) last.items.push(c);
    else groups.push({ label, items: [c] });
  }

  /* ---------------- render ---------------- */

  const sidebar = (
    <div className="flex h-full w-72 flex-col border-r border-white/[0.07] bg-[#0b0812]/95 backdrop-blur-xl">
      {/* brand */}
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <div className="flex items-center gap-2.5">
          <FlowerOfLife className="h-7 w-7 text-violet-300" />
          <span className="text-[15px] font-semibold tracking-tight text-white">splettify</span>
        </div>
        <button
          onClick={() => setSidebarOpen(false)}
          className="rounded-lg p-1.5 text-white/50 hover:bg-white/10 hover:text-white lg:hidden"
          aria-label="Tutup sidebar"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* search + new chat + dashboard nav */}
      <div className="px-3 pt-2">
        <button
          onClick={openSearchPanel}
          className="flex w-full items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5 text-sm text-white/45 transition-all hover:border-violet-300/30 hover:bg-violet-500/10 hover:text-white/75"
        >
          <Search className="h-4 w-4" />
          Cari obrolan…
        </button>
        <button
          onClick={newChat}
          className="mt-2 flex w-full items-center gap-2.5 rounded-xl border border-violet-400/25 bg-violet-500/15 px-3.5 py-2.5 text-sm font-medium text-violet-100 shadow-[0_0_24px_-6px_rgba(139,92,246,0.5)] transition-all hover:bg-violet-500/25"
        >
          <MessageSquarePlus className="h-4 w-4" />
          Obrolan baru
        </button>
        {user.role === 'ADMIN' && onOpenDashboard ? (
          <button
            onClick={() => {
              onOpenDashboard();
              setSidebarOpen(false);
            }}
            className="mt-2 flex w-full items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5 text-sm font-medium text-white/80 transition-all hover:border-violet-300/30 hover:bg-violet-500/10"
          >
            <Activity className="h-4 w-4 text-violet-300" />
            Dashboard IoT
            <span className="ml-auto rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-200">
              Admin
            </span>
          </button>
        ) : null}
        {user.role === 'ADMIN' && onOpenAdmin ? (
          <button
            onClick={() => {
              onOpenAdmin();
              setSidebarOpen(false);
            }}
            className="mt-2 flex w-full items-center gap-2.5 rounded-xl border border-amber-300/20 bg-amber-500/[0.08] px-3.5 py-2.5 text-sm font-medium text-amber-100 transition-all hover:border-amber-300/40 hover:bg-amber-500/15"
          >
            <ShieldCheck className="h-4 w-4 text-amber-300" />
            Panel Admin
            <span className="ml-auto rounded-full border border-amber-300/25 bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium text-amber-200">
              Khusus
            </span>
          </button>
        ) : null}
      </div>

      {/* search panel / conversation list */}
      <div className="mt-4 min-h-0 flex-1 overflow-y-auto px-3 pb-4 [scrollbar-width:thin]">
        {searchOpen ? (
          <SearchPanel
            input={searchInput}
            onInputChange={setSearchInput}
            onSubmit={() => runSearch()}
            searching={searching}
            results={searchResults}
            history={history}
            historyLoading={historyLoading}
            onBack={closeSearchPanel}
            onRunHistory={(q) => runSearch(q)}
            onRemoveHistory={removeHistory}
            onClearHistory={clearHistory}
            onOpenResult={openResult}
          />
        ) : loadingList ? (
          <div className="space-y-2 px-1">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-9 animate-pulse rounded-lg bg-white/[0.06]" />
            ))}
          </div>
        ) : conversations.length === 0 ? (
          <p className="px-2 pt-6 text-center text-xs leading-relaxed text-white/35">
            Belum ada percakapan.
            <br />
            Mulai perjalanan pertamamu di bawah ✨
          </p>
        ) : (
          groups.map((g) => (
            <div key={g.label}>
              <p className="px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/30">
                {g.label}
              </p>
              <div className="space-y-0.5">
                {g.items.map((c) => (
                  <div
                    key={c.id}
                    className={`group flex items-center gap-1 rounded-lg pr-1 transition-colors ${
                      c.id === activeId ? 'bg-violet-500/20' : 'hover:bg-white/[0.06]'
                    }`}
                  >
                    <button
                      onClick={() => {
                        skipLoadRef.current = false;
                        setActiveId(c.id);
                        setSidebarOpen(false);
                      }}
                      className="min-w-0 flex-1 truncate px-2.5 py-2 text-left text-[13px] text-white/80"
                      title={c.title}
                    >
                      {c.title}
                    </button>
                    <button
                      onClick={() => deleteConversation(c.id)}
                      aria-label={`Hapus "${c.title}"`}
                      className="rounded-md p-1.5 text-white/25 opacity-0 transition-all hover:bg-white/10 hover:text-rose-300 group-hover:opacity-100"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* user footer */}
      <div className="border-t border-white/[0.07] p-3">
        <div className="flex items-center gap-3 rounded-xl px-2 py-1.5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 text-sm font-semibold text-white">
            {firstName.charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13px] font-medium text-white">{user.name}</p>
            <p className="truncate text-[11px] text-white/40">{user.email}</p>
          </div>
          <button
            onClick={logout}
            aria-label="Keluar"
            title="Keluar"
            className="rounded-lg p-2 text-white/45 transition-colors hover:bg-white/10 hover:text-rose-300"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="relative h-dvh overflow-hidden">
      {/* purple ambience */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(110% 80% at 85% 0%, rgba(124,58,237,0.5) 0%, rgba(124,58,237,0) 55%),' +
            'radial-gradient(100% 90% at 10% 100%, rgba(91,33,182,0.65) 0%, rgba(18,11,30,0) 70%),' +
            'linear-gradient(160deg, #150d20 0%, #2a1458 50%, #3b1a78 100%)',
        }}
      />
      <div aria-hidden="true" className="absolute -right-40 -top-64 h-[820px] w-[820px] rounded-full border border-white/10" />
      <div aria-hidden="true" className="absolute -bottom-80 -left-52 h-[900px] w-[900px] rounded-full border border-white/[0.08]" />

      <div className="relative z-10 flex h-full p-0 sm:p-4 lg:p-5">
        <div className="flex h-full w-full overflow-hidden rounded-none border-0 bg-[#0d0a13]/95 shadow-[0_50px_140px_-30px_rgba(76,29,149,0.9)] backdrop-blur-xl sm:rounded-[28px] sm:border sm:border-violet-300/20">
          {/* sidebar — desktop */}
          <aside className="hidden lg:block">{sidebar}</aside>

          {/* sidebar — mobile drawer */}
          {sidebarOpen ? (
            <div className="fixed inset-0 z-40 lg:hidden">
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
              <div className="absolute left-0 top-0 h-full">{sidebar}</div>
            </div>
          ) : null}

          {/* main column */}
          <main className="flex min-w-0 flex-1 flex-col">
            {/* header */}
            <header className="flex items-center gap-3 border-b border-white/[0.07] px-4 py-3">
              <button
                onClick={() => setSidebarOpen(true)}
                aria-label="Buka sidebar"
                className="rounded-lg p-1.5 text-white/60 hover:bg-white/10 hover:text-white lg:hidden"
              >
                <Menu className="h-5 w-5" />
              </button>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-white">{activeTitle}</p>
              </div>
              <span className="hidden items-center gap-1.5 rounded-full border border-violet-300/25 bg-violet-500/10 px-3 py-1 text-[11px] font-medium text-violet-200 sm:flex">
                <Sparkles className="h-3 w-3" />
                Agent Splettify
              </span>
            </header>

            {/* messages */}
            <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto [scrollbar-width:thin]">
              {messages.length === 0 && !stream && !loadingMessages ? (
                <EmptyState firstName={firstName} onPick={(p) => sendMessage(p)} />
              ) : (
                <div className="mx-auto flex max-w-3xl flex-col gap-5 px-4 py-6">
                  {loadingMessages ? (
                    <div className="space-y-3 py-4">
                      {[0, 1].map((i) => (
                        <div key={i} className="h-16 animate-pulse rounded-2xl bg-white/[0.05]" />
                      ))}
                    </div>
                  ) : null}

                  {messages.map((m) =>
                    m.role === 'user' ? (
                      <div key={m.id} className="flex justify-end">
                        <div className="max-w-[85%] rounded-2xl rounded-br-md bg-gradient-to-br from-violet-600 to-violet-700 px-4 py-2.5 text-[14px] leading-relaxed whitespace-pre-wrap text-white shadow-[0_10px_30px_-10px_rgba(139,92,246,0.6)]">
                          {m.content}
                        </div>
                      </div>
                    ) : (
                      <AssistantBubble key={m.id} content={m.content} />
                    )
                  )}

                  {stream ? (
                    <AssistantBubble content={stream.text.slice(0, stream.shown)} streaming />
                  ) : sending ? (
                    <div className="flex items-center gap-2.5">
                      <AssistantAvatar />
                      <div className="flex items-center gap-1.5 rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-3">
                        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-300 [animation-delay:0ms]" />
                        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-300 [animation-delay:150ms]" />
                        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-300 [animation-delay:300ms]" />
                      </div>
                    </div>
                  ) : null}
                </div>
              )}
            </div>

            {/* composer */}
            <div className="border-t border-white/[0.07] px-4 py-3.5">
              <div className="mx-auto max-w-3xl">
                <div className="flex items-end gap-2 rounded-[22px] border border-white/10 bg-white/[0.05] p-2 pl-4 shadow-[0_10px_40px_-12px_rgba(0,0,0,0.6)] transition-colors focus-within:border-violet-400/50">
                  <Textarea
                    ref={textareaRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        sendMessage();
                      }
                    }}
                    rows={1}
                    placeholder="Kirim pesan ke Agent Splettify…"
                    aria-label="Pesan"
                    className="max-h-[180px] flex-1 resize-none border-0 bg-transparent px-0 py-2 text-[14px] text-white shadow-none focus-visible:ring-0 focus-visible:ring-offset-0 placeholder:text-white/25"
                  />
                  <Button
                    onClick={() => sendMessage()}
                    disabled={!input.trim() || sending || !!stream}
                    aria-label="Kirim pesan"
                    className="h-10 w-10 shrink-0 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 p-0 shadow-[0_0_24px_-4px_rgba(139,92,246,0.7)] hover:brightness-110 disabled:opacity-40"
                  >
                    {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="mt-2 text-center text-[10.5px] text-white/25">
                  Agent Splettify bisa keliru. Periksa kembali informasi penting.
                </p>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Sub-components                                                     */
/* ------------------------------------------------------------------ */

function AssistantAvatar() {
  return (
    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-violet-300/35 bg-violet-500/15 shadow-[inset_0_0_10px_rgba(167,139,250,0.2)]">
      <FlowerOfLife className="h-5 w-5 text-violet-200" />
    </div>
  );
}

function AssistantBubble({ content, streaming = false }: { content: string; streaming?: boolean }) {
  return (
    <div className="flex gap-3">
      <AssistantAvatar />
      <div className="min-w-0 max-w-[calc(100%-44px)] rounded-2xl rounded-tl-md border border-white/10 bg-white/[0.05] px-4 py-3 text-[14px] text-white/90">
        <ReactMarkdown components={mdComponents}>{content}</ReactMarkdown>
        {streaming ? <span className="ml-0.5 inline-block h-4 w-2 animate-pulse rounded-sm bg-violet-300 align-middle" /> : null}
      </div>
    </div>
  );
}

function EmptyState({ firstName, onPick }: { firstName: string; onPick: (prompt: string) => void }) {
  return (
    <div className="flex h-full flex-col items-center justify-center px-6 py-10 text-center">
      <div className="animate-floaty relative">
        <div className="absolute inset-0 -z-10 rounded-full bg-violet-600/30 blur-[60px]" />
        <FlowerOfLife className="h-20 w-20 text-violet-300" />
      </div>
      <p className="mt-3 text-[11px] font-medium uppercase tracking-[0.3em] text-violet-300/80">
        AI Agent Pintarmu
      </p>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
        Selamat datang, {firstName}
      </h1>
      <p className="mt-2 max-w-md text-sm text-white/50">
        Tanyakan apa saja — otomasi, IIoT, IoT, atau pekerjaan harianmu. Splettify siap membantu 24/7.
      </p>

      <div className="mt-8 grid w-full max-w-xl grid-cols-1 gap-2.5 sm:grid-cols-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s.title}
            onClick={() => onPick(s.prompt)}
            className="group rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-left transition-all hover:border-violet-300/40 hover:bg-violet-500/10"
          >
            <p className="text-[13px] font-medium text-white/90">{s.title}</p>
            <p className="mt-0.5 line-clamp-2 text-[11.5px] leading-relaxed text-white/40 group-hover:text-white/55">
              {s.prompt}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Panel pencarian + riwayat (tersimpan otomatis di database)         */
/* ------------------------------------------------------------------ */

function SearchPanel({
  input,
  onInputChange,
  onSubmit,
  searching,
  results,
  history,
  historyLoading,
  onBack,
  onRunHistory,
  onRemoveHistory,
  onClearHistory,
  onOpenResult,
}: {
  input: string;
  onInputChange: (v: string) => void;
  onSubmit: () => void;
  searching: boolean;
  results: SearchResults;
  history: HistoryItem[];
  historyLoading: boolean;
  onBack: () => void;
  onRunHistory: (q: string) => void;
  onRemoveHistory: (id: string) => void;
  onClearHistory: () => void;
  onOpenResult: (conversationId: string) => void;
}) {
  return (
    <div className="space-y-4">
      {/* input pencarian */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit();
        }}
      >
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onBack}
            aria-label="Kembali ke daftar obrolan"
            className="rounded-lg p-1.5 text-white/50 transition-colors hover:bg-white/10 hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/30" />
            <input
              value={input}
              onChange={(e) => onInputChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') onBack();
              }}
              placeholder="Cari pesan & obrolan…"
              aria-label="Kata kunci pencarian"
              autoFocus
              className="h-9 w-full rounded-lg border border-white/10 bg-white/[0.05] pr-3 text-[13px] text-white placeholder:text-white/25 focus:border-violet-400/50 focus:outline-none"
              style={{ paddingLeft: '2rem' }}
            />
          </div>
        </div>
      </form>

      {searching ? (
        <div className="space-y-2 px-1">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-10 animate-pulse rounded-lg bg-white/[0.06]" />
          ))}
        </div>
      ) : results ? (
        <>
          {results.conversations.length === 0 && results.messages.length === 0 ? (
            <p className="px-2 pt-4 text-center text-xs leading-relaxed text-white/35">
              Tidak ada hasil untuk “{input.slice(0, 40)}”.
            </p>
          ) : null}

          {results.conversations.length > 0 ? (
            <div>
              <p className="px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/30">
                Percakapan ({results.conversations.length})
              </p>
              <div className="space-y-0.5">
                {results.conversations.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => onOpenResult(c.id)}
                    className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-white/[0.07]"
                  >
                    <MessageSquare className="h-3.5 w-3.5 shrink-0 text-violet-300" />
                    <span className="min-w-0 flex-1 truncate text-[13px] text-white/85">{c.title}</span>
                    <span className="shrink-0 text-[10px] text-white/30">{histTime(c.updatedAt)}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {results.messages.length > 0 ? (
            <div>
              <p className="px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/30">
                Pesan ({results.messages.length})
              </p>
              <div className="space-y-0.5">
                {results.messages.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => onOpenResult(m.conversation.id)}
                    className="w-full rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-white/[0.07]"
                  >
                    <p className="flex items-center gap-2 text-[10px] text-white/35">
                      <span
                        className={`rounded-full px-1.5 py-0.5 text-[9px] font-medium ${
                          m.role === 'user'
                            ? 'border border-violet-300/25 bg-violet-500/10 text-violet-200'
                            : 'border border-white/15 bg-white/[0.06] text-white/55'
                        }`}
                      >
                        {m.role === 'user' ? 'Kamu' : 'Splettify'}
                      </span>
                      <span className="truncate">{m.conversation.title}</span>
                    </p>
                    <p className="mt-1 line-clamp-2 text-[12px] leading-relaxed text-white/70">
                      {excerptAround(m.content, input)}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          ) : null}
        </>
      ) : (
        /* ---------- riwayat pencarian ---------- */
        <div>
          <div className="flex items-center justify-between px-2 pb-1.5">
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/30">
              Riwayat pencarian
            </p>
            {history.length > 0 ? (
              <button
                type="button"
                onClick={onClearHistory}
                className="text-[10px] font-medium text-rose-300/80 transition-colors hover:text-rose-200"
              >
                Hapus semua
              </button>
            ) : null}
          </div>

          {historyLoading ? (
            <div className="space-y-2 px-1">
              {[0, 1].map((i) => (
                <div key={i} className="h-9 animate-pulse rounded-lg bg-white/[0.06]" />
              ))}
            </div>
          ) : history.length === 0 ? (
            <p className="px-2 pt-4 text-center text-xs leading-relaxed text-white/35">
              Belum ada riwayat pencarian.
              <br />
              Setiap pencarianmu otomatis tersimpan di akun.
            </p>
          ) : (
            <div className="space-y-0.5">
              {history.map((h) => (
                <div
                  key={h.id}
                  className="group flex items-center gap-1 rounded-lg pr-1 transition-colors hover:bg-white/[0.07]"
                >
                  <button
                    type="button"
                    onClick={() => onRunHistory(h.query)}
                    className="flex min-w-0 flex-1 items-center gap-2.5 px-2.5 py-2 text-left"
                    title={`Cari lagi: ${h.query}`}
                  >
                    <Clock3 className="h-3.5 w-3.5 shrink-0 text-white/30" />
                    <span className="min-w-0 flex-1 truncate text-[13px] text-white/80">{h.query}</span>
                    <span className="shrink-0 text-[10px] text-white/30">{histTime(h.createdAt)}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onRemoveHistory(h.id)}
                    aria-label={`Hapus riwayat "${h.query}"`}
                    className="rounded-md p-1.5 text-white/25 opacity-0 transition-all hover:bg-white/10 hover:text-rose-300 group-hover:opacity-100"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
          <p className="mt-3 px-2 text-[10px] leading-relaxed text-white/25">
            Riwayat tersimpan otomatis di database, khusus untuk akunmu.
          </p>
        </div>
      )}
    </div>
  );
}
