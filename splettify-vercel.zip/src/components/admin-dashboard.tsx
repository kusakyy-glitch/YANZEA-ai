'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  ArrowLeft,
  BadgeCheck,
  Cpu,
  Droplets,
  Fan,
  Gauge,
  KeyRound,
  Lightbulb,
  Loader2,
  LogOut,
  MessagesSquare,
  MoveHorizontal,
  Siren,
  Sun,
  Thermometer,
  Users,
  Waves,
  Workflow,
  Zap,
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { FlowerOfLife } from '@/components/sacred-geometry';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type AdminUserInfo = {
  id: string;
  name: string;
  email: string;
  role: string;
  emailVerified: boolean;
  googleId: string | null;
  createdAt: string;
  _count: { conversations: number; devices: number };
};

export type AdminDevice = {
  id: string;
  name: string;
  kind: string; // "sensor" | "aktuator"
  metric: string | null;
  unit: string | null;
  zone: string;
  baseValue: number;
  amplitude: number;
  isOn: boolean;
  user: { name: string; email: string };
};

export type AdminRule = {
  id: string;
  name: string;
  operator: string; // ">" | "<"
  threshold: number;
  action: boolean; // true = nyalakan
  enabled: boolean;
  sensor: { id: string; name: string; unit: string | null };
  actuator: { id: string; name: string };
  user: { name: string; email: string };
};

export type AdminStats = {
  totalUsers: number;
  verifiedUsers: number;
  googleUsers: number;
  totalDevices: number;
  sensors: number;
  actuators: number;
  actuatorsOn: number;
  totalRules: number;
  activeRules: number;
  totalConversations: number;
  totalMessages: number;
  googleOAuthConfigured: boolean;
  mailProviderConfigured: boolean;
};

type AdminUserProp = { id: string; name: string; email: string; role?: string };

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

const fmt = (n: number) => n.toLocaleString('id-ID', { maximumFractionDigits: 1 });

function SensorGlyph({ metric, className }: { metric: string | null; className?: string }) {
  switch (metric) {
    case 'suhu':
      return <Thermometer className={className} />;
    case 'kelembapan':
      return <Droplets className={className} />;
    case 'tekanan':
      return <Gauge className={className} />;
    case 'arus':
      return <Zap className={className} />;
    case 'level':
      return <Waves className={className} />;
    case 'cahaya':
      return <Sun className={className} />;
    default:
      return <Activity className={className} />;
  }
}

function ActuatorGlyph({ name, className }: { name: string; className?: string }) {
  const n = name.toLowerCase();
  if (n.includes('kipas') || n.includes('pendingin')) return <Fan className={className} />;
  if (n.includes('pompa')) return <Droplets className={className} />;
  if (n.includes('conveyor')) return <MoveHorizontal className={className} />;
  if (n.includes('lampu')) return <Lightbulb className={className} />;
  if (n.includes('alarm')) return <Siren className={className} />;
  return <Cpu className={className} />;
}

/** Simulasi telemetri (pola sama dengan dashboard IoT pengguna). */
function simValue(device: AdminDevice, tSec: number, index: number): number {
  const period = 90 + index * 22;
  const phase = index * 1.7;
  const slow = Math.sin((tSec / period) * Math.PI * 2 + phase);
  const wobble = Math.sin(tSec / 7 + index) * 0.06;
  const noise = (Math.random() - 0.5) * 0.05;
  return Math.max(0, device.baseValue + device.amplitude * (slow + wobble + noise));
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
      <div className="flex items-center gap-2 text-white/50">
        <span className="text-violet-300">{icon}</span>
        <p className="text-[10.5px] font-medium uppercase tracking-wider">{label}</p>
      </div>
      <p className="mt-2 text-2xl font-semibold tracking-tight text-white">{value}</p>
      <p className="mt-0.5 text-[10.5px] text-white/35">{sub}</p>
    </div>
  );
}

function RoleBadge({ role }: { role: string }) {
  if (role === 'ADMIN') {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/25 bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium text-amber-200">
        <BadgeCheck className="h-3 w-3" /> Admin
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-white/15 bg-white/[0.06] px-2 py-0.5 text-[10px] font-medium text-white/60">
      Pengguna
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Status integrasi (Google OAuth & email)                            */
/* ------------------------------------------------------------------ */

function IntegrationCard({ stats }: { stats: AdminStats }) {
  // Komponen ini hanya dirender di klien (setelah sesi dimuat), jadi window aman diakses.
  const [origin] = useState(() => (typeof window === 'undefined' ? '' : window.location.origin));

  const oauthActive = stats.googleOAuthConfigured;

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-violet-300/20 bg-violet-500/10 text-violet-200">
            <KeyRound className="h-4 w-4" />
          </span>
          <div>
            <p className="text-sm font-medium text-white">Integrasi Google OAuth</p>
            <p className="text-[11px] text-white/40">Tombol “Lanjutkan dengan Google” di halaman masuk &amp; daftar</p>
          </div>
        </div>
        {oauthActive ? (
          <span className="flex items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-medium text-emerald-200">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> Aktif — kredensial terpasang
          </span>
        ) : (
          <span className="flex items-center gap-1.5 rounded-full border border-amber-300/25 bg-amber-500/10 px-2.5 py-1 text-[11px] font-medium text-amber-200">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" /> Mode simulasi
          </span>
        )}
      </div>

      {oauthActive ? (
        <p className="mt-4 text-xs leading-relaxed text-white/55">
          Kredensial <span className="font-mono text-violet-200">GOOGLE_CLIENT_ID</span> dan{' '}
          <span className="font-mono text-violet-200">GOOGLE_CLIENT_SECRET</span> sudah terpasang. Pengunjung kini
          diarahkan ke halaman login Google sungguhan. Pastikan redirect URI{' '}
          <span className="font-mono text-violet-200">https://www.splettify.co.id/api/auth/google/callback</span> dan{' '}
          <span className="font-mono text-violet-200">{origin || '…'}/api/auth/google/callback</span> terdaftar di
          Google Cloud Console.
        </p>
      ) : (
        <>
          <p className="mt-4 text-xs leading-relaxed text-white/55">
            Untuk mengaktifkan “Masuk dengan Google” sungguhan, buat <b>OAuth Client ID</b> gratis di Google Cloud
            Console (kunci ini hanya bisa dibuat dari akun Google milikmu sendiri, ±5 menit):
          </p>
          <ol className="mt-3 space-y-1.5 text-xs leading-relaxed text-white/60">
            <li>
              <span className="mr-1.5 font-semibold text-violet-300">1.</span>
              Buka <span className="font-mono text-violet-200">console.cloud.google.com</span> → buat project, mis.{' '}
              <i>Splettify Web</i>.
            </li>
            <li>
              <span className="mr-1.5 font-semibold text-violet-300">2.</span>
              Menu <b>APIs &amp; Services → OAuth consent screen</b> → pilih <i>External</i> → isi nama aplikasi &amp;
              email.
            </li>
            <li>
              <span className="mr-1.5 font-semibold text-violet-300">3.</span>
              Tab <b>Credentials → Create Credentials → OAuth client ID</b> → jenis <i>Web application</i>.
            </li>
            <li>
              <span className="mr-1.5 font-semibold text-violet-300">4.</span>
              Isi <b>Authorized redirect URI</b> (domain final):
              <span className="mt-1 block font-mono break-all text-violet-200">
                https://www.splettify.co.id/api/auth/google/callback
              </span>
              <span className="mt-1 block text-white/45">
                Selama masih tahap development/preview, daftarkan juga URL yang sedang dipakai sekarang:
                <span className="block font-mono break-all text-violet-200/80">
                  {origin || '…'}/api/auth/google/callback
                </span>
              </span>
            </li>
            <li>
              <span className="mr-1.5 font-semibold text-violet-300">5.</span>
              Salin <span className="font-mono">Client ID</span> &amp; <span className="font-mono">Client secret</span>{' '}
              ke file <span className="font-mono">.env</span> sebagai{' '}
              <span className="font-mono text-violet-200">GOOGLE_CLIENT_ID</span> dan{' '}
              <span className="font-mono text-violet-200">GOOGLE_CLIENT_SECRET</span>, lalu restart server.
            </li>
          </ol>
          <p className="mt-3 text-[11px] leading-relaxed text-white/35">
            Selama kredensial belum diisi, tombol Google memakai mode simulasi (pemilih akun tiruan) agar alur tetap
            bisa diuji tanpa kunci asli.
          </p>
        </>
      )}

      <div className="mt-4 flex flex-wrap gap-2 border-t border-white/[0.07] pt-4">
        <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] text-white/60">
          <Activity className="h-3 w-3 text-violet-300" />
          Email:{' '}
          {stats.mailProviderConfigured ? (
            <span className="text-emerald-300">Resend aktif</span>
          ) : (
            <span className="text-amber-200">mode simulasi</span>
          )}
        </span>
        <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] text-white/60">
          <Users className="h-3 w-3 text-violet-300" />
          {stats.googleUsers} akun via Google
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Tables                                                             */
/* ------------------------------------------------------------------ */

function DevicesTable({ devices, live }: { devices: AdminDevice[]; live: Record<string, number> }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.03]">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead>
          <tr className="border-b border-white/[0.08] text-[10.5px] uppercase tracking-wider text-white/40">
            <th className="px-4 py-3 font-medium">Perangkat</th>
            <th className="px-4 py-3 font-medium">Jenis</th>
            <th className="px-4 py-3 font-medium">Zona</th>
            <th className="px-4 py-3 font-medium">Pemilik</th>
            <th className="px-4 py-3 text-right font-medium">Nilai / Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/[0.05]">
          {devices.map((d) => (
            <tr key={d.id} className="transition-colors hover:bg-white/[0.03]">
              <td className="px-4 py-3">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-violet-300/20 bg-violet-500/10 text-violet-200">
                    {d.kind === 'sensor' ? (
                      <SensorGlyph metric={d.metric} className="h-4 w-4" />
                    ) : (
                      <ActuatorGlyph name={d.name} className="h-4 w-4" />
                    )}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-medium text-white">{d.name}</p>
                    {d.kind === 'sensor' ? (
                      <p className="text-[10.5px] text-white/35">{d.metric}</p>
                    ) : null}
                  </div>
                </div>
              </td>
              <td className="px-4 py-3">
                <span
                  className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${
                    d.kind === 'sensor'
                      ? 'border-violet-300/25 bg-violet-500/10 text-violet-200'
                      : 'border-sky-300/25 bg-sky-500/10 text-sky-200'
                  }`}
                >
                  {d.kind === 'sensor' ? 'Sensor' : 'Aktuator'}
                </span>
              </td>
              <td className="px-4 py-3 text-white/60">{d.zone}</td>
              <td className="px-4 py-3">
                <p className="text-white/70">{d.user.name}</p>
                <p className="text-[10.5px] text-white/35">{d.user.email}</p>
              </td>
              <td className="px-4 py-3 text-right">
                {d.kind === 'sensor' ? (
                  <span className="font-mono text-[15px] font-semibold text-white">
                    {live[d.id] !== undefined ? fmt(live[d.id]) : '—'}
                    <span className="ml-1 text-[11px] font-normal text-white/40">{d.unit}</span>
                  </span>
                ) : d.isOn ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-medium text-emerald-200">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" /> Menyala
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.05] px-2.5 py-1 text-[11px] font-medium text-white/50">
                    <span className="h-1.5 w-1.5 rounded-full bg-white/40" /> Mati
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function RulesTable({ rules }: { rules: AdminRule[] }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.03]">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead>
          <tr className="border-b border-white/[0.08] text-[10.5px] uppercase tracking-wider text-white/40">
            <th className="px-4 py-3 font-medium">Aturan</th>
            <th className="px-4 py-3 font-medium">Kondisi (sensor)</th>
            <th className="px-4 py-3 font-medium">Aksi (aktuator)</th>
            <th className="px-4 py-3 font-medium">Pemilik</th>
            <th className="px-4 py-3 text-right font-medium">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/[0.05]">
          {rules.map((r) => (
            <tr key={r.id} className="transition-colors hover:bg-white/[0.03]">
              <td className="px-4 py-3 font-medium text-white">{r.name}</td>
              <td className="px-4 py-3">
                <span className="font-mono text-xs text-violet-200">
                  {r.sensor.name} {r.operator} {fmt(r.threshold)} {r.sensor.unit ?? ''}
                </span>
              </td>
              <td className="px-4 py-3 text-white/70">
                {r.actuator.name}{' '}
                <span className={`text-xs font-medium ${r.action ? 'text-emerald-300' : 'text-rose-300'}`}>
                  → {r.action ? 'Nyalakan' : 'Matikan'}
                </span>
              </td>
              <td className="px-4 py-3">
                <p className="text-white/70">{r.user.name}</p>
                <p className="text-[10.5px] text-white/35">{r.user.email}</p>
              </td>
              <td className="px-4 py-3 text-right">
                {r.enabled ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-medium text-emerald-200">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> Aktif
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.05] px-2.5 py-1 text-[11px] font-medium text-white/50">
                    Nonaktif
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function UsersTable({ users }: { users: AdminUserInfo[] }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.03]">
      <table className="w-full min-w-[760px] text-left text-sm">
        <thead>
          <tr className="border-b border-white/[0.08] text-[10.5px] uppercase tracking-wider text-white/40">
            <th className="px-4 py-3 font-medium">Pengguna</th>
            <th className="px-4 py-3 font-medium">Peran</th>
            <th className="px-4 py-3 font-medium">Email</th>
            <th className="px-4 py-3 text-center font-medium">Data</th>
            <th className="px-4 py-3 text-right font-medium">Terdaftar</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/[0.05]">
          {users.map((u) => (
            <tr key={u.id} className="transition-colors hover:bg-white/[0.03]">
              <td className="px-4 py-3">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-violet-300/25 bg-violet-500/15 text-[11px] font-semibold text-violet-100">
                    {u.name.slice(0, 1).toUpperCase()}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-medium text-white">{u.name}</p>
                    <p className="truncate text-[10.5px] text-white/35">{u.email}</p>
                  </div>
                </div>
              </td>
              <td className="px-4 py-3">
                <RoleBadge role={u.role} />
              </td>
              <td className="px-4 py-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  {u.emailVerified ? (
                    <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300/25 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-200">
                      <BadgeCheck className="h-3 w-3" /> Terverifikasi
                    </span>
                  ) : (
                    <span className="rounded-full border border-amber-300/25 bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium text-amber-200">
                      Belum verifikasi
                    </span>
                  )}
                  {u.googleId ? (
                    <span className="rounded-full border border-white/15 bg-white/[0.06] px-2 py-0.5 text-[10px] font-medium text-white/60">
                      Google
                    </span>
                  ) : null}
                </div>
              </td>
              <td className="px-4 py-3 text-center text-xs text-white/55">
                {u._count.conversations} obrolan · {u._count.devices} perangkat
              </td>
              <td className="px-4 py-3 text-right text-xs text-white/45">{formatDate(u.createdAt)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main dashboard                                                     */
/* ------------------------------------------------------------------ */

export function AdminDashboard({
  user,
  onBack,
  onOpenIot,
  onLogout,
}: {
  user: AdminUserProp;
  onBack: () => void;
  onOpenIot: () => void;
  onLogout: () => void;
}) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUserInfo[]>([]);
  const [devices, setDevices] = useState<AdminDevice[]>([]);
  const [rules, setRules] = useState<AdminRule[]>([]);
  const [tick, setTick] = useState(0);

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await fetch('/api/admin/overview', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.message || 'Gagal memuat data admin.');
        return;
      }
      setStats(data.stats);
      setUsers(data.users);
      setDevices(data.devices);
      setRules(data.rules);
    } catch {
      setError('Koneksi bermasalah. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  /* telemetri live untuk sensor */
  useEffect(() => {
    const t = setInterval(() => setTick((v) => v + 1), 2000);
    return () => clearInterval(t);
  }, []);

  const liveValues = useMemo(() => {
    const tSec = Date.now() / 1000;
    const map: Record<string, number> = {};
    devices.forEach((d, i) => {
      if (d.kind === 'sensor') map[d.id] = simValue(d, tSec, i);
    });
    return map;
  }, [devices, tick]);

  async function logout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } finally {
      onLogout();
    }
  }

  const sensors = devices.filter((d) => d.kind === 'sensor');

  return (
    <div className="relative flex min-h-dvh flex-col bg-[#0d0a13]">
      {/* ambient glows */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -right-32 -top-40 h-[420px] w-[420px] rounded-full bg-violet-700/25 blur-[130px]" />
        <div className="absolute -left-40 top-1/3 h-[380px] w-[380px] rounded-full bg-purple-700/20 blur-[130px]" />
        <FlowerOfLife className="absolute -bottom-24 -right-24 h-96 w-96 text-violet-500/[0.05]" />
      </div>

      {/* header */}
      <header className="sticky top-0 z-20 border-b border-white/[0.07] bg-[#0b0812]/90 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <FlowerOfLife className="h-7 w-7 text-violet-300" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[15px] font-semibold tracking-tight text-white">splettify</span>
                <span className="rounded-full border border-amber-300/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber-200">
                  Panel Admin
                </span>
              </div>
              <p className="text-[10.5px] text-white/40">Monitoring IIoT · Otomasi · IoT</p>
            </div>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <span className="hidden text-right sm:block">
              <span className="block text-xs font-medium text-white/85">{user.name}</span>
              <span className="block text-[10.5px] text-white/40">{user.email}</span>
            </span>
            <Button
              variant="outline"
              onClick={onOpenIot}
              className="h-9 rounded-xl border-white/10 bg-white/[0.05] px-3 text-xs text-white/85 hover:bg-white/[0.1] hover:text-white"
            >
              <Activity className="h-3.5 w-3.5 text-violet-300" /> Dashboard IoT
            </Button>
            <Button
              variant="outline"
              onClick={onBack}
              className="h-9 rounded-xl border-white/10 bg-white/[0.05] px-3 text-xs text-white/85 hover:bg-white/[0.1] hover:text-white"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Chat AI
            </Button>
            <Button
              variant="outline"
              onClick={logout}
              aria-label="Keluar"
              className="h-9 rounded-xl border-rose-300/20 bg-rose-500/[0.08] px-3 text-xs text-rose-200 hover:bg-rose-500/15 hover:text-rose-100"
            >
              <LogOut className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Keluar</span>
            </Button>
          </div>
        </div>
      </header>

      {/* content */}
      <main className="relative z-10 mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6">
        {loading ? (
          <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-white/50">
            <Loader2 className="h-7 w-7 animate-spin text-violet-300" />
            <p className="text-sm">Memuat data monitoring…</p>
          </div>
        ) : error ? (
          <div className="mx-auto mt-16 max-w-md rounded-2xl border border-rose-400/20 bg-rose-500/10 p-6 text-center">
            <p className="text-sm font-medium text-rose-200">{error}</p>
            <Button
              onClick={load}
              className="mt-4 h-10 rounded-xl bg-gradient-to-r from-violet-600 to-purple-500 text-xs font-semibold text-white"
            >
              Coba lagi
            </Button>
          </div>
        ) : stats ? (
          <div className="space-y-6">
            {/* stat cards */}
            <section aria-label="Ringkasan" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              <StatCard
                icon={<Users className="h-4 w-4" />}
                label="Pengguna"
                value={String(stats.totalUsers)}
                sub={`${stats.verifiedUsers} terverifikasi · ${stats.googleUsers} via Google`}
              />
              <StatCard
                icon={<Cpu className="h-4 w-4" />}
                label="Perangkat IIoT/IoT"
                value={String(stats.totalDevices)}
                sub={`${stats.sensors} sensor · ${stats.actuators} aktuator`}
              />
              <StatCard
                icon={<Workflow className="h-4 w-4" />}
                label="Aturan Otomasi"
                value={`${stats.activeRules}/${stats.totalRules}`}
                sub="aktif / total terpasang"
              />
              <StatCard
                icon={<MessagesSquare className="h-4 w-4" />}
                label="Aktivitas AI"
                value={String(stats.totalConversations)}
                sub={`${stats.totalMessages} pesan terkirim`}
              />
            </section>

            {/* integrations */}
            <IntegrationCard stats={stats} />

            {/* tabs */}
            <Tabs defaultValue="perangkat" className="w-full">
              <TabsList className="h-auto w-full justify-start gap-1 rounded-2xl border border-white/10 bg-white/[0.04] p-1 sm:w-auto">
                <TabsTrigger
                  value="perangkat"
                  className="rounded-xl px-3.5 py-2 text-xs font-medium text-white/60 data-[state=active]:bg-violet-500/20 data-[state=active]:text-white"
                >
                  <Cpu className="mr-1.5 h-3.5 w-3.5" /> Perangkat ({devices.length})
                </TabsTrigger>
                <TabsTrigger
                  value="otomasi"
                  className="rounded-xl px-3.5 py-2 text-xs font-medium text-white/60 data-[state=active]:bg-violet-500/20 data-[state=active]:text-white"
                >
                  <Workflow className="mr-1.5 h-3.5 w-3.5" /> Otomasi ({rules.length})
                </TabsTrigger>
                <TabsTrigger
                  value="pengguna"
                  className="rounded-xl px-3.5 py-2 text-xs font-medium text-white/60 data-[state=active]:bg-violet-500/20 data-[state=active]:text-white"
                >
                  <Users className="mr-1.5 h-3.5 w-3.5" /> Pengguna ({users.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="perangkat" className="mt-4 space-y-4">
                <p className="text-xs leading-relaxed text-white/45">
                  Semua perangkat sensor &amp; aktuator terdaftar di sistem. Nilai sensor diperbarui live setiap 2
                  detik (telemetri simulasi), sama seperti dashboard IoT pengguna.
                </p>
                <DevicesTable devices={devices} live={liveValues} />
                {sensors.length > 0 ? (
                  <p className="text-[11px] text-white/35">
                    {stats.actuatorsOn} dari {stats.actuators} aktuator sedang menyala.
                  </p>
                ) : null}
              </TabsContent>

              <TabsContent value="otomasi" className="mt-4 space-y-4">
                <p className="text-xs leading-relaxed text-white/45">
                  Logika otomatis 24/7: ketika kondisi sensor terpenuhi, aktuator dikendalikan otomatis.
                </p>
                <RulesTable rules={rules} />
              </TabsContent>

              <TabsContent value="pengguna" className="mt-4 space-y-4">
                <p className="text-xs leading-relaxed text-white/45">
                  Semua akun terdaftar beserta status verifikasi email, metode pendaftaran, dan jumlah datanya.
                </p>
                <UsersTable users={users} />
              </TabsContent>
            </Tabs>
          </div>
        ) : null}
      </main>

      <footer className="relative z-10 mt-auto border-t border-white/[0.06] py-5 text-center">
        <p className="text-xs tracking-wide text-white/40">
          © 2026 Splettify · splettify.co.id — Panel Admin — AI Agent Otomasi, IIoT &amp; IoT
        </p>
      </footer>
    </div>
  );
}
