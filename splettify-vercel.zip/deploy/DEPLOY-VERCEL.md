# Deploy Vercel — Splettify di splettify.vercel.app (GRATIS)

Target: aplikasi live di URL gratis **`splettify.vercel.app`** dengan database cloud
**Turso** (SQLite di cloud, gratis). Kode aplikasi sudah siap 100% — tinggal ikuti
langkah di bawah (~30 menit).

> ✅ **Sudah diuji di sandbox:** dump data valid (9/9 tabel identik), jalur adapter
> Turso teruji (login + API 200), jalur SQLite lokal tetap normal, lint bersih.

---

## Ringkasan alur

```
Download source (zip) → Upload GitHub → Import Vercel → Buat Turso → Isi env → Live 🎉
```

---

## Langkah 1 — Download & upload ke GitHub

1. Download `splettify-vercel.zip` (dari halaman chat ini), lalu **ekstrak** di komputermu.
2. Buka [github.com/new](https://github.com/new) → buat repo baru, nama: `splettify`,
   visibilitas **Private** (disarankan) → Create.
3. Upload semua file & folder hasil ekstrak ke repo itu
   (di halaman repo: *uploading an existing file* → drag semua isi folder → Commit).
   - Jangan upload folder `node_modules` atau `.next` (memang tidak ada di zip).
4. *(Alternatif tanpa GitHub: install [Vercel CLI](https://vercel.com/cli), lalu di
   folder hasil ekstrak jalankan `npx vercel` dan ikuti petunjuknya — langsung deploy.)*

## Langkah 2 — Buat database Turso (gratis)

1. Daftar di [turso.tech](https://turso.tech) → *Sign up with GitHub/Google* (gratis).
2. Install CLI Turso di komputermu:
   ```bash
   curl -sSfL https://get.tur.so/install.sh | bash
   turso auth login
   ```
3. Buat database + ambil kredensial:
   ```bash
   turso db create splettify
   turso db show splettify --url        # → TURSO_DATABASE_URL  (libsql://...)
   turso db tokens create splettify     # → TURSO_AUTH_TOKEN    (eyJ...)
   ```
4. **Impor data yang sudah ada** (akun, percakapan, perangkat IoT — semuanya ikut):
   ```bash
   turso db shell splettify < db/turso-migrate.sql
   ```
   File `db/turso-migrate.sql` ada di dalam zip.

## Langkah 3 — Import project di Vercel

1. Daftar di [vercel.com](https://vercel.com) → *Sign up with GitHub*.
2. *Add New → Project → Import* repo `splettify` kamu.
3. Framework otomatis terdeteksi **Next.js** — biarkan default, langsung *Deploy*
   (env diisi di langkah 4, belum perlu sekarang).
4. Setelah berhasil deploy, ubah **Project Name** jadi `splettify`
   (*Settings → General → Project Name → Save* → redeploy) agar URL-nya persis
   **`splettify.vercel.app`** (kalau nama sudah dipakai orang, pilih variasi seperti
   `splettify-app`).

## Langkah 4 — Isi environment variables

*Settings → Environment Variables* → tambahkan (lihat juga `.env.vercel.example`):

| Key | Value | Wajib? |
|---|---|---|
| `TURSO_DATABASE_URL` | `libsql://splettify-<username>.turso.io` | ✅ |
| `TURSO_AUTH_TOKEN` | token dari `turso db tokens create` | ✅ |
| `NEXT_PUBLIC_SITE_URL` | `https://splettify.vercel.app` | ✅ |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | dari Google Cloud Console | opsional |
| `MAIL_FROM` / `RESEND_API_KEY` | dari resend.com | opsional |

Lalu *Deployments → terbaru → Redeploy* (agar env aktif).

## Langkah 5 — Selesai ✅

Buka **https://splettify.vercel.app** — login dengan akun yang sudah ada
(mis. `kusakyy@gmail.com`) akan langsung bekerja karena datanya sudah diimpor ke Turso.

---

## Pasca-deploy (opsional)

- **Google OAuth nyata**: di Google Cloud Console, tambahkan *Authorized redirect URI*
  `https://splettify.vercel.app/api/auth/google/callback`.
- **Email nyata**: daftar [resend.com](https://resend.com), ambil API key → isi env
  → kode verifikasi/reset terkirim sungguhan.
- **Upgrade ke domain sendiri**: sewaktu-waktu bisa tambah `www.splettify.co.id` di
  *Settings → Domains* (lihat `DEPLOY.md` untuk opsi VPS).

## Masalah umum

| Gejala | Solusi |
|---|---|
| `500` saat login | Cek `TURSO_DATABASE_URL` & `TURSO_AUTH_TOKEN` sudah benar + sudah Redeploy |
| Data kosong | Jalankan lagi `turso db shell splettify < db/turso-migrate.sql` |
| Build gagal di Vercel | Pastikan semua file ter-upload (terutama `prisma/schema.prisma`) |
| Kode verifikasi tidak terkirim | Normal — mode simulasi; isi `RESEND_API_KEY` untuk kirim nyata |
