# Panduan Deploy — Splettify di www.splettify.co.id

## Fakta penting: URL preview tidak bisa diganti

URL `preview-xxxx.space-z.ai` yang kamu pakai sekarang **diberikan otomatis oleh platform
sandbox** dan tidak dapat diubah dari dalam proyek — itu bukan bagian dari kode aplikasi.
Jadi satu-satunya cara mendapatkan URL `splettify` adalah **men-deploy ke domain milikmu
sendiri**. Kabar baiknya: seluruh konfigurasi aplikasi sudah siap untuk domain tersebut
(`metadataBase`, footer, redirect URI Google, domain email pengirim), jadi tinggal ikuti
panduan di bawah.

> ✅ **Sudah diuji (trial produksi di sandbox):** `bun run build` sukses, server standalone
> merespons `HTTP 200` dengan Host `www.splettify.co.id`, favicon `image/png`, guard API
> `401` tanpa sesi, login admin → `200`, IoT API dengan sesi → `200`. Konfigurasi produksi
> terbukti jalan — di VPS tinggal salin-tempel langkah-langkah di bawah.

---

## Opsi A — VPS + Caddy (rekomendasi)

Cocok dengan database SQLite yang sudah terpasang. Butuh: domain `splettify.co.id` + 1 VPS
(Ubuntu 22.04+, 1 GB RAM cukup).

> Catatan: domain `.co.id` didaftarkan lewat registrar resmi PANDI (Niagahoster,
> Domainesia, Rumahweb, dst.) dan umumnya meminta data KTP pemilik domain.

### 1. Arahkan DNS
Di panel registrar, buat **A record** mengarah ke IP VPS:

| Tipe | Nama | Nilai         |
|------|------|---------------|
| A    | @    | 203.0.113.10  |
| A    | www  | 203.0.113.10  |

(ganti `203.0.113.10` dengan IP VPS-mu)

### 2. Siapkan server
```bash
# install runtime & tools
curl -fsSL https://bun.sh/install | bash
sudo apt-get update && sudo apt-get install -y caddy

# salin kode proyek (mis. via git)
sudo mkdir -p /var/www/splettify
sudo chown $USER /var/www/splettify
git clone <repo-kamu> /var/www/splettify   # atau upload via scp/rsync
cd /var/www/splettify
```

### 3. Konfigurasi & build
```bash
cp .env.production.example .env
nano .env      # isi DATABASE_URL, GOOGLE_CLIENT_*, RESEND_API_KEY

bun install
bunx prisma db push        # buat tabel (atau salin db/custom.db yang sudah ada)
bun run build              # otomatis menyalin aset statis ke .next/standalone/
```

### 4. Jalankan sebagai service + HTTPS
```bash
sudo cp deploy/splettify.service /etc/systemd/system/
sudo chown -R www-data:www-data /var/www/splettify
sudo systemctl daemon-reload
sudo systemctl enable --now splettify

sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

### 5. Selesai ✅
Buka **https://www.splettify.co.id** — `splettify.co.id` tanpa www otomatis diarahkan ke
`www`, HTTPS diterbitkan otomatis oleh Caddy.

---

## Opsi B — Vercel + custom domain (paling cepat, tanpa server)

1. Push proyek ke GitHub → import di [vercel.com](https://vercel.com) → Deploy.
2. Di Vercel: *Settings → Domains → Add* `www.splettify.co.id`, lalu ikuti instruksi DNS
   (CNAME ke `cname.vercel-dns.com`).
3. *Settings → Environment Variables* → isi `NEXT_PUBLIC_SITE_URL`,
   `GOOGLE_CLIENT_ID/SECRET`, `RESEND_API_KEY` sesuai `.env.production.example`.

> ⚠️ **Catatan database:** filesystem Vercel bersifat sementara (serverless), jadi SQLite
> file (`db/custom.db`) tidak akan tersimpan. Untuk Opsi B, ganti dulu database ke
> Turso (SQLite cloud, kompatibel dengan Drizzle/Prisma) atau Postgres (mis. Neon/Supabase).
> Kalau tidak mau migrasi database, pakai **Opsi A**.

---

## Checklist pasca-deploy

- [ ] `https://www.splettify.co.id` terbuka dengan gembok 🔒
- [ ] **Google OAuth**: di Google Cloud Console, ganti/tambah *Authorized redirect URI*
      menjadi `https://www.splettify.co.id/api/auth/google/callback`
- [ ] **Email**: verifikasi domain `splettify.co.id` di Resend agar kode verifikasi &
      reset sandi terkirim dari `noreply@splettify.co.id`
- [ ] Coba daftar akun baru end-to-end (register → verifikasi → login → chat)
- [ ] Login admin `kusakyy@gmail.com` → cek Panel Admin & IoT Dashboard
