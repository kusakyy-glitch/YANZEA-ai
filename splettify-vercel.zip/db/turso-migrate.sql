-- ─────────────────────────────────────────────────────────────
-- Dump SQLite → Turso — Splettify (AI Agent Otomasi, IIoT & IoT)
-- Dihasilkan oleh scripts/dump_sqlite.mjs
-- Impor: turso db shell <nama-db> < db/turso-migrate.sql
-- ─────────────────────────────────────────────────────────────
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;

CREATE TABLE "Session" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "token" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7ya0r40001nbsh8tq9vtv9', '2e2bd66f1ebefa88e2332ac581a4bfdab2d4a7929c58ea6fc4ad2a53971299ce', 'cmw7y67wv0000nbv2mx757okc', 1796741482575, 1794149482576);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7yaak20009nbshn0dkp46t', 'fe512c1e4fa1184bda8f4a9376f1b5dd0534d4d9a16e13737d82ca48d9cb5670', 'cmw7yaah40005nbshlyy5w5oc', 1796741495282, 1794149495283);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7yaalj000bnbshpstwv0q5', 'da95691081068c413890461c56cb5bcb7d407e15c64095c0326af742ade90d68', 'cmw7yaah40005nbshlyy5w5oc', 1796741495335, 1794149495336);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7ycm0y000inbshh0e8qdm6', 'cf94d18a61e470831f0c613d0d835286a9151f1d832995ca83a4aa0c003b7b11', 'cmw7ycm0v000gnbshfbu63hle', 1796741603458, 1794149603459);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7yoql20001nbb90udyggri', '4f9a236dc56c97804346546eeccc994d92ac499646cb4f01ebdd633583ff18a6', 'cmw7yaah40005nbshlyy5w5oc', 1796742169237, 1794150169238);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7ypkjh0007nbb94eg71o5p', '3c96c2006135703c234314b56809d08a7c1ede59d1f98f7de40ceebd699f02e6', 'cmw7y67wv0000nbv2mx757okc', 1796742208060, 1794150208061);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7zbu1w000pnbb9c9pfxw43', '0b97e034f14eaa1ebb9dd304c265f6b1a2c5445499e3c828ee31174ececc90fa', 'cmw7y67wv0000nbv2mx757okc', 1796743246819, 1794151246820);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw7zbu4q000rnbb9b9h42o72', '71fcb23b2ae50bb88c00f97196b8e18bb4ae076ed238f794c20408a7aca27d48', 'cmw7yaah40005nbshlyy5w5oc', 1796743246921, 1794151246922);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw81c5gb0018nbb926hfs54q', 'dd1128bccf68e871335c74169a4cc5c060267aa9eb80fc47289e26e406a22a59', 'cmw7y67wv0000nbv2mx757okc', 1796746620826, 1794154620827);
INSERT INTO "Session" ("id", "token", "userId", "expiresAt", "createdAt") VALUES ('cmw81uret0001nb7pjzuri6ul', '63ddbcba4870ae64383acd963c229b8d79bfe0313aaa84ea2cd5f031662e72e1', 'cmw7y67wv0000nbv2mx757okc', 1796747489092, 1794155489093);
-- ↑ 10 baris data tabel "Session"

CREATE TABLE "Device" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "metric" TEXT,
    "unit" TEXT,
    "zone" TEXT NOT NULL DEFAULT 'Pabrik',
    "baseValue" REAL NOT NULL DEFAULT 0,
    "amplitude" REAL NOT NULL DEFAULT 0,
    "isOn" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Device_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67wy0002nbv2mxv6asba', 'cmw7y67wv0000nbv2mx757okc', 'Sensor Suhu Lini Produksi A', 'sensor', 'suhu', '°C', 'Lini Produksi A', 32.5, 3.5, 0, 1794149305235);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67wz0006nbv2jay2ow8u', 'cmw7y67wv0000nbv2mx757okc', 'Sensor Kelembapan Gudang', 'sensor', 'kelembapan', '%', 'Gudang Bahan', 68, 8, 0, 1794149305235);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67x00008nbv22io04cpn', 'cmw7y67wv0000nbv2mx757okc', 'Sensor Tekanan Pompa Hidrolik', 'sensor', 'tekanan', 'bar', 'Utility', 6.2, 1.4, 0, 1794149305236);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67x0000anbv2lzl4qbjr', 'cmw7y67wv0000nbv2mx757okc', 'Sensor Getaran Motor Conveyor', 'sensor', 'getaran', 'mm/s', 'Lini Produksi B', 4.1, 1.8, 0, 1794149305236);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67x1000cnbv23wzr5112', 'cmw7y67wv0000nbv2mx757okc', 'Sensor Intensitas Cahaya Workshop', 'sensor', 'cahaya', 'lux', 'Workshop', 520, 160, 0, 1794149305237);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67wz0004nbv283j82bkb', 'cmw7y67wv0000nbv2mx757okc', 'Sensor Arus Panel Utama', 'sensor', 'arus', 'A', 'Ruang Panel', 42, 10, 0, 1794149305235);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67x2000enbv2813fragi', 'cmw7y67wv0000nbv2mx757okc', 'Conveyor Line B', 'actuator', NULL, NULL, 'Lini Produksi B', 0, 0, 1, 1794149305239);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67x3000gnbv2ly7peufu', 'cmw7y67wv0000nbv2mx757okc', 'Lampu Workshop', 'actuator', NULL, NULL, 'Workshop', 0, 0, 0, 1794149305239);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67x3000inbv2qupoz98u', 'cmw7y67wv0000nbv2mx757okc', 'Pompa Hidrolik Utama', 'actuator', NULL, NULL, 'Utility', 0, 0, 1, 1794149305240);
INSERT INTO "Device" ("id", "userId", "name", "kind", "metric", "unit", "zone", "baseValue", "amplitude", "isOn", "createdAt") VALUES ('cmw7y67x4000knbv2nrdt6wt2', 'cmw7y67wv0000nbv2mx757okc', 'Kipas Pendingin Line A', 'actuator', NULL, NULL, 'Lini Produksi A', 0, 0, 1, 1794149305240);
-- ↑ 10 baris data tabel "Device"

CREATE TABLE "Conversation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Conversation_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "Conversation" ("id", "title", "userId", "createdAt", "updatedAt") VALUES ('cmw7yoqh20001nbls04wtexem', 'Kalibrasi sensor suhu', 'cmw7yaah40005nbshlyy5w5oc', 1794150169095, 1794150169095);
INSERT INTO "Conversation" ("id", "title", "userId", "createdAt", "updatedAt") VALUES ('cmw7zb1dk000jnbb91zxnwt28', 'halo tes singkat', 'cmw7yaah40005nbshlyy5w5oc', 1794151209656, 1794151210467);
INSERT INTO "Conversation" ("id", "title", "userId", "createdAt", "updatedAt") VALUES ('cmw800406000ynbb9jk2r7phg', 'siapa kamu?', 'cmw7zzmqc000snbb90kpnfnel', 1794152379462, 1794152381188);
-- ↑ 3 baris data tabel "Conversation"

CREATE TABLE "Message" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "role" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "Message" ("id", "role", "content", "conversationId", "createdAt") VALUES ('cmw7yoqh30002nblsvtjoyg5p', 'user', 'Bagaimana cara kalibrasi sensor suhu PT100 di lini produksi?', 'cmw7yoqh20001nbls04wtexem', 1794150169095);
INSERT INTO "Message" ("id", "role", "content", "conversationId", "createdAt") VALUES ('cmw7yoqh30003nbls02eoztlw', 'assistant', 'Kalibrasi sensor suhu PT100 dilakukan dengan membandingkan pembacaan terhadap termometer referensi pada titik tetap: 0 °C (air es) dan 100 °C (air mendidih), lalu terapkan koreksi offset pada PLC.', 'cmw7yoqh20001nbls04wtexem', 1794150169095);
INSERT INTO "Message" ("id", "role", "content", "conversationId", "createdAt") VALUES ('cmw7zb1dl000lnbb9n9wd6o4g', 'user', 'halo tes singkat', 'cmw7zb1dk000jnbb91zxnwt28', 1794151209658);
INSERT INTO "Message" ("id", "role", "content", "conversationId", "createdAt") VALUES ('cmw7zb201000nnbb9h2yzlt4f', 'assistant', 'Halo! Saya Yanzea, siap membantu Anda dengan sistem otomasi, IIoT, IoT, dan berbagai pertanyaan lainnya. Ada yang bisa saya bantu? 😊', 'cmw7zb1dk000jnbb91zxnwt28', 1794151210465);
INSERT INTO "Message" ("id", "role", "content", "conversationId", "createdAt") VALUES ('cmw80040b0010nbb95wo7buiq', 'user', 'siapa kamu?', 'cmw800406000ynbb9jk2r7phg', 1794152379467);
INSERT INTO "Message" ("id", "role", "content", "conversationId", "createdAt") VALUES ('cmw8005c20012nbb9bhyd0nlq', 'assistant', 'Halo! Splettify adalah asisten pintar yang siap membantu Anda dengan berbagai pertanyaan dan proyek. Saya ahli dalam bidang otomasi industri, IIoT, dan IoT, serta siap membantu kebutuhan umum seperti menulis, perencanaan, atau saran sehari-hari.

Saya bersifat ramah, antusias, dan selalu berusaha memberikan solusi yang konkret dan dapat ditindaklanjuti. Jika ada yang bisa saya bantu, jangan ragu untuk bertanya!', 'cmw800406000ynbb9jk2r7phg', 1794152381186);
-- ↑ 6 baris data tabel "Message"

CREATE TABLE "EmailVerificationCode" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "codeHash" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "usedAt" DATETIME,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "EmailVerificationCode_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "EmailVerificationCode" ("id", "userId", "codeHash", "expiresAt", "usedAt", "attempts", "createdAt") VALUES ('cmw7ya4p90004nbshpmt51f82', 'cmw7ya4p70002nbshlhcumuv0', 'ace21e62f8cbfaf9d7b037cde5d497f4108c0785c63f6d1c3fa514e412473f8a', 1794150087692, NULL, 0, 1794149487693);
INSERT INTO "EmailVerificationCode" ("id", "userId", "codeHash", "expiresAt", "usedAt", "attempts", "createdAt") VALUES ('cmw7yaah60007nbshmx2faymw', 'cmw7yaah40005nbshlyy5w5oc', 'f5d25888aff9b900f438a7fbbb2d2e7bd182588fe651398fe8a4483ed1467e5a', 1794150095177, 1794149495278, 0, 1794149495178);
INSERT INTO "EmailVerificationCode" ("id", "userId", "codeHash", "expiresAt", "usedAt", "attempts", "createdAt") VALUES ('cmw7zzmqr000unbb9rcp7k973', 'cmw7zzmqc000snbb90kpnfnel', 'bf1d7a50d572832e987f9744244d190d61108d1b551d701e7886808164673d42', 1794152957090, 1794152368785, 0, 1794152357091);
-- ↑ 3 baris data tabel "EmailVerificationCode"

CREATE TABLE "AutomationRule" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "sensorId" TEXT NOT NULL,
    "operator" TEXT NOT NULL,
    "threshold" REAL NOT NULL,
    "actuatorId" TEXT NOT NULL,
    "action" BOOLEAN NOT NULL DEFAULT true,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AutomationRule_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "AutomationRule_sensorId_fkey" FOREIGN KEY ("sensorId") REFERENCES "Device" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "AutomationRule_actuatorId_fkey" FOREIGN KEY ("actuatorId") REFERENCES "Device" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "AutomationRule" ("id", "userId", "name", "sensorId", "operator", "threshold", "actuatorId", "action", "enabled", "createdAt") VALUES ('cmw7y67x4000mnbv25crq3ydc', 'cmw7y67wv0000nbv2mx757okc', 'Kipas ON jika suhu > 34 °C', 'cmw7y67wy0002nbv2mxv6asba', '>', 34, 'cmw7y67x4000knbv2nrdt6wt2', 1, 1, 1794149305241);
INSERT INTO "AutomationRule" ("id", "userId", "name", "sensorId", "operator", "threshold", "actuatorId", "action", "enabled", "createdAt") VALUES ('cmw7y67x5000onbv23iwof4c1', 'cmw7y67wv0000nbv2mx757okc', 'Pompa ON jika tekanan < 5,5 bar', 'cmw7y67x00008nbv22io04cpn', '<', 5.5, 'cmw7y67x3000inbv2qupoz98u', 1, 1, 1794149305242);
INSERT INTO "AutomationRule" ("id", "userId", "name", "sensorId", "operator", "threshold", "actuatorId", "action", "enabled", "createdAt") VALUES ('cmw7y67x7000qnbv2gbgqyzbo', 'cmw7y67wv0000nbv2mx757okc', 'Lampu ON jika cahaya < 200 lux', 'cmw7y67x1000cnbv23wzr5112', '<', 200, 'cmw7y67x3000gnbv2ly7peufu', 1, 1, 1794149305243);
INSERT INTO "AutomationRule" ("id", "userId", "name", "sensorId", "operator", "threshold", "actuatorId", "action", "enabled", "createdAt") VALUES ('cmw7y67x7000snbv2k134nc6e', 'cmw7y67wv0000nbv2mx757okc', 'Conveyor OFF jika getaran > 7 mm/s', 'cmw7y67x0000anbv2lzl4qbjr', '>', 7, 'cmw7y67x2000enbv2813fragi', 0, 1, 1794149305244);
-- ↑ 4 baris data tabel "AutomationRule"

CREATE TABLE "SearchHistory" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "query" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "SearchHistory_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "SearchHistory" ("id", "userId", "query", "createdAt") VALUES ('cmw7yq3oa000bnbb99b99zzu6', 'cmw7yaah40005nbshlyy5w5oc', 'sensor', 1794150232859);
INSERT INTO "SearchHistory" ("id", "userId", "query", "createdAt") VALUES ('cmw7z99up000fnbb9yzic1fua', 'cmw7y67wv0000nbv2mx757okc', 'MQTT', 1794151127329);
-- ↑ 2 baris data tabel "SearchHistory"

CREATE TABLE "User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "email" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "passwordHash" TEXT,
    "googleId" TEXT,
    "role" TEXT NOT NULL DEFAULT 'USER',
    "emailVerified" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "User" ("id", "email", "name", "passwordHash", "googleId", "role", "emailVerified", "createdAt", "updatedAt") VALUES ('cmw7y67wv0000nbv2mx757okc', 'kusakyy@gmail.com', 'Admin Splettify', '96d72aebb4521ffedf0e24999742d24f:16ebf83c217dfc277ca29dbf60499e6b1ab2deafb889f75cc19c237feebc2c51c518fce13348f3a9ecd38bb000360e91affb7c1dcf7f200a9d896911d8d854f7', NULL, 'ADMIN', 1, 1794149305231, 1794152297494);
INSERT INTO "User" ("id", "email", "name", "passwordHash", "googleId", "role", "emailVerified", "createdAt", "updatedAt") VALUES ('cmw7ya4p70002nbshlhcumuv0', 'budi.uji@test.com', 'Budi Uji', '9aa20da6044a847a88358bab52c4070e:56026e96247242cff5cc5487a7bc901dd389096970177d01e0a37cd03f4c0e3cc9055fbf8000176ff5e6debfd6823f35346fdc362901b25823b05f296a6110c6', NULL, 'USER', 0, 1794149487691, 1794149487691);
INSERT INTO "User" ("id", "email", "name", "passwordHash", "googleId", "role", "emailVerified", "createdAt", "updatedAt") VALUES ('cmw7yaah40005nbshlyy5w5oc', 'sari.uji@test.com', 'Sari Uji', '43ea30bd7ee363fb540bb50e0a3600f6:475b46d0d17186202ab6d531a8a7e93344c54b4b8038834c0f98d99d84d1ca8909512d5dcaf7d7692cbc409785c6c10245241faeeb6efc5c78a3384e0ce52149', NULL, 'USER', 1, 1794149495176, 1794149495281);
INSERT INTO "User" ("id", "email", "name", "passwordHash", "googleId", "role", "emailVerified", "createdAt", "updatedAt") VALUES ('cmw7ycm0v000gnbshfbu63hle', 'dewi.google@gmail.com', 'Dewi Google', NULL, 'google:dewi.google@gmail.com', 'USER', 1, 1794149603456, 1794149603456);
INSERT INTO "User" ("id", "email", "name", "passwordHash", "googleId", "role", "emailVerified", "createdAt", "updatedAt") VALUES ('cmw7zzmqc000snbb90kpnfnel', 'rina.uji@test.com', 'Rina Uji', '869c86a5b3203a06c27273174aa84608:ae8cbf39271ab55ea02a33dde158277f0541071e4e4a6a651b03a1f89f9fd3b005a218d464fc0a7a4f73f12e34f283acef5819c9e3645add1ea0c1171517fecf', NULL, 'USER', 1, 1794152357077, 1794152368789);
-- ↑ 5 baris data tabel "User"

CREATE TABLE "PasswordResetCode" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "codeHash" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "usedAt" DATETIME,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PasswordResetCode_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "PasswordResetCode" ("id", "userId", "codeHash", "expiresAt", "usedAt", "attempts", "createdAt") VALUES ('cmw7ycmcn000knbshoyiog615', 'cmw7y67wv0000nbv2mx757okc', '3aebe5f377baa0f0eaf405fc4e872d89c4176c937cedb97d4d49b39e869f5173', 1794150203878, NULL, 0, 1794149603880);
-- ↑ 1 baris data tabel "PasswordResetCode"

CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

CREATE UNIQUE INDEX "Session_token_key" ON "Session"("token");

CREATE UNIQUE INDEX "User_googleId_key" ON "User"("googleId");

CREATE INDEX "SearchHistory_userId_createdAt_idx" ON "SearchHistory"("userId", "createdAt");

COMMIT;
PRAGMA foreign_keys=ON;
